def are_anagrams(str1: str, str2: str):
    """
    Checks if two input strings are anagrams of each other.
    """
    # Check if both inputs are strings
    if not isinstance(str1, str) or not isinstance(str2, str):
        raise TypeError("Both inputs must be strings.")
    # Check if both strings have the same length
    if len(str1) != len(str2):
        raise ValueError("Input strings must be of the same length.")
    # Convert both strings to lowercase and sort them
    # This is done to ignore case and character order differences
    sorted_str1 = sorted(str1.lower())
    sorted_str2 = sorted(str2.lower())
    # Compare the sorted strings
    # If they are equal, the original strings are anagrams
    return sorted_str1 == sorted_str2
# Example usage:
print(are_anagrams("listen", "silent"))  # True
print(are_anagrams("hello", "world"))  # False
# Test edge cases:
try:
    are_anagrams(123, "abc")  # Raises TypeError
except TypeError as e:
    print(e)
try:
    are_anagrams("abc", "defg")  # Raises ValueError
except ValueError as e:
    print(e)