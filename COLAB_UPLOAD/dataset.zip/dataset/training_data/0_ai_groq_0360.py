import random
def quicksort(arr: list[int]):
    """
    Sorts an array of integers using the QuickSort algorithm with random pivot selection.
    Time complexity:
    - Best case: O(n log n) when the pivot is chosen such that it divides the array into two halves of roughly equal size.
    - Average case: O(n log n) due to the random pivot selection, which ensures that the array is divided into two halves of roughly equal size on average.
    - Worst case: O(n^2) when the pivot is chosen such that it is always the smallest or largest element in the array, leading to a highly unbalanced partition.
    :param arr: The array of integers to be sorted.
    :return: The sorted array of integers.
    """
    if len(arr) <= 1:  # Base case: If the array has 1 or 0 elements, it is already sorted.
        return arr
    # Select a random pivot index.
    pivot_index = random.randint(0, len(arr) - 1)
    # Swap the pivot element with the first element in the array.
    arr[0], arr[pivot_index] = arr[pivot_index], arr[0]
    # Partition the array around the pivot element.
    i = 1
    for j in range(1, len(arr)):
        if arr[j] < arr[0]:
            arr[i], arr[j] = arr[j], arr[i]
            i += 1
    # Swap the pivot element with the element at the correct position.
    arr[0], arr[i - 1] = arr[i - 1], arr[0]
    # Recursively sort the subarrays on either side of the pivot element.
    left = quicksort(arr[:i - 1])
    right = quicksort(arr[i:])
    # Combine the sorted subarrays and the pivot element.
    return left + [arr[i - 1]] + right