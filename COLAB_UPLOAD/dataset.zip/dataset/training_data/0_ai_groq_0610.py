from typing import List, Tuple
def find_pairs(nums: List[int], target: int):
    """
    Finds all pairs in the given list of numbers that sum to the target value.
    - nums: A list of integers.
    - target: The target sum.
    - A list of tuples, where each tuple contains a pair of numbers that sum to the target.
    Time complexity: O(n log n) due to sorting.
    """
    if not nums:
        return []
    nums.sort()  # Sort the list to enable two-pointer technique
    left, right = 0, len(nums) - 1  # Initialize two pointers
    pairs = []  # List to store the pairs
    while left < right:
        current_sum = nums[left] + nums[right]
        if current_sum == target:
            # If the current sum equals the target, add the pair to the result
            pairs.append((nums[left], nums[right]))
            left += 1
            right -= 1
            # Skip duplicates to find all unique pairs
            while left < right and nums[left] == nums[left - 1]:
                left += 1
            while left < right and nums[right] == nums[right + 1]:
                right -= 1
        elif current_sum < target:
            # If the current sum is less than the target, move the left pointer to the right
            left += 1
        else:
            # If the current sum is greater than the target, move the right pointer to the left
            right -= 1
    return pairs