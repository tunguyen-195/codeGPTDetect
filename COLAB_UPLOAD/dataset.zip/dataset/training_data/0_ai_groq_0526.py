import heapq
class Graph:
    """
    A class to represent a weighted graph.
    ----------
    num_vertices : int
        The number of vertices in the graph.
    adjacency_list : list
        An adjacency list representation of the graph, where each element is a list of tuples containing the neighbor and the edge weight.
    Methods:
    -------
    add_edge(u, v, weight):
        Adds an edge between vertices u and v with the given weight.
    prim_mst():
        Returns a minimum spanning tree using Prim's algorithm.
    """
    def __init__(self):
        """
        Initializes an empty graph with no vertices.
        """
        self.num_vertices = 0
        self.adjacency_list = []
    def add_edge(self, u, v, weight):
        """
        Adds an edge between vertices u and v with the given weight.
        ----
        u : int
            The index of the first vertex.
        v : int
            The index of the second vertex.
        weight : float
            The weight of the edge.
        ------