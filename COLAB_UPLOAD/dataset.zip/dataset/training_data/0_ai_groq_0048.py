def longest_increasing_subsequence(sequence: list[int]):
    """
    This function calculates the length of the longest increasing subsequence in a given sequence.
    """
    if not sequence:
        raise ValueError("Input sequence is empty")
    # Initialize a list to store the lengths of LIS ending at each position
    lengths = [1] * len(sequence)
    # Iterate over the sequence to fill the lengths list
    for i in range(1, len(sequence)):
        # For each element, compare it with all previous elements
        for j in range(i):
            # If the current element is greater than the previous element, update the length
            if sequence[i] > sequence[j]:
                lengths[i] = max(lengths[i], lengths[j] + 1)
    # The length of the LIS is the maximum value in the lengths list
    return max(lengths)
def longest_increasing_subsequence_optimized(sequence: list[int]):
    """
    This function calculates the length of the longest increasing subsequence in a given sequence using an optimized approach.
    """
    if not sequence:
        raise ValueError("Input sequence is empty")
    # Initialize a list to store the smallest tail of each subsequence length
    tails = [sequence[0]]
    # Iterate over the sequence to fill the tails list
    for num in sequence[1:]:
        # If the current number is greater than the last tail, append it to the tails list
        if num > tails[-1]:
            tails.append(num)
        # Otherwise, find the smallest tail that is greater than or equal to the current number and update it
        else: