def binary_search(arr: list[int], target: int):
    """
    Performs a binary search on a sorted array to find the index of a target element.
    """
    # Check if the input array is sorted
    if not is_sorted(arr):
        raise ValueError("Input array must be sorted")
    low, high = 0, len(arr) - 1
    while low <= high:
        # Calculate the mid index
        mid = (low + high) // 2
        # Check if the target element is found at the mid index
        if arr[mid] == target:
            return mid
        # If the target element is less than the mid element, search in the left half
        elif arr[mid] > target:
            high = mid - 1
        # If the target element is greater than the mid element, search in the right half
        else:
            low = mid + 1
    # If the target element is not found, return -1
    return -1
def is_sorted(arr: list[int]):
    """
    Checks if a list is sorted in ascending order.
    """
    # Check if the list is sorted using a simple iterative approach
    for i in range(len(arr) - 1):
        if arr[i] > arr[i + 1]: