from typing import Dict, List, Set
class Graph:
    """
    Represents a directed graph using adjacency list representation.
    """
    
    def __init__(self):
        """
        Initializes an empty graph.
        """
        self.adjacency_list: Dict[int, List[int]] = {}
    def add_edge(self, source: int, destination: int):
        """
        Adds a directed edge from source node to destination node.
        """
        if source not in self.adjacency_list:
            self.adjacency_list[source] = []
        self.adjacency_list[source].append(destination)
    def cycle_detection(self, start_node: int):
        """
        Detects whether a cycle exists in the graph starting from a given node.
        bool: True if a cycle exists, False otherwise.
        """
        visited: Set[int] = set()
        rec_stack: Set[int] = set()
        def is_cyclic_util(node: int):
            """
            Recursive helper function to perform DFS.
