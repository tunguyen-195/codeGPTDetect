def modular_exponentiation(base: int, exponent: int, modulus: int):
    """
    Compute the modular exponentiation of a given base, exponent, and modulus.
    int: The result of the modular exponentiation.
    TypeError: If the inputs are not integers.
    ValueError: If the modulus is zero.
    """
    # Check if inputs are integers
    if not isinstance(base, int) or not isinstance(exponent, int) or not isinstance(modulus, int):
        raise TypeError("All inputs must be integers.")
    # Check if modulus is zero
    if modulus == 0:
        raise ValueError("Modulus cannot be zero.")
    # Handle negative exponents
    if exponent < 0:
        # Compute the modular multiplicative inverse of the base
        inverse_base = pow(base, -1, modulus)
        # Update the base and exponent
        base = inverse_base
        exponent = -exponent
    # Initialize the result to 1
    result = 1
    # Compute the modular exponentiation using the exponentiation by squaring method
    while exponent > 0:
        # If the exponent is odd, multiply the result by the base
        if exponent % 2 == 1:
            result = (result * base) % modulus
        # Square the base and divide the exponent by 2
        base = (base * base) % modulus