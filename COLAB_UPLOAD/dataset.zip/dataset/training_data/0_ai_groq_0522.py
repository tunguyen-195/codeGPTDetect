from typing import Dict, List, Tuple
import heapq
class Graph:
    """
    A weighted graph represented as an adjacency list.
    """
    def __init__(self):
        self.vertices = {}
    def add_vertex(self, vertex: str):
        """
        Add a new vertex to the graph.
        """
        if vertex not in self.vertices:
            self.vertices[vertex] = {}
    def add_edge(self, from_vertex: str, to_vertex: str, weight: float):
        """
        Add a new edge to the graph.
        """
        if from_vertex in self.vertices and to_vertex in self.vertices:
            self.vertices[from_vertex][to_vertex] = weight
            self.vertices[to_vertex][from_vertex] = weight  # For undirected graph
    def dijkstra(self, start_vertex: str):
        """
        Find the shortest path from the start vertex to all other vertices using Dijkstra's algorithm.
        """
        if start_vertex not in self.vertices:
            raise ValueError("Start vertex not found in graph")
        distances = {vertex: float('inf') for vertex in self.vertices}
        distances[start_vertex] = 0
        unvisited_vertices = [(0, start_vertex)]
