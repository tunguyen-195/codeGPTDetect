from typing import Dict, List, Set
class DirectedGraph:
    """
    A class representing a directed graph.
    ----------
    graph : Dict[int, List[int]]
        A dictionary representing the adjacency list of the graph.
    """
    def __init__(self):
        """
        Initializes an empty directed graph.
        """
        self.graph: Dict[int, List[int]] = {}
    def add_vertex(self, vertex: int):
        """
        Adds a new vertex to the graph.
        -----
        vertex : int
            The vertex to be added.
        """
        if vertex not in self.graph:
            self.graph[vertex] = []
    def add_edge(self, source: int, destination: int):
        """
        Adds a new edge to the graph.
        -----
        source : int
            The source vertex of the edge.
        destination : int
            The destination vertex of the edge.
        ------
        ValueError