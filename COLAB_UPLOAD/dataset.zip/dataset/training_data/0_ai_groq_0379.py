from typing import Dict, List, Tuple
import heapq
class Graph:
    """
    A class representing a weighted graph.
    -----------
    num_vertices : int
        The number of vertices in the graph.
    adjacency_list : Dict[int, List[Tuple[int, int]]]
        An adjacency list representing the graph, where each key is a vertex
        and its corresponding value is a list of tuples containing the neighboring
        vertex and the edge weight.
    Methods:
    --------
    add_edge(vertex1: int, vertex2: int, weight: int)
        Adds an edge to the graph.
    dijkstra(start_vertex: int) -> Dict[int, int]
        Runs Dijkstra's algorithm to find the shortest distances from the start vertex to all other vertices.
    """
    def __init__(self):
        self.num_vertices = 0
        self.adjacency_list = {}
    def add_edge(self, vertex1: int, vertex2: int, weight: int):
        """
        Adds an edge to the graph.
        -----
        vertex1 : int
            The first vertex of the edge.
        vertex2 : int
            The second vertex of the edge.
        weight : int
            The weight of the edge.
        ------