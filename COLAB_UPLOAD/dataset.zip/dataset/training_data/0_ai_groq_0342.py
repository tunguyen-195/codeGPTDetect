class Node:
    """Represents a node in the doubly linked list."""
    def __init__(self, data: any):
        """
        Initializes a new node with the given data.
        """
        self.data = data
        self.next: 'Node' = None
        self.prev: 'Node' = None
class DoublyLinkedList:
    """Represents a doubly linked list."""
    def __init__(self):
        """
        Initializes an empty doubly linked list.
        """
        self.head: Node = None
        self.tail: Node = None
        self.size: int = 0
    def append(self, data: any):
        """
        Adds a new node with the given data at the end of the list.
        """
        new_node = Node(data)
        if self.head is None:
            self.head = new_node
            self.tail = new_node
        else:
            new_node.prev = self.tail
            self.tail.next = new_node
            self.tail = new_node
        self.size += 1
    def prepend(self, data: any):
        """
        Adds a new node with the given data at the beginning of the list.
