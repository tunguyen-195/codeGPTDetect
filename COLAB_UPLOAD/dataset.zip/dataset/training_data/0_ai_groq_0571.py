class LinearSearch:
    """
    A class representing a linear search algorithm with a sentinel value.
    """
    def __init__(self, array: list, sentinel: int):
        """
        Initializes the linear search object.
        """
        if sentinel in array:
            raise ValueError("Sentinel value must be unique in the array")
        self.sentinel = sentinel
        self.array = array
    def search(self, target: int):
        """
        Searches for the target value in the array using linear search with a sentinel.
        """
        # Add the sentinel value to the end of the array
        extended_array = self.array + [self.sentinel]
        for i, element in enumerate(extended_array):
            # Check if the target value is found
            if element == target:
                # If found, return the index in the original array
                return i - 1 if i != len(self.array) else -1
            # If the sentinel value is reached, return -1
            if element == self.sentinel:
                return -1
        # If the target value is not found, return -1
        return -1
# Example usage:
if __name__ == "__main__":
    array = [1, 2, 3, 4, 5]
    sentinel = 10
    search = LinearSearch(array, sentinel)