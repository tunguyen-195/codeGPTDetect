class Item:
    """Represents an item with its weight and value."""
    
    def __init__(self, weight: float, value: float):
        """
        Initializes an Item object.
        
        """
        self.weight = weight
        self.value = value
def fractional_knapsack(capacity: float, items: list[Item]):
    """
    Solves the Fractional Knapsack problem using the greedy approach.
    
    
    float: The maximum value that can be put in the knapsack.
    """
    
    # Calculate the value-to-weight ratio for each item
    item_ratios = [(item.value / item.weight, item) for item in items]
    
    # Sort the items in descending order of their value-to-weight ratios
    item_ratios.sort(reverse=True)
    
    total_value = 0.0
    for ratio, item in item_ratios:
        # If the item's weight is less than or equal to the remaining capacity, put the whole item in the knapsack
        if item.weight <= capacity:
            total_value += item.value
            capacity -= item.weight
        # Otherwise, put as much of the item as possible in the knapsack
        else:
            total_value += ratio * capacity
            break
    