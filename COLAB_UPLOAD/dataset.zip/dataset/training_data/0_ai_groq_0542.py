class Node:
    """Represents a node in a doubly linked list."""
    
    def __init__(self, data: any):
        """
        Initializes a node with given data.
        
        """
        self.data = data
        self.prev: Node | None = None
        self.next: Node | None = None
class DoublyLinkedList:
    """Represents a doubly linked list."""
    
    def __init__(self):
        """
        Initializes an empty doubly linked list.
        """
        self.head: Node | None = None
        self.tail: Node | None = None
        self.size: int = 0
    def append(self, data: any):
        """
        Adds a new node with given data at the end of the list.
        
        """
        node = Node(data)
        if self.head is None:
            self.head = node
            self.tail = node
        else:
            self.tail.next = node
            node.prev = self.tail
            self.tail = node
        self.size += 1
