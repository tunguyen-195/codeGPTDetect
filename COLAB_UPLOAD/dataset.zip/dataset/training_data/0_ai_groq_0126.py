def single_non_duplicate(nums: list[int]):
    """
    This function finds the single non-duplicate in an array using bit manipulation.
    
    The function works by XORing all the numbers in the array. Since XOR of all 
    elements gives us an odd occurring element, the result will be the single 
    non-duplicate number.
    int: The single non-duplicate number in the array.
    ValueError: If the input list is empty.
    """
    # Check if the input list is empty
    if not nums:
        raise ValueError("Input list cannot be empty")
    # Initialize result variable to 0
    result = 0
    # Iterate over each number in the array
    for num in nums:
        # XOR the current number with the result
        # This works because XOR of a number with itself is 0, and XOR of a number with 0 is the number itself
        result ^= num
    # After iterating over all numbers, the result will be the single non-duplicate number
    return result
# Example usage:
if __name__ == "__main__":
    nums = [2, 3, 5, 4, 5, 2, 4]
    print(single_non_duplicate(nums))  # Output: 3