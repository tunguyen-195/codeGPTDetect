from abc import ABC, abstractmethod
from enum import Enum
from typing import Dict, List
class VehicleType(Enum):
    """Enum representing the type of vehicle."""
    CAR = 1
    TRUCK = 2
    MOTORCYCLE = 3
class Vehicle(ABC):
    """Abstract base class representing a vehicle."""
    def __init__(self, license_plate: str, vehicle_type: VehicleType):
        """
        Initializes a vehicle.
        """
        self.license_plate = license_plate
        self.vehicle_type = vehicle_type
    @abstractmethod
    def can_fit(self, parking_spot):
        """Checks if the vehicle can fit in a parking spot."""
        pass
class Car(Vehicle):
    """Class representing a car."""
    def __init__(self, license_plate: str):
        """
        Initializes a car.
        """
        super().__init__(license_plate, VehicleType.CAR)
    def can_fit(self, parking_spot):
        """Checks if the car can fit in a parking spot."""
        return parking_spot.size >= 1
class Truck(Vehicle):
    """Class representing a truck."""