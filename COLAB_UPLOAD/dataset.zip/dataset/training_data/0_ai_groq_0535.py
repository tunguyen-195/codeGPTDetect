class Node:
    """Represents a single node in the Binary Search Tree."""
    
    def __init__(self, value: int):
        """Initializes a new Node with the given value."""
        
        self.value: int = value
        self.left: Node | None = None
        self.right: Node | None = None
class BinarySearchTree:
    """Represents a Binary Search Tree."""
    
    def __init__(self):
        """Initializes an empty Binary Search Tree."""
        
        self.root: Node | None = None
    def insert(self, value: int):
        """Inserts a new value into the Binary Search Tree."""
        
        if not self.root:
            self.root = Node(value)
        else:
            self._insert_recursive(self.root, value)
    def _insert_recursive(self, node: Node, value: int):
        """Recursively inserts a new value into the Binary Search Tree."""
        
        if value < node.value:
            if node.left:
                self._insert_recursive(node.left, value)
            else:
                node.left = Node(value)
        elif value > node.value:
            if node.right:
                self._insert_recursive(node.right, value)
            else:
                node.right = Node(value)
