def ternary_search(low: int, high: int, f: callable):
    """
    Ternary search for unimodal functions.
    float: The approximate minimum value of the function.
    ValueError: If the search interval is empty.
    TypeError: If the input function is not callable.
    """
    # Check if the search interval is empty
    if low >= high:
        raise ValueError("Search interval must not be empty")
    # Check if the input function is callable
    if not callable(f):
        raise TypeError("Input function must be callable")
    # Initialize the search interval
    while high - low > 1:
        # Calculate the two points that divide the search interval into three equal parts
        mid1 = low + (high - low) // 3
        mid2 = high - (high - low) // 3
        # Evaluate the function at the two points
        y1 = f(mid1)
        y2 = f(mid2)
        # If the function values at the two points are different, update the search interval
        if y1 < y2:
            # Move the upper bound to the second point
            high = mid2
        else:
            # Move the lower bound to the first point
            low = mid1
