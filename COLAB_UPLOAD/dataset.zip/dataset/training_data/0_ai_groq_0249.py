from typing import Any, List, Tuple
class Deque:
    """
    A Double-ended Queue implementation.
    This class provides methods for adding elements to both ends of the queue,
    removing elements from both ends, and checking the size of the queue.
    """
    def __init__(self):
        """
        Initializes an empty deque.
        """
        self.__items: List[Any] = []
    def append_front(self, item: Any):
        """
        Adds an element to the front of the deque.
        """
        self.__items.insert(0, item)
    def append_rear(self, item: Any):
        """
        Adds an element to the rear of the deque.
        """
        self.__items.append(item)
    def remove_front(self):
        """
        Removes and returns the element from the front of the deque.
        """
        if not self.__items:
            raise IndexError("Deque is empty")
        return self.__items.pop(0)
