from typing import List
def get_permutations(string: str):
    """
    Generate all permutations of a given string.
    List[str]: A list of all permutations of the input string.
    TypeError: If the input is not a string.
    ValueError: If the input string is empty.
    """
    # Check if input is a string
    if not isinstance(string, str):
        raise TypeError("Input must be a string.")
    # Check if input string is empty
    if len(string) == 0:
        raise ValueError("Input string cannot be empty.")
    # Base case: if the string has only one character, return it
    if len(string) == 1:
        return [string]
    # Initialize an empty list to store the permutations
    permutations = []
    # Iterate over each character in the string
    for i, char in enumerate(string):
        # Get the remaining characters
        remaining_chars = string[:i] + string[i+1:]
        # Generate permutations for the remaining characters
        for perm in get_permutations(remaining_chars):
            # Append the current character to each permutation
            permutations.append(char + perm)
    return permutations