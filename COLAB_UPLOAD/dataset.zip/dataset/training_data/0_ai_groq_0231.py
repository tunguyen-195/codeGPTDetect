from typing import Dict, List
class Graph:
    """
    Represents an undirected graph using an adjacency list representation.
    """
    def __init__(self, num_vertices: int):
        """
        Initializes a graph with the given number of vertices.
        """
        self.num_vertices = num_vertices
        self.adjacency_list = {i: [] for i in range(num_vertices)}
    def add_edge(self, vertex1: int, vertex2: int):
        """
        Adds an edge between two vertices in the graph.
        """
        self.adjacency_list[vertex1].append(vertex2)
        self.adjacency_list[vertex2].append(vertex1)
    def find_articulation_points(self):
        """
        Finds all articulation points in the graph.
        List[int]: A list of articulation points in the graph.
        """
        visited = [False] * self.num_vertices
        discovery_time = [float('inf')] * self.num_vertices
        low_value = [float('inf')] * self.num_vertices
        parent = [None] * self.num_vertices
        articulation_points = set()