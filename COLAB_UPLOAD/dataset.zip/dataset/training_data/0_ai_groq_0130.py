def read_large_file(file_path: str):
    """
    Reads a large file line by line efficiently.
    """
    try:
        # Open the file in read mode
        with open(file_path, 'r', encoding='utf-8') as file:
            # Read the file line by line
            for line in file:
                # Yield each line
                yield line.strip()
    except FileNotFoundError:
        # Handle the case when the file does not exist
        print(f"The file {file_path} does not exist.")
        raise
    except PermissionError:
        # Handle the case when there is no permission to read the file
        print(f"No permission to read the file {file_path}.")
        raise
    except Exception as e:
        # Handle any other exceptions
        print(f"An error occurred: {e}")
        raise
def main():
    # Example usage
    file_path = 'large_file.txt'
    for i, line in enumerate(read_large_file(file_path)):
        print(f"Line {i+1}: {line}")
if __name__ == "__main__":
    main()