def manacher(s: str):
    """
    This function implements Manacher's algorithm to find the longest palindrome in a given string.
    
    
    str: The longest palindrome substring.
    """
    
    # Preprocess the string to handle even length palindromes
    T = '#'.join('^{}$'.format(s))
    n = len(T)
    P = [0] * n
    C = R = 0
    
    # Initialize the maximum length and center of the longest palindrome
    max_len = 0
    center = 0
    
    for i in range(1, n - 1):
        # If i is within the right boundary of the current center, use the mirror property
        if R > i:
            i_mirror = 2 * C - i
            P[i] = min(R - i, P[i_mirror])
        
        # Attempt to expand the palindrome centered at i
        while T[i + P[i] + 1] == T[i - P[i] - 1]:
            P[i] += 1
        
        # If the palindrome centered at i expand past the right boundary, update the center and right boundary
        if i + P[i] > R:
            C, R = i, i + P[i]
        
        # Update the maximum length and center of the longest palindrome
        if P[i] > max_len:
            max_len = P[i]
            center = i
    
    # Extract the longest palindrome substring
    longest_palindrome = T[center - max_len: center + max_len + 1].replace('#', '').replace('^', '').replace('$', '')