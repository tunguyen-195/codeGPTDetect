def jump_search(arr: list[int], target: int):
    """
    Jump Search algorithm implementation for sorted arrays.
    """
    if not arr:
        raise ValueError("Input array is empty")
    # Calculate the jump size
    jump_size = int(len(arr) ** 0.5)
    # Find the block where the target value may be present
    left, right = 0, 0
    while right < len(arr) and arr[right] <= target:
        left = right
        right += jump_size
    # If the right pointer exceeds the array length, set it to the last index
    if right > len(arr) - 1:
        right = len(arr) - 1
    # Perform a linear search in the block for the target value
    index = left
    while index <= right and arr[index] <= target:
        # If the target value is found, return its index
        if arr[index] == target:
            return index
        index += 1
    # If the target value is not found, return -1
    return -1
def main():
    # Example usage
    arr = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10]
    target = 5
    result = jump_search(arr, target)
    if result != -1:
        print(f"Target value {target} found at index {result}")
    else: