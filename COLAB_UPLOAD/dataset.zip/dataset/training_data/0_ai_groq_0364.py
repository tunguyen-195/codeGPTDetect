def selection_sort(arr: list):
    """
    Sorts an array in ascending order using the Selection Sort algorithm.
    Time complexity: O(n^2)
    Space complexity: O(1)
    TypeError: If the input is not a list.
    ValueError: If the input list is empty.
    """
    # Check if the input is a list
    if not isinstance(arr, list):
        raise TypeError("Input must be a list.")
    # Check if the input list is empty
    if len(arr) == 0:
        raise ValueError("Input list cannot be empty.")
    # Iterate over the array
    for i in range(len(arr)):
        # Initialize the minimum index to the current index
        min_idx = i
        # Iterate over the unsorted portion of the array to find the minimum element
        for j in range(i + 1, len(arr)):
            # If a smaller element is found, update the minimum index
            if arr[j] < arr[min_idx]:
                min_idx = j
        # Swap the minimum element with the current element
        arr[i], arr[min_idx] = arr[min_idx], arr[i]
# Example usage:
arr = [64, 25, 12, 22, 11]
print("Original array:", arr)
selection_sort(arr)
print("Sorted array:", arr)