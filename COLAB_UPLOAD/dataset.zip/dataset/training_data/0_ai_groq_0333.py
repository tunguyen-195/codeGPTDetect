class Activity:
    """Represents an activity with start and finish times."""
    
    def __init__(self, id: int, start: int, finish: int):
        """
        Initializes an activity.
        
        """
        self.id = id
        self.start = start
        self.finish = finish
    def __repr__(self):
        """Returns a string representation of the activity."""
        return f"Activity({self.id}, {self.start}, {self.start + 1})"
def activity_selection(activities: list[Activity]):
    """
    Selects the maximum number of activities that can be performed by a single person.
    
    The greedy approach is used: at each step, select the activity with the earliest finish time.
    
    
    list[Activity]: List of selected activities.
    """
    # Sort the activities by their finish times
    activities.sort(key=lambda activity: activity.finish)
    
    # Initialize the list of selected activities
    selected_activities = []
    
    # Initialize the finish time of the last selected activity
    last_finish = -1
    
    # Iterate over the activities
    for activity in activities: