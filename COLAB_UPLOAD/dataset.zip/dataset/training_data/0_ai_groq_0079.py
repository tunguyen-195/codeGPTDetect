from typing import List, Tuple, Optional
def two_sum(nums: List[int], target: int):
    """
    Returns the indices of the two numbers in the list that add up to the target.
    """
    # Create a hash map to store the numbers we've seen so far and their indices
    num_map = {}
    # Iterate over the list of numbers with their indices
    for i, num in enumerate(nums):
        # Calculate the complement of the current number
        complement = target - num
        # Check if the complement is in the hash map
        if complement in num_map:
            # If it is, return the indices of the current number and its complement
            return (num_map[complement], i)
        # If not, add the current number and its index to the hash map
        num_map[num] = i
    # If we've iterated over the entire list and haven't found a pair, return None
    return None
def main():
    # Example usage:
    nums = [2, 7, 11, 15]
    target = 9
    result = two_sum(nums, target)
    if result:
        print(f"Indices of the two numbers that add up to {target}: {result}")
    else:
        print("No pair found that adds up to the target.")
if __name__ == "__main__":
    main()