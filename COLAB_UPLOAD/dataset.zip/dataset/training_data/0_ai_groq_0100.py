import heapq
from collections import defaultdict
from typing import Dict, List, Tuple
class Node:
    """Represents a node in the Huffman tree."""
    def __init__(self, char: str, freq: int):
        self.char = char
        self.freq = freq
        self.left = None
        self.right = None
    def __lt__(self, other: 'Node'):
        """Compares two nodes based on their frequencies."""
        return self.freq < other.freq
def calculate_frequencies(text: str):
    """
    Calculates the frequency of each character in the given text.
    Dict[str, int]: A dictionary where the keys are characters and the values are their frequencies.
    """
    frequencies = defaultdict(int)
    for char in text:
        frequencies[char] += 1
    return dict(frequencies)
def build_huffman_tree(frequencies: Dict[str, int]):
    """
    Builds the Huffman tree using a priority queue.
    Node: The root of the Huffman tree.
    """
    # Create a priority queue to store the nodes
    priority_queue = []
    for char, freq in frequencies.items():