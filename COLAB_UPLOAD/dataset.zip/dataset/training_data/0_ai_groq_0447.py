import heapq
class PriorityQueue:
    """
    A Priority Queue implementation using heapq.
    Methods:
    is_empty(): Checks if the queue is empty.
    push(item, priority): Adds an item to the queue with a specified priority.
    pop(): Removes and returns the item with the highest priority from the queue.
    peek(): Returns the item with the highest priority from the queue without removing it.
    """
    def __init__(self, reversed=False):
        """
        Initializes a new Priority Queue.
        """
        self.queue = []
        self.reversed = reversed
    def is_empty(self):
        """
        Checks if the queue is empty.
        bool: True if the queue is empty, False otherwise.
        """
        return not self.queue
    def push(self, item: any, priority: int):
        """
        Adds an item to the queue with a specified priority.
