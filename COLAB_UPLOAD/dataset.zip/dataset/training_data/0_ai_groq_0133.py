import requests
from bs4 import BeautifulSoup
from typing import List, Dict
def web_scraper(url: str):
    """
    Web scraper function using BeautifulSoup.
    Dict: A dictionary containing the scraped data.
    """
    try:
        # Send a GET request to the URL
        response = requests.get(url)
        
        # Check if the request was successful
        if response.status_code == 200:
            # Parse the HTML content using BeautifulSoup
            soup = BeautifulSoup(response.text, 'html.parser')
            
            # Find all the paragraph tags on the webpage
            paragraphs = soup.find_all('p')
            
            # Initialize an empty list to store the paragraph text
            paragraph_text = []
            
            # Loop through each paragraph and extract the text
            for paragraph in paragraphs:
                # Strip any leading or trailing whitespace from the text
                text = paragraph.get_text().strip()
                
                # Add the text to the list
                paragraph_text.append(text)
            
            # Create a dictionary to store the scraped data
            data = {
                'url': url,
                'paragraphs': paragraph_text
            }