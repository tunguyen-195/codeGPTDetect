def compute_prefix_function(pattern: str):
    """
    Compute the prefix function for the given pattern.
    The prefix function is used in the KMP algorithm to determine the amount
    of characters that can be safely skipped when a mismatch occurs.
    """
    prefix = [0] * len(pattern)
    j = 0
    for i in range(1, len(pattern)):
        while j > 0 and pattern[i] != pattern[j]:
            j = prefix[j - 1]
        if pattern[i] == pattern[j]:
            j += 1
        prefix[i] = j
    return prefix
def kmp_pattern_matching(text: str, pattern: str):
    """
    Find all occurrences of the given pattern in the text using the KMP algorithm.
    """
    if not text or not pattern:
        return []  # edge case: empty text or pattern
    prefix = compute_prefix_function(pattern)
    occurrences = []
    j = 0
    for i in range(len(text)):
        while j > 0 and text[i] != pattern[j]:
            j = prefix[j - 1]
        if text[i] == pattern[j]:
            j += 1
        if j == len(pattern):
            occurrences.append((i - len(pattern) + 1, i))
            j = prefix[j - 1]
    return occurrences
# Example usage: