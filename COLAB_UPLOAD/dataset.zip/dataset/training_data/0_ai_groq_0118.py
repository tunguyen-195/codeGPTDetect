def is_prime(n: int):
    """
    Checks if a number is prime.
    bool: True if the number is prime, False otherwise.
    TypeError: If the input is not an integer.
    ValueError: If the input is less than 2.
    """
    # Check if input is an integer
    if not isinstance(n, int):
        raise TypeError("Input must be an integer.")
    # Check if input is less than 2
    if n < 2:
        raise ValueError("Input must be greater than or equal to 2.")
    # 2 is the only even prime number
    if n == 2:
        return True
    # All other even numbers are not prime
    if n % 2 == 0:
        return False
    # Check odd factors up to the square root of n
    for i in range(3, int(n ** 0.5) + 1, 2):
        # If n is divisible by any factor, it's not prime
        if n % i == 0:
            return False
    # If no factors are found, n is prime
    return True
def main():
    # Example usage:
    print(is_prime(11))  # True
    print(is_prime(15))  # False