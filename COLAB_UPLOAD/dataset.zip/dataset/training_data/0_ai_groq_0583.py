def longest_increasing_subsequence(nums: list[int]):
    """
    Returns the length of the longest increasing subsequence in the given list of integers.
    nums: A list of integers.
    An integer representing the length of the longest increasing subsequence.
    Time complexity: O(n^2)
    Space complexity: O(n)
    """
    if not nums:
        return 0
    n = len(nums)
    dp = [1] * n  # Initialize dp array with 1s
    for i in range(1, n):
        for j in range(i):
            # If the current element is greater than the previous element,
            # update the dp array with the maximum length of subsequence
            if nums[i] > nums[j]:
                dp[i] = max(dp[i], dp[j] + 1)
        # Update the maximum length of subsequence
        dp[i] = max(dp[i], 1)
    return max(dp)
def longest_increasing_subsequence_with_indices(nums: list[int]):
    """
    Returns the length of the longest increasing subsequence and its indices in the given list of integers.
    nums: A list of integers.
    A tuple containing an integer representing the length of the longest increasing subsequence
    and a list of indices representing the positions of the subsequence in the original list.
    Time complexity: O(n^2)
    Space complexity: O(n)
    """