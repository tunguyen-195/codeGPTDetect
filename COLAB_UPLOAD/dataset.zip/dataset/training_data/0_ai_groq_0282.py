def longest_common_subsequence(str1: str, str2: str):
    """
    Compute the longest common subsequence of two input strings using dynamic programming.
    Time complexity: O(m*n), where m and n are the lengths of str1 and str2 respectively.
    Space complexity: O(m*n), for the 2D array used to store the dynamic programming table.
    """
    # Initialize a 2D array to store the lengths of common subsequences
    dp: list[list[int]] = [[0] * (len(str2) + 1) for _ in range(len(str1) + 1)]
    # Fill the dynamic programming table
    for i in range(1, len(str1) + 1):
        for j in range(1, len(str2) + 1):
            # If the current characters in str1 and str2 are equal, update the length of the common subsequence
            if str1[i - 1] == str2[j - 1]:
                dp[i][j] = dp[i - 1][j - 1] + 1
            # Otherwise, take the maximum length of the common subsequences without the current characters
            else:
                dp[i][j] = max(dp[i - 1][j], dp[i][j - 1])
    # Reconstruct the longest common subsequence from the dynamic programming table
    lcs: list[str] = []
    i, j = len(str1), len(str2)
    while i > 0 and j > 0:
        # If the current characters in str1 and str2 are equal, add the character to the LCS and move diagonally
        if str1[i - 1] == str2[j - 1]:
            lcs.append(str1[i - 1])
            i -= 1
            j -= 1
        # Otherwise, move in the direction of the larger value
        elif dp[i - 1][j] > dp[i][j - 1]:
            i -= 1
        else:
            j -= 1
    # Return the longest common subsequence in the correct order
    return ''.join(reversed(lcs))
# Example usage: