class MaxHeap:
    """
    A class representing a Max Heap data structure.
    """
    def __init__(self, elements: list = None):
        """
        Initializes a new Max Heap instance.
        """
        self.heap = []
        if elements is not None:
            self.heap = elements[:]
            self.heapify()
    def heapify(self):
        """
        Builds a Max Heap by heapifying the underlying list.
        This operation ensures that the parent node is greater than its child nodes at each level.
        """
        for i in range(len(self.heap) // 2 - 1, -1, -1):
            self.sift_down(i)
    def sift_down(self, index: int):
        """
        Sifts down the element at the given index to maintain the Max Heap property.
        """
        while True:
            largest = index
            left_child = 2 * index + 1
            right_child = 2 * index + 2
            # Check if the left child is larger
            if left_child < len(self.heap) and self.heap[left_child] > self.heap[largest]:
                largest = left_child
            # Check if the right child is larger