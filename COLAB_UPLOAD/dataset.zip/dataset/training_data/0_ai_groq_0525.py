import heapq
from typing import List, Tuple
class DisjointSet:
    """Disjoint set data structure for union-find operations."""
    def __init__(self, vertices: int):
        """Initialize the disjoint set with 'vertices' vertices."""
        self.parent = {i: i for i in range(vertices)}
        self.rank = {i: 0 for i in range(vertices)}
    def find(self, vertex: int):
        """Find the representative of the set containing 'vertex'."""
        if self.parent[vertex] != vertex:
            self.parent[vertex] = self.find(self.parent[vertex])
        return self.parent[vertex]
    def union(self, vertex1: int, vertex2: int):
        """Merge the sets containing 'vertex1' and 'vertex2'."""
        root1 = self.find(vertex1)
        root2 = self.find(vertex2)
        if root1 != root2:
            if self.rank[root1] > self.rank[root2]:
                self.parent[root2] = root1
            else:
                self.parent[root1] = root2
                if self.rank[root1] == self.rank[root2]:
                    self.rank[root2] += 1
class Graph:
    """Graph data structure with methods for Kruskal's algorithm."""
    def __init__(self, vertices: int):
        """Initialize the graph with 'vertices' vertices."""
        self.vertices = vertices
        self.edges = []
    def add_edge(self, weight: int, vertex1: int, vertex2: int):
        """Add an edge to the graph with 'weight' and endpoints 'vertex1' and 'vertex2'."""
        self.edges.append((weight, vertex1, vertex2))