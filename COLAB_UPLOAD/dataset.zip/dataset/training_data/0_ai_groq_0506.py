def is_valid_parentheses(s: str):
    """
    Checks if a given string of parentheses is valid.
    A string of parentheses is valid if every open parenthesis can be matched with a corresponding close parenthesis.
    """
    # Create a dictionary to map closing parentheses to their corresponding opening ones
    parentheses_map = {')': '(', '}': '{', ']': '['}
    # Create a set of opening parentheses for easy look up
    opening_parentheses = set(['(', '{', '['])
    # Initialize an empty stack to store the opening parentheses
    stack = []
    # Iterate over each character in the string
    for char in s:
        # If the character is an opening parenthesis, push it onto the stack
        if char in opening_parentheses:
            stack.append(char)
        # If the character is a closing parenthesis, check if the stack is empty or the top of the stack does not match
        elif char in parentheses_map:
            if not stack or stack.pop() != parentheses_map[char]:
                return False
    # If the stack is empty after iterating over the entire string, the parentheses are valid
    return not stack