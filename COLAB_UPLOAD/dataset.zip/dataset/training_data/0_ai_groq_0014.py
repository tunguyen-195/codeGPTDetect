from typing import Any
class Deque:
    """
    A class representing a Deque (Double-ended Queue) data structure.
    
    This class provides methods to add and remove elements from both ends of the deque.
    """
    def __init__(self):
        """
        Initializes an empty deque.
        """
        self._deque: list[Any] = []
    def add_front(self, value: Any):
        """
        Adds an element to the front of the deque.
        
        """
        self._deque.insert(0, value)
    def add_rear(self, value: Any):
        """
        Adds an element to the rear of the deque.
        
        """
        self._deque.append(value)
    def remove_front(self):
        """
        Removes an element from the front of the deque.
        
        """
        if not self._deque:
            raise IndexError("Cannot remove from an empty deque")
        return self._deque.pop(0)
    def remove_rear(self):
        """