def rob(nums: list[int]):
    """
    This function solves the House Robber problem using dynamic programming.
    
    The problem statement is: You are a professional thief planning to rob houses along a street. 
    Each house has a certain amount of money stashed, the only constraint stopping you from robbing each of them is that 
    adjacent houses have security systems connected and it will automatically contact the police if two adjacent houses were broken into on the same night.
    
    Given a list of non-negative integers representing the amount of money of each house, 
    determine the maximum amount of money you can rob tonight without alerting the police.
    int: The maximum amount of money that can be robbed.
    """
    # Base case: If the list is empty, return 0
    if not nums:
        return 0
    # Base case: If the list has only one house, return the money in that house
    if len(nums) == 1:
        return nums[0]
    # Initialize a list to store the maximum amount of money that can be robbed up to each house
    dp = [0] * len(nums)
    # The maximum amount of money that can be robbed up to the first house is the money in the first house
    dp[0] = nums[0]
    # The maximum amount of money that can be robbed up to the second house is the maximum of the money in the first house and the money in the second house
    dp[1] = max(nums[0], nums[1])
    # For each house from the third house onwards
    for i in range(2, len(nums)):
        # The maximum amount of money that can be robbed up to this house is the maximum of the maximum amount of money that can be robbed up to the previous house
        # and the sum of the money in this house and the maximum amount of money that can be robbed up to the house two houses ago
        dp[i] = max(dp[i-1], dp[i-2] + nums[i])
    # The maximum amount of money that can be robbed is the maximum amount of money that can be robbed up to the last house