def jump_search(arr: list, x: int):
    """
    Jump search algorithm for finding an element in a sorted array.
    int: The index of the target element if found, -1 otherwise.
    TypeError: If the input array is not a list or the target element is not an integer.
    ValueError: If the input array is empty or the target element is not found.
    """
    n = len(arr)
    # Find block size to be jumped
    step = int(n ** 0.5)
    # Find the block where element is present
    prev = 0
    while arr[min(step, n) - 1] < x:
        # This is done to ensure that the element is within the array
        prev = step
        step += int(n ** 0.5)
        if prev >= n:
            return -1
    # Doing a linear search for the element in the block where it is present
    while arr[prev] < x:
        prev += 1
        # If we reach the end of the block, the element is not present
        if prev == min(step, n):
            return -1
    # If element is found, return its index
    if arr[prev] == x:
        return prev
    return -1
# Example usage:
if __name__ == "__main__":