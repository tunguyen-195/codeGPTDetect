def floyd_warshall(graph: list[list[int]]):
    """
    Compute the shortest path between all pairs of vertices in a weighted graph.
    graph: A 2D list representing the adjacency matrix of the graph.
           graph[i][j] is the weight of the edge from vertex i to vertex j.
           If there is no edge between i and j, graph[i][j] is infinity.
    A 2D list representing the shortest distances between all pairs of vertices.
    """
    # Get the number of vertices in the graph
    num_vertices = len(graph)
    # Create a copy of the input graph to store the shortest distances
    distances = [[float('inf')] * num_vertices for _ in range(num_vertices)]
    # Initialize the distances matrix with the input graph
    for i in range(num_vertices):
        for j in range(num_vertices):
            distances[i][j] = graph[i][j]
    # Create a 2D list to store the shortest paths
    paths = [[None] * num_vertices for _ in range(num_vertices)]
    # Initialize the distances matrix with the input graph
    for i in range(num_vertices):
        for j in range(num_vertices):
            if i == j:
                distances[i][j] = 0
                paths[i][j] = [i]
    # Iterate over all vertices as potential intermediate vertices
    for k in range(num_vertices):
        # Iterate over all pairs of vertices
        for i in range(num_vertices):
            for j in range(num_vertices):
                # Check if the path from i to k to j is shorter than the current shortest path from i to j
                if distances[i][k] + distances[k][j] < distances[i][j]:
                    distances[i][j] = distances[i][k] + distances[k][j]