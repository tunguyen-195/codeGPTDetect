def knapsack_capacity(weights: list[int], values: list[int], capacity: int):
    """
    Solves the 0-1 Knapsack problem using dynamic programming.
    tuple[list[int], int]: A tuple containing the optimal subset of items and their total value.
    Time complexity: O(nW)
    Space complexity: O(nW)
    """
    n = len(weights)
    dp = [[0] * (capacity + 1) for _ in range(n + 1)]
    # Fill dp[][] in bottom up manner
    for i in range(1, n + 1):
        for w in range(1, capacity + 1):
            # If weight of the item is more than capacity, then this item cannot be included
            if weights[i - 1] > w:
                dp[i][w] = dp[i - 1][w]
            else:
                # Return maximum of excluding and including the item
                dp[i][w] = max(dp[i - 1][w], values[i - 1] + dp[i - 1][w - weights[i - 1]])
    # Reconstruct the optimal subset of items
    subset = []
    w = capacity
    for i in range(n, 0, -1):
        if dp[i][w] != dp[i - 1][w]:
            subset.append(i - 1)
            w -= weights[i - 1]
    return subset[::-1], dp[n][capacity]
# Example usage
weights = [1, 3, 4, 5]
values = [1, 4, 5, 7]