class Stack:
    """
    A class to implement Stack using list with push, pop, peek operations.
    """
    def __init__(self):
        """
        Initializes an empty stack.
        """
        self.elements: list = []
    def push(self, value: any):
        """
        Adds an element to the top of the stack.
        """
        self.elements.append(value)
    def pop(self):
        """
        Removes and returns the top element from the stack.
        """
        if not self.is_empty():
            return self.elements.pop()
        else:
            raise IndexError("Cannot pop from an empty stack")
    def peek(self):
        """
        Returns the top element from the stack without removing it.
        """
        if not self.is_empty():
            return self.elements[-1]
        else:
            raise IndexError("Cannot peek from an empty stack")
    def is_empty(self):