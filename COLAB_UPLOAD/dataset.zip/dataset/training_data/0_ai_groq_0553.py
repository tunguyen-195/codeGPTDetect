from typing import Dict, List
class Graph:
    """
    A class to represent a Graph using adjacency list.
    """
    def __init__(self):
        """
        Initialize an empty graph.
        """
        self.adj_list: Dict[int, List[int]] = {}
    def add_edge(self, u: int, v: int):
        """
        Add an edge between two nodes in the graph.
        """
        if u not in self.adj_list:
            self.adj_list[u] = []
        if v not in self.adj_list:
            self.adj_list[v] = []
        self.adj_list[u].append(v)
        self.adj_list[v].append(u)  # Comment: Assuming undirected graph
    def dfs(self, start_node: int):
        """
        Perform a Depth-First Search (DFS) traversal of the graph.
        """
        visited: set = set()
        self._dfs_helper(start_node, visited)
    def _dfs_helper(self, node: int, visited: set):
        """
        A helper function for the DFS traversal.
        """
        visited.add(node)
        print(node, end=" ")