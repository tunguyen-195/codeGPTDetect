class Graph:
    """
    A class to represent a graph using an adjacency list.
    """
    def __init__(self, num_vertices: int):
        """
        Initialize the graph with a specified number of vertices.
        """
        self.num_vertices = num_vertices
        self.adj_list = [[] for _ in range(num_vertices)]
    def add_edge(self, u: int, v: int, weight: int):
        """
        Add an edge to the graph.
        """
        self.adj_list[u].append((v, weight))
        self.adj_list[v].append((u, weight))  # For undirected graph
    def find(self, parent: list, i: int):
        """
        Find the set of an element i.
        """
        if parent[i] == i:
            return i
        return self.find(parent, parent[i])
    def union(self, parent: list, rank: list, x: int, y: int):
        """
        Union of two sets of x and y.
        """
        x_root = self.find(parent, x)
        y_root = self.find(parent, y)
        if rank[x_root] < rank[y_root]:
            parent[x_root] = y_root