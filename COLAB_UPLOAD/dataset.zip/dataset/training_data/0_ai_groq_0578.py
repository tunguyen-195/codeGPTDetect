import heapq
import math
class AStarSearch:
    """
    A class representing the A* Search algorithm for pathfinding.
    ----------
    grid : list of lists
        A 2D grid representing the environment.
        0 represents an empty cell.
        1 represents an obstacle.
    start : tuple
        The coordinates of the starting point.
    goal : tuple
        The coordinates of the goal point.
    heuristic : str
        The heuristic function to use. Can be 'manhattan' or 'euclidean'.
    """
    def __init__(self, grid: list[list[int]], start: tuple[int, int], goal: tuple[int, int], heuristic: str = 'manhattan'):
        """
        Initialize the AStarSearch object.
        ----
        grid : list of lists
            A 2D grid representing the environment.
        start : tuple
            The coordinates of the starting point.
        goal : tuple
            The coordinates of the goal point.
        heuristic : str, optional
            The heuristic function to use. Can be 'manhattan' or 'euclidean'. Defaults to 'manhattan'.
        """
        self.grid = grid
        self.start = start
        self.goal = goal
        self.heuristic = heuristic
        if heuristic not in ['manhattan', 'euclidean']: