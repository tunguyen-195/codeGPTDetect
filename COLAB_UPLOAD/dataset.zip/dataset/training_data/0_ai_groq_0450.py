class MinHeap:
    """
    A Min Heap data structure implementation in Python.
    """
    def __init__(self, capacity: int = 10):
        """
        Initializes a new Min Heap with the given capacity.
        """
        self.heap = [None] * (2 * capacity + 1)  # Initialize with None values
        self.capacity = capacity
        self.size = 0
    def insert(self, value: int):
        """
        Inserts a new value into the Min Heap.
        ValueError: If the heap is full.
        """
        if self.size == self.capacity:
            raise ValueError("Heap is full. Cannot insert more elements.")
        self.heap[self.size + 1] = value
        self.size += 1
        self._heapify_up(self.size)
    def extract_min(self):
        """
        Removes and returns the minimum value from the Min Heap.
        int: The minimum value.
        ValueError: If the heap is empty.