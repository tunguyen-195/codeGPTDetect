def coin_change_min_coins(coins: list[int], amount: int):
    """
    This function calculates the minimum number of coins needed to reach a given amount.
    Time complexity: O(amount * len(coins))
    Space complexity: O(amount)
    """
    # Create a list to store the minimum number of coins needed for each amount from 0 to the target amount
    dp = [float('inf')] * (amount + 1)
    dp[0] = 0  # It takes 0 coins to reach an amount of 0
    # Iterate over each coin denomination
    for coin in coins:
        # Iterate over each amount from the coin denomination to the target amount
        for x in range(coin, amount + 1):
            # Update the minimum number of coins needed for the current amount
            dp[x] = min(dp[x], dp[x - coin] + 1)
    # Return the minimum number of coins needed for the target amount, or -1 if it's not possible to reach the target amount
    return dp[amount] if dp[amount] != float('inf') else -1
# Example usage:
coins = [1, 2, 5]
amount = 11
min_coins = coin_change_min_coins(coins, amount)
print(f"The minimum number of coins needed to reach an amount of {amount} is {min_coins}")