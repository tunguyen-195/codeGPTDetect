from typing import Dict
def fibonacci(n: int, memo: Dict[int, int] = {}):
    """
    Calculate the nth Fibonacci number using memoization.
    int: The nth Fibonacci number.
    ValueError: If n is a negative integer.
    """
    # Check if n is a non-negative integer
    if not isinstance(n, int) or n < 0:
        raise ValueError("n must be a non-negative integer")
    # Base cases
    if n == 0:
        # The 0th Fibonacci number is 0
        return 0
    elif n == 1:
        # The 1st Fibonacci number is 1
        return 1
    elif n in memo:
        # If the Fibonacci number has been calculated before, return the stored result
        return memo[n]
    else:
        # Calculate the Fibonacci number and store it in the memo dictionary
        result = fibonacci(n - 1, memo) + fibonacci(n - 2, memo)
        memo[n] = result
        return result
def main():
    # Example usage
    n = 10
    print(f"The {n}th Fibonacci number is: {fibonacci(n)}")
if __name__ == "__main__":