def compress_string(input_str: str):
    """
    Compresses a given string by replacing repeated characters with the character and its count.
    str: The compressed string.
    TypeError: If the input is not a string.
    """
    # Check if the input is a string
    if not isinstance(input_str, str):
        raise TypeError("Input must be a string.")
    # Handle edge case where the input string is empty
    if not input_str:
        return ""
    # Initialize variables to keep track of the current character and its count
    current_char = input_str[0]
    current_count = 1
    # Initialize an empty string to store the compressed string
    compressed_str = ""
    # Iterate over the input string starting from the second character
    for char in input_str[1:]:
        # If the current character is the same as the previous one, increment the count
        if char == current_char:
            current_count += 1
        # If the current character is different from the previous one, append the previous character and its count to the compressed string
        else:
            compressed_str += current_char + str(current_count)
            current_char = char
            current_count = 1
    # Append the last character and its count to the compressed string
    compressed_str += current_char + str(current_count)
