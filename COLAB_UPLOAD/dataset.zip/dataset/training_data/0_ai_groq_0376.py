from typing import Dict, List, Optional
class Graph:
    """
    A class representing a graph data structure.
    ----------
    adjacency_list : Dict[str, List[str]]
        The adjacency list representation of the graph.
    """
    def __init__(self):
        """
        Initializes an empty graph.
        """
        self.adjacency_list: Dict[str, List[str]] = {}
    def add_vertex(self, vertex: str):
        """
        Adds a new vertex to the graph.
        ----------
        vertex : str
            The vertex to add.
        """
        if vertex not in self.adjacency_list:
            self.adjacency_list[vertex] = []
    def add_edge(self, vertex1: str, vertex2: str):
        """
        Adds a new edge between two vertices in the graph.
        ----------
        vertex1 : str
            The first vertex.
        vertex2 : str
            The second vertex.
        """
        if vertex1 in self.adjacency_list and vertex2 in self.adjacency_list:
            self.adjacency_list[vertex1].append(vertex2)