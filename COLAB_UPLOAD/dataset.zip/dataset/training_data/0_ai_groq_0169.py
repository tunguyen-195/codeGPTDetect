def shell_sort(arr: list[int], gap_sequence: list[int]):
    """
    Sorts an array using Shell Sort with a custom gap sequence.
    list[int]: The sorted array.
    Time Complexity:
    The time complexity of Shell Sort depends on the gap sequence used. 
    For the Hibbard sequence, it is O(n log n) on average, but can be O(n^2) in the worst case for other sequences.
    The time complexity of this implementation is O(n * sum(gap_sequence)), where n is the length of the array.
    ValueError: If the input array is empty or the gap sequence is empty or contains non-positive values.
    """
    # Check if the input array is empty
    if not arr:
        raise ValueError("Input array is empty")
    # Check if the gap sequence is empty or contains non-positive values
    if not gap_sequence or any(gap <= 0 for gap in gap_sequence):
        raise ValueError("Gap sequence is empty or contains non-positive values")
    # Iterate over each gap in the gap sequence
    for gap in gap_sequence:
        # Perform insertion sort for the current gap
        for i in range(gap, len(arr)):
            # Store the current element to be inserted
            temp = arr[i]
            # Initialize the index for the insertion sort
            j = i
            # Shift elements to the right until the correct position for the current element is found
            while j >= gap and arr[j - gap] > temp:
                arr[j] = arr[j - gap]
                j -= gap
