class Node:
    """
    A class representing a node in the AVL tree.
    """
    def __init__(self, value: int):
        """
        Initializes a new node with the given value.
        """
        self.value = value
        self.left = None
        self.right = None
        self.height = 1
class AVLTree:
    """
    A class representing an AVL tree.
    """
    def __init__(self):
        """
        Initializes an empty AVL tree.
        """
        self.root = None
    def get_height(self, node: Node):
        """
        Gets the height of the given node.
