def climb_stairs(n: int):
    """
    This function calculates the number of distinct ways to climb n stairs.
    
    
    int: The number of distinct ways to climb n stairs.
    
    Time Complexity: O(n)
    Space Complexity: O(1)
    """
    if n <= 2:
        # Base cases: 1 or 2 stairs can be climbed in 1 or 2 ways respectively.
        return n
    
    # Initialize variables to store the number of ways to climb i stairs.
    ways = [0] * (n + 1)
    ways[1] = 1  # 1 way to climb 1 stair.
    ways[2] = 2  # 2 ways to climb 2 stairs (1+1 or 2).
    
    # Calculate the number of ways to climb i stairs for i > 2.
    for i in range(3, n + 1):
        # The number of ways to climb i stairs is the sum of the number of ways to climb i-1 and i-2 stairs.
        ways[i] = ways[i - 1] + ways[i - 2]
    
    return ways[n]
# Example usage:
n = 4
print(f"The number of distinct ways to climb {n} stairs is: {climb_stairs(n)}")