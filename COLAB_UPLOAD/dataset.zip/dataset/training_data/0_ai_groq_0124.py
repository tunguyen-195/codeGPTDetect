def count_set_bits(n: int):
    """
    Counts the number of set bits in a given integer using bit manipulation.
    """
    # Check if input is an integer
    if not isinstance(n, int):
        raise TypeError("Input must be an integer.")
    # Initialize count of set bits
    count = 0
    # Continue the process until n becomes 0
    while n:
        # Perform bitwise AND operation with 1 to check if the least significant bit is set
        # If the result is 1, it means the bit is set, so increment the count
        count += n & 1
        
        # Right shift the number by 1 to move to the next bit
        n >>= 1
    return count
# Example usage
if __name__ == "__main__":
    num = 15  # Binary representation: 1111
    print(f"Number of set bits in {num} is: {count_set_bits(num)}")
    num = 16  # Binary representation: 10000
    print(f"Number of set bits in {num} is: {count_set_bits(num)}")