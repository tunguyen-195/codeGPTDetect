def insertion_sort(arr: list[int]):
    """
    Sorts an array using the insertion sort algorithm with binary search optimization.
    Time complexity:
    - Best: O(n log n) (when binary search is used)
    - Average: O(n^2) (when binary search is not used)
    - Worst: O(n^2)
    :param arr: The input array to be sorted
    :return: None
    """
    def binary_search(arr: list[int], target: int):
        """
        Performs a binary search on the sorted portion of the array.
        :param arr: The input array
        :param target: The target value to be searched
        :return: The index of the target value if found, -1 otherwise
        """
        low, high = 0, len(arr) - 1
        while low <= high:
            mid = (low + high) // 2
            if arr[mid] == target:
                return mid
            elif arr[mid] < target:
                low = mid + 1
            else:
                high = mid - 1
        return -1
    for i in range(1, len(arr)):
        key = arr[i]
        j = binary_search(arr[:i], key)
        if j == -1:
            # Insertion sort without binary search optimization
            j = 0
            while j < i and arr[j] > key:
                arr[j] = arr[j + 1]