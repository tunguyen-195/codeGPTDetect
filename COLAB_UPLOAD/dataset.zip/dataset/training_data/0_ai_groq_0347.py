import heapq
class PriorityQueue:
    """
    A Priority Queue implementation using the heapq module.
    This class provides methods to insert elements into the queue with a given priority,
    remove the highest priority element from the queue, and check if the queue is empty.
    """
    def __init__(self):
        """
        Initialize an empty priority queue.
        """
        self._queue = []
        self._index = 0
    def push(self, item: any, priority: int):
        """
        Insert an item into the priority queue with a given priority.
        :param item: The item to be inserted into the queue.
        :param priority: The priority of the item.
        :raises ValueError: If the priority is not a non-negative integer.
        """
        if not isinstance(priority, int) or priority < 0:
            raise ValueError("Priority must be a non-negative integer")
        heapq.heappush(self._queue, (-priority, self._index, item))
        self._index += 1
    def pop(self):
        """
        Remove and return the item with the highest priority from the queue.
        :raises IndexError: If the queue is empty.
        """
        if not self._queue:
            raise IndexError("Queue is empty")
        return heapq.heappop(self._queue)[-1]
