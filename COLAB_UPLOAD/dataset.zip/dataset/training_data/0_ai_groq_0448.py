from typing import Any
class CircularQueue:
    """
    A class representing a fixed-size circular queue.
    ----------
    size : int
        The maximum size of the queue.
    queue : list
        The underlying list representing the queue.
    front : int
        The index of the front element in the queue.
    rear : int
        The index of the rear element in the queue.
    is_full : bool
        Whether the queue is full.
    is_empty : bool
        Whether the queue is empty.
    """
    def __init__(self, size: int):
        """
        Initializes a new instance of the CircularQueue class.
        ----
        size : int
            The maximum size of the queue.
        ------
        ValueError
            If the size is less than 1.
        """
        if size < 1:
            raise ValueError("Size must be at least 1")
        self.size = size
        self.queue = [None] * size
        self.front = 0
        self.rear = 0