def find_duplicate(nums: list[int]):
    """
    Finds a duplicate number in an array using Floyd's Tortoise and Hare algorithm.
    - nums: A list of integers with a duplicate.
    - The duplicate number in the array.
    - ValueError: If the input list is empty or does not contain a duplicate.
    """
    # Check if the input list is empty
    if not nums:
        raise ValueError("Input list is empty")
    # Phase 1: Detecting the cycle using tortoise and hare algorithm
    # The tortoise moves one step at a time, while the hare moves two steps at a time
    tortoise = nums[0]
    hare = nums[0]
    while True:
        tortoise = nums[tortoise]
        hare = nums[nums[hare]]
        # If the tortoise and hare meet, we have found the cycle
        if tortoise == hare:
            break
    # Phase 2: Finding the start of the cycle
    # The tortoise starts from the beginning, and both the tortoise and hare move one step at a time
    tortoise = nums[0]
    while tortoise != hare:
        tortoise = nums[tortoise]
        hare = nums[hare]
    # The meeting point is the duplicate number
    return hare
def main():
    # Example usage
    nums = [1, 3, 4, 2, 2]
    try:
        duplicate = find_duplicate(nums)