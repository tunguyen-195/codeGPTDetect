import random
from typing import List
def quicksort(arr: List[int]):
    """
    Sorts an array using the QuickSort algorithm with random pivot selection.
    Time complexity:
    - Best case: O(n log n)
    - Average case: O(n log n)
    - Worst case: O(n^2)
    :param arr: The input array to be sorted
    :return: The sorted array
    """
    _quicksort_helper(arr, 0, len(arr) - 1)
    return arr
def _quicksort_helper(arr: List[int], low: int, high: int):
    """
    Recursive helper function for QuickSort.
    :param arr: The input array
    :param low: The low index of the current partition
    :param high: The high index of the current partition
    :return: None
    """
    if low < high:
        # Select a random pivot index
        pivot_index = random.randint(low, high)
        
        # Swap the pivot element with the last element in the partition
        arr[pivot_index], arr[high] = arr[high], arr[pivot_index]
        
        # Partition the array around the pivot
        pivot_final_index = _partition(arr, low, high)
        
        # Recursively sort the subarrays
        _quicksort_helper(arr, low, pivot_final_index - 1)
        _quicksort_helper(arr, pivot_final_index + 1, high)