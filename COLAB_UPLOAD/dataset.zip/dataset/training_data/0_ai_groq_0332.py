class Graph:
    """A class representing a graph with bridges."""
    def __init__(self, num_vertices: int):
        """
        Initialize the graph with a given number of vertices.
        """
        self.num_vertices = num_vertices
        self.adj_list = [[] for _ in range(num_vertices)]
        self.time = 0
        self.low = [0] * num_vertices
        self.parent = [-1] * num_vertices
        self.on_stack = [False] * num_vertices
        self.bridges = []
    def add_edge(self, u: int, v: int):
        """
        Add an edge between two vertices in the graph.
        """
        self.adj_list[u].append(v)
        self.adj_list[v].append(u)
    def dfs(self, u: int, visited: list):
        """
        Perform a Depth-First Search (DFS) from a given vertex.
        """
        self.time += 1
        self.low[u] = self.time
        self.on_stack[u] = True
        visited[u] = True
        for v in self.adj_list[u]:
            if not visited[v]:
                self.parent[v] = u
                self.dfs(v, visited)
                self.low[u] = min(self.low[u], self.low[v])
