class Node:
    """
    A class to represent a node in the Red-Black Tree.
    """
    def __init__(self, key: int, color: str = 'red'):
        """
        Initializes a Node object.
        """
        self.key = key
        self.color = color
        self.left = None
        self.right = None
        self.parent = None
class RedBlackTree:
    """
    A class to represent a Red-Black Tree.
    """
    def __init__(self):
        """
        Initializes a RedBlackTree object.
        """
        self.nil = Node(0, 'black')
        self.root = self.nil
    def pre_order(self, node: Node):
        """
        Performs a pre-order traversal of the tree.
        """
        if node != self.nil:
            print(f"Key: {node.key}, Color: {node.color}")
            self.pre_order(node.left)
            self.pre_order(node.right)
