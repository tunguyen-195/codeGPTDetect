from typing import Dict, List, Set
class DirectedGraph:
    """
    A class to represent a Directed Graph.
    ----------
    graph : Dict[int, List[int]]
        A dictionary representing the adjacency list of the graph.
    """
    def __init__(self):
        """
        Initializes an empty directed graph.
        """
        self.graph: Dict[int, List[int]] = {}
    def add_vertex(self, vertex: int):
        """
        Adds a vertex to the graph.
        ----
        vertex : int
            The vertex to be added.
        ------
        ValueError
            If the vertex is already in the graph.
        """
        if vertex in self.graph:
            raise ValueError("Vertex already exists in the graph")
        self.graph[vertex] = []
    def add_edge(self, source: int, destination: int):
        """
        Adds a directed edge from the source vertex to the destination vertex.
        ----
        source : int
            The source vertex.