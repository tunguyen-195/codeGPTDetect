from typing import Dict, List, Set
class Graph:
    """A class representing a graph."""
    
    def __init__(self, num_vertices: int):
        """
        Initialize a graph with the given number of vertices.
        
        """
        self.num_vertices = num_vertices
        self.adj_list: Dict[int, List[int]] = {i: [] for i in range(num_vertices)}
    def add_edge(self, u: int, v: int):
        """
        Add an edge between two vertices in the graph.
        
        """
        if u < 0 or u >= self.num_vertices or v < 0 or v >= self.num_vertices:
            raise ValueError("Vertex index out of range")
        self.adj_list[u].append(v)
        self.adj_list[v].append(u)
    def articulation_points(self):
        """
        Find articulation points in the graph.
        
        An articulation point is a vertex that, when removed, increases the number of connected components in the graph.
        
        Set[int]: A set of articulation points in the graph.
        """
        visited: Set[int] = set()
        disc: Dict[int, int] = {i: -1 for i in range(self.num_vertices)}
        low: Dict[int, int] = {i: float('inf') for i in range(self.num_vertices)}
        parent: Dict[int, int] = {i: -1 for i in range(self.num_vertices)}
        ap: Set[int] = set()
        time = 0