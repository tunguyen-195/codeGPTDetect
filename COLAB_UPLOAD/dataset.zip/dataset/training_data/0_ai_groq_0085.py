from collections import deque
from typing import List
def sliding_window_maximum(nums: List[int], k: int):
    """
    Returns the maximum value in each window of size k in the given list of numbers.
    - nums (List[int]): The list of numbers.
    - k (int): The size of the window.
    - List[int]: A list of maximum values in each window.
    - ValueError: If the window size is larger than the list of numbers.
    """
    if k > len(nums):
        raise ValueError("Window size cannot be larger than the list of numbers")
    # Initialize the result list and the deque to store indices of maximum values
    result = []
    max_indices = deque()
    # Iterate over the list of numbers
    for i, num in enumerate(nums):
        # Remove indices of smaller values from the back of the deque
        while max_indices and nums[max_indices[-1]] < num:
            max_indices.pop()
        # Add the current index to the deque
        max_indices.append(i)
        # Remove indices that are out of the current window from the front of the deque
        if max_indices[0] <= i - k:
            max_indices.popleft()
        # Add the maximum value in the current window to the result list
        if i >= k - 1:
            result.append(nums[max_indices[0]])
    return result
