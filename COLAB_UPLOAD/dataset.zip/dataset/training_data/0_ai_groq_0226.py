class Graph:
    """
    Represents a weighted graph using an adjacency list.
    """
    def __init__(self, num_vertices: int):
        """
        Initializes a new graph with the specified number of vertices.
        """
        self.num_vertices = num_vertices
        self.adjacency_list = {i: [] for i in range(num_vertices)}
    def add_edge(self, vertex1: int, vertex2: int, weight: int):
        """
        Adds a new edge to the graph.
        """
        if vertex1 < 0 or vertex1 >= self.num_vertices or vertex2 < 0 or vertex2 >= self.num_vertices:
            raise ValueError("Vertex out of range")
        # Add the edge to the adjacency list
        self.adjacency_list[vertex1].append((vertex2, weight))
        self.adjacency_list[vertex2].append((vertex1, weight))  # Comment this line for a directed graph
    def prim_mst(self):
        """
        Finds the minimum spanning tree of the graph using Prim's algorithm.
        """
        visited = [False] * self.num_vertices
        visited[0] = True  # Start with vertex 0
        mst = []
        edges = []
        # Add all edges from the starting vertex to the list of edges
        for neighbor, weight in self.adjacency_list[0]:
            edges.append((0, neighbor, weight))