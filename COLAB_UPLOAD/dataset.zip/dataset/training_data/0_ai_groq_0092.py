from typing import List, Dict
def topological_sort(graph: Dict[int, List[int]]):
    """
    Performs a topological sort on a directed acyclic graph (DAG) using depth-first search (DFS).
    graph: A dictionary representing the adjacency list of the graph, where each key is a node and its corresponding value is a list of its neighbors.
    A list of nodes in topologically sorted order. If the graph contains a cycle, raises a ValueError.
    """
    visited = set()  # Keeps track of visited nodes
    ordering = []  # Stores the topological ordering
    temp_visited = set()  # Temporarily keeps track of visited nodes during the current DFS path
    def dfs(node: int):
        """
        Recursive DFS function to traverse the graph and build the topological ordering.
        node: The current node being visited.
        """
        # If the node is already in the current DFS path, it means a cycle is detected
        if node in temp_visited:
            raise ValueError("Graph contains a cycle")
        # If the node is already visited, return immediately
        if node in visited:
            return
        # Mark the node as temporarily visited
        temp_visited.add(node)
        # Recursively visit all neighbors of the node
        for neighbor in graph.get(node, []):
            dfs(neighbor)
        # Mark the node as visited and add it to the ordering
        visited.add(node)
        ordering.append(node)
        # Remove the node from the temporary visited set