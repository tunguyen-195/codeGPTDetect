def unbounded_knapsack(capacity: int, weights: list, values: list):
    """
    Solve the unbounded knapsack problem using dynamic programming.
    int: Maximum value that can be put in a knapsack of capacity.
    ValueError: If weights or values are empty or if their lengths do not match.
    """
    # Check if weights and values are empty or if their lengths do not match
    if not weights or not values or len(weights) != len(values):
        raise ValueError("Weights and values must be non-empty lists of the same length")
    # Initialize a list to store the maximum value for each capacity from 0 to capacity
    max_values = [0] * (capacity + 1)
    # Iterate over each capacity from 1 to the maximum capacity
    for cap in range(1, capacity + 1):
        # Initialize the maximum value for the current capacity to 0
        max_val = 0
        # Iterate over each item
        for i, (weight, value) in enumerate(zip(weights, values)):
            # If the item's weight is less than or equal to the current capacity
            if weight <= cap:
                # Calculate the maximum value by taking the maximum of the current maximum value and the value of the current item plus the maximum value for the remaining capacity
                max_val = max(max_val, value + max_values[cap - weight])
        # Update the maximum value for the current capacity
        max_values[cap] = max_val
    # Return the maximum value for the maximum capacity
    return max_values[capacity]
# Example usage
if __name__ == "__main__":