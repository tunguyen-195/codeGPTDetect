def max_area(height: list[int]):
    """
    This function calculates the maximum area of water that can be trapped between two lines.
    The function uses a two-pointer approach, one starting from the beginning of the array and one from the end.
    It iteratively moves the pointer with the smaller height towards the other pointer, expanding the area.
    The maximum area is updated whenever a larger area is found.
    """
    # Initialize two pointers, one at the beginning and one at the end of the array
    left: int = 0
    right: int = len(height) - 1
    # Initialize the maximum area
    max_area: int = 0
    # Iterate until the two pointers meet
    while left < right:
        # Calculate the width of the current area
        width: int = right - left
        # Calculate the height of the current area (minimum of the two lines)
        current_height: int = min(height[left], height[right])
        # Calculate the current area
        current_area: int = width * current_height
        # Update the maximum area if the current area is larger
        max_area = max(max_area, current_area)
        # Move the pointer with the smaller height towards the other pointer
        if height[left] < height[right]:
            left += 1
        else:
            right -= 1
    # Return the maximum area
    return max_area