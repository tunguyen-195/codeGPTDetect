def max_area(height: list[int]):
    """
    Calculate the maximum area of water that can be trapped between lines.
    int: The maximum area of water that can be trapped.
    Time complexity: O(n), where n is the number of lines.
    """
    if not height:
        raise ValueError("Input list cannot be empty")
    # Initialize two pointers, one at the start and one at the end of the list
    left: int = 0
    right: int = len(height) - 1
    # Initialize the maximum area
    max_area: int = 0
    while left < right:
        # Calculate the width of the container
        width: int = right - left
        # Calculate the height of the container (minimum of the two lines)
        container_height: int = min(height[left], height[right])
        # Calculate the area of the container
        area: int = width * container_height
        # Update the maximum area if the current area is larger
        max_area = max(max_area, area)
        # Move the pointer of the shorter line towards the other pointer
        if height[left] < height[right]:
            left += 1
        else:
            right -= 1
    return max_area