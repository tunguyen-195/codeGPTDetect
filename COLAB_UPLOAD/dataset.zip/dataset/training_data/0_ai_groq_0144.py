import random
class Node:
    """Node class representing each element in the skip list."""
    
    def __init__(self, data: int, level: int):
        """
        Initialize a Node with given data and level.
        """
        self.data = data
        self.next = [None]*level
class SkipList:
    """Skip List class for efficient search operations."""
    
    def __init__(self, max_level: int = 16, p: float = 0.5):
        """
        Initialize a Skip List with given maximum level and probability.
        """
        self.max_level = max_level
        self.p = p
        self.level = 1
        self.header = Node('HEAD', max_level)
    def _random_level(self):
        """
        Generate a random level for a new node.
        int: A random level between 1 and max_level.
        """
        level = 1
        while random.random() < self.p and level < self.max_level:
            level += 1
        return level