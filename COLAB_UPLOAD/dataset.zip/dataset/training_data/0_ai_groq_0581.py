def unbounded_knapsack(weights: list[int], values: list[int], capacity: int):
    """
    Solve the Unbounded Knapsack problem using dynamic programming.
    int: The maximum value that can be put in a knapsack of capacity 'capacity'.
    Time Complexity: O(nW)
    Space Complexity: O(W)
    """
    # Initialize a list to store the maximum value that can be put in a knapsack of capacity i
    dp = [0] * (capacity + 1)
    # Iterate over each item
    for i, (weight, value) in enumerate(zip(weights, values)):
        # Iterate in reverse order to avoid overwriting previously computed values
        for j in range(capacity, weight - 1, -1):
            # Update the maximum value that can be put in a knapsack of capacity j
            dp[j] = max(dp[j], dp[j - weight] + value)
    # Return the maximum value that can be put in a knapsack of capacity 'capacity'
    return dp[capacity]
# Example usage
weights = [1, 2, 4, 2, 5]
values = [5, 3, 5, 2, 1]
capacity = 10
print(unbounded_knapsack(weights, values, capacity))  # Output: 16