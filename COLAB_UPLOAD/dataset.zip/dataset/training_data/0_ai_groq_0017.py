class BinaryHeap:
    """
    A class to implement Binary Heap with both min and max operations.
    """
    def __init__(self, heap_type: str = 'min'):
        """
        Initializes the BinaryHeap object.
        """
        self.heap = []
        if heap_type not in ['min', 'max']:
            raise ValueError("Invalid heap type. It should be either 'min' or 'max'.")
        self.heap_type = heap_type
    def insert(self, value: int):
        """
        Inserts a value into the heap.
        """
        self.heap.append(value)
        self._heapify_up(len(self.heap) - 1)
    def delete(self, value: int):
        """
        Deletes a value from the heap.
        ValueError: If the value is not found in the heap.
        """
        try:
            index = self.heap.index(value)
            self._swap(index, len(self.heap) - 1)
            self.heap.pop()