class SegmentTree:
    """
    A Segment Tree class to support range queries.
    Methods:
        __init__: Initializes the segment tree.
        query: Performs a range query.
        update: Updates a value in the array and the segment tree.
    """
    def __init__(self, array: list[int]):
        """
        Initializes the segment tree.
        """
        self.n = len(array)
        if self.n == 0:
            raise ValueError("Array cannot be empty")
        self.tree = [0] * (4 * self.n)
        self.array = array
        self.build_tree(0, 0, self.n - 1)
    def build_tree(self, node: int, start: int, end: int):
        """
        Builds the segment tree recursively.
        """
        if start == end:
            self.tree[node] = self.array[start]
        else:
            mid = (start + end) // 2
            self.build_tree(2 * node + 1, start, mid)
            self.build_tree(2 * node + 2, mid + 1, end)
            self.tree[node] = self.tree[2 * node + 1] + self.tree[2 * node + 2]
    def query(self, left: int, right: int):
        """
        Performs a range query.
