def interpolation_search(arr: list[int], target: int):
    """
    Interpolation search is an improved variant of Binary Search which works on sorted arrays.
    It is based on the idea that in a uniformly distributed array, the insertion point for a
    target value is in proportion to its value and the size of the array.
    """
    low: int = 0
    high: int = len(arr) - 1
    while low <= high and target >= arr[low] and target <= arr[high]:
        # Calculate the position using interpolation formula
        index: int = low + ((target - arr[low]) * (high - low)) // (arr[high] - arr[low])
        # Check if target is present at the calculated index
        if arr[index] == target:
            return index
        # If target is greater than the element at the calculated index, then it must be
        # in the right subarray, so we update the low index to the next index of the
        # calculated index
        elif arr[index] < target:
            low = index + 1
        # If target is smaller than the element at the calculated index, then it must be
        # in the left subarray, so we update the high index to the previous index of the
        # calculated index
        else:
            high = index - 1
    # If we exit the while loop without finding the target, it means the target is not
    # present in the array, so we return -1
    return -1
def main():
    """
    Example usage of the interpolation search function.
    """
    arr: list[int] = [10, 12, 13, 16, 18, 19, 20, 21, 22, 23, 24, 33, 35, 42, 47]