from typing import List
def find_permutations(input_string: str):
    """
    Generates all permutations of a given string.
    """
    if not isinstance(input_string, str):
        raise TypeError("Input must be a string.")
    if len(input_string) == 0:
        raise ValueError("Input string cannot be empty.")
    # Base case: If the string has only one character, return it as the only permutation
    if len(input_string) == 1:
        return [input_string]
    # Initialize an empty list to store the permutations
    permutations = []
    # Iterate over each character in the string
    for i, char in enumerate(input_string):
        # Remove the current character from the string
        remaining_string = input_string[:i] + input_string[i + 1:]
        # Generate all permutations of the remaining string
        for perm in find_permutations(remaining_string):
            # Add the current character at the beginning of each permutation
            permutations.append(char + perm)
    return permutations
# Example usage:
input_string = "abc"
print("Permutations of '{}'".format(input_string))
for perm in find_permutations(input_string):
    print(perm)