def longest_substring_without_repeating_characters(s: str):
    """
    This function finds the longest substring without repeating characters in a given string.
    """
    # Check if input is a string
    if not isinstance(s, str):
        raise TypeError("Input must be a string.")
    # Initialize variables to store the longest substring and its length
    longest_substring = ""
    max_length = 0
    # Initialize a set to store unique characters in the current substring
    unique_chars = set()
    # Initialize two pointers for the sliding window
    left = 0
    # Iterate over the string
    for right in range(len(s)):
        # While the current character is in the set of unique characters, remove the leftmost character
        while s[right] in unique_chars:
            unique_chars.remove(s[left])
            left += 1
        # Add the current character to the set of unique characters
        unique_chars.add(s[right])
        # Update the longest substring if the current substring is longer
        if right - left + 1 > max_length:
            max_length = right - left + 1
            longest_substring = s[left:right + 1]
    return longest_substring
def main():
    # Example usage
    print(longest_substring_without_repeating_characters("abcabcbb"))  # Output: "abc"
    print(longest_substring_without_repeating_characters("bbbbb"))  # Output: "b"