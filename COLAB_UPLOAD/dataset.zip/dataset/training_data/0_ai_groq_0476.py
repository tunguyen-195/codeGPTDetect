from typing import Dict, List, Any
class Graph:
    """
    A basic implementation of a graph using an adjacency list representation.
    - vertices (set): A set of all unique vertices in the graph.
    - adjacency_list (dict): A dictionary representing the adjacency list of the graph.
    """
    def __init__(self):
        """
        Initializes an empty graph.
        """
        self.vertices = set()
        self.adjacency_list: Dict[Any, List[Any]] = {}
    def add_vertex(self, vertex: Any):
        """
        Adds a vertex to the graph.
        - vertex (Any): The vertex to add.
        - ValueError: If the vertex is already in the graph.
        """
        if vertex in self.vertices:
            raise ValueError("Vertex already exists in the graph")
        self.vertices.add(vertex)
        self.adjacency_list[vertex] = []
    def add_edge(self, vertex1: Any, vertex2: Any):
        """
        Adds an edge between two vertices in the graph.
        - vertex1 (Any): The first vertex.
        - vertex2 (Any): The second vertex.
        - ValueError: If either vertex is not in the graph.
        """
        if vertex1 not in self.vertices or vertex2 not in self.vertices: