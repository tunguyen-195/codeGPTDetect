from collections import deque
from typing import Dict, List, Optional
class Graph:
    """
    Represents a graph data structure.
    """
    def __init__(self):
        """
        Initializes an empty graph.
        """
        self.adjacency_list: Dict[int, List[int]] = {}
    def add_node(self, node: int):
        """
        Adds a new node to the graph.
        node: The node to add.
        """
        if node not in self.adjacency_list:
            self.adjacency_list[node] = []
    def add_edge(self, node1: int, node2: int):
        """
        Adds a new edge between two nodes in the graph.
        node1: The first node.
        node2: The second node.
        """
        if node1 in self.adjacency_list and node2 in self.adjacency_list:
            self.adjacency_list[node1].append(node2)
            self.adjacency_list[node2].append(node1)
    def bfs_shortest_path(self, start_node: int, end_node: int):
        """
        Finds the shortest path between two nodes using Breadth-First Search.
        start_node: The starting node.
        end_node: The target node.