def binary_search(arr: list[int], target: int):
    """
    Searches for a target element in a sorted array using binary search algorithm.
    int: The index of the target element if found, -1 otherwise.
    TypeError: If the input array is not a list or contains non-integer values.
    ValueError: If the input array is not sorted in ascending order.
    """
    # Check if the input array is a list and contains only integers
    if not isinstance(arr, list) or not all(isinstance(x, int) for x in arr):
        raise TypeError("Input array must be a list of integers.")
    # Check if the input array is sorted in ascending order
    if arr != sorted(arr):
        raise ValueError("Input array must be sorted in ascending order.")
    # Initialize the search boundaries
    left, right = 0, len(arr) - 1
    # Continue searching while the search boundaries are valid
    while left <= right:
        # Calculate the middle index
        mid = (left + right) // 2
        # Check if the target element is found at the middle index
        if arr[mid] == target:
            return mid
        # If the target element is less than the middle element, update the right boundary
        elif arr[mid] > target:
            right = mid - 1
        # If the target element is greater than the middle element, update the left boundary
        else:
            left = mid + 1