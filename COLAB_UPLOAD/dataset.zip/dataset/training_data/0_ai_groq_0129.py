import json
def write_to_json(data: dict, filename: str):
    """
    Writes data to a JSON file with formatting.
    """
    # Check if the data is a dictionary
    if not isinstance(data, dict):
        raise TypeError("Data must be a dictionary")
    # Check if the filename is not empty
    if not filename:
        raise ValueError("Filename cannot be empty")
    try:
        # Open the file in write mode
        with open(filename, 'w') as file:
            # Use json.dump to write the data to the file with indentation for formatting
            json.dump(data, file, indent=4)
    except IOError as e:
        # Handle any IO errors that occur while writing to the file
        raise IOError(f"Error writing to file: {e}")
def main():
    """
    Example usage of the write_to_json function.
    """
    data = {
        "name": "John Doe",
        "age": 30,
        "city": "New York"
    }
    filename = "example.json"
    write_to_json(data, filename)
if __name__ == "__main__":
    main()