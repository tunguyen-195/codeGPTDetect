def longest_substring_without_repeating_chars(s: str):
    """
    Find the length of the longest substring without repeating characters in a given string.
    """
    if not isinstance(s, str):
        raise TypeError("Input must be a string.")
    # Initialize variables to keep track of the longest substring and the current substring
    longest_length = 0
    window_start = 0
    char_index_map = {}
    # Iterate over the string
    for window_end in range(len(s)):
        # Get the current character
        right_char = s[window_end]
        # If the current character is already in the map, update the window start
        if right_char in char_index_map and char_index_map[right_char] >= window_start:
            # Update the window start to the character's previous index + 1
            window_start = char_index_map[right_char] + 1
        # Update the character's index in the map
        char_index_map[right_char] = window_end
        # Update the longest length
        longest_length = max(longest_length, window_end - window_start + 1)
    return longest_length
# Example usage:
print(longest_substring_without_repeating_chars("abcabcbb"))  # Output: 3
print(longest_substring_without_repeating_chars("bbbbb"))  # Output: 1
print(longest_substring_without_repeating_chars("pwwkew"))  # Output: 3
print(longest_substring_without_repeating_chars(""))  # Output: 0
print(longest_substring_without_repeating_chars("a"))  # Output: 1