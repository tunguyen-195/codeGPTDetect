class Node:
    """
    A node in the linked list used for separate chaining in the hash table.
    
    """
    def __init__(self, key: any, value: any):
        """
        Initializes a new node with the given key and value.
        
        """
        self.key = key
        self.value = value
        self.next = None
class HashTable:
    """
    A hash table implementation using separate chaining for collision resolution.
    
    """
    def __init__(self, size: int):
        """
        Initializes a new hash table with the given size.
        
        
        ValueError: If the size is not a positive integer.
        """
        if not isinstance(size, int) or size <= 0:
            raise ValueError("Size must be a positive integer")
        self.size = size
        self.table = [None] * size
    def _hash_function(self, key: any):