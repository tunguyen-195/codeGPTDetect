def find_all_substrings(input_string: str):
    """
    Finds all possible substrings of a given input string.
    """
    # Check if input is a string
    if not isinstance(input_string, str):
        raise TypeError("Input must be a string.")
    # Check if input string is empty
    if len(input_string) == 0:
        raise ValueError("Input string cannot be empty.")
    # Initialize an empty list to store all substrings
    all_substrings = []
    # Iterate over the input string with two nested loops to generate all substrings
    for i in range(len(input_string)):
        # The outer loop determines the starting index of the substring
        for j in range(i + 1, len(input_string) + 1):
            # The inner loop determines the ending index of the substring
            # Append the substring from index i to j to the list
            all_substrings.append(input_string[i:j])
    return all_substrings
def main():
    try:
        input_str = "abc"
        substrings = find_all_substrings(input_str)
        print(f"All substrings of '{input_str}': {substrings}")
    except (TypeError, ValueError) as e:
        print(f"Error: {e}")
if __name__ == "__main__":
    main()