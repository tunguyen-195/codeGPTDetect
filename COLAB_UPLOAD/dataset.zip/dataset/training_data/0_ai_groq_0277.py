from collections import deque
class Graph:
    """
    A class to represent a graph using an adjacency list.
    
    ----------
    adjacency_list : dict
        A dictionary representing the adjacency list of the graph.
        
    Methods:
    -------
    add_edge(node1, node2)
        Adds an edge between two nodes in the graph.
    bfs_shortest_path(start_node, end_node)
        Performs Breadth-First Search to find the shortest path between two nodes.
    """
    def __init__(self):
        """
        Initializes an empty graph.
        """
        self.adjacency_list = {}
    def add_edge(self, node1, node2):
        """
        Adds an edge between two nodes in the graph.
        
        ----------
        node1 : any
            The first node of the edge.
        node2 : any
            The second node of the edge.
        
        ------
        ValueError
            If either node is not in the graph.
        """
        if node1 not in self.adjacency_list:
            self.adjacency_list[node1] = []