def coin_change_ways(coins: list[int], amount: int):
    """
    Calculate the number of ways to make the given amount using the provided coins.
    int: The number of ways to make the given amount.
    ValueError: If the amount is negative.
    """
    if amount < 0:
        raise ValueError("Amount cannot be negative.")
    # Initialize a list to store the number of ways for each amount from 0 to the target amount
    ways = [0] * (amount + 1)
    ways[0] = 1  # There is 1 way to make 0 amount (use no coins)
    # Iterate over each coin denomination
    for coin in coins:
        # Iterate over each amount from the coin denomination to the target amount
        for i in range(coin, amount + 1):
            # The number of ways to make the current amount is the sum of the number of ways to make the current amount without using the current coin and the number of ways to make the amount minus the current coin
            ways[i] += ways[i - coin]
    return ways[amount]
# Example usage
coins = [1, 2, 5]
amount = 5
print(f"Number of ways to make {amount} using coins {coins}: {coin_change_ways(coins, amount)}")