def is_power_of_two(n: int):
    """
    Checks if a given number is a power of two using bit manipulation.
    """
    # Check if input is an integer
    if not isinstance(n, int):
        raise TypeError("Input must be an integer.")
    # A number is a power of two if it has exactly one bit set to 1 in its binary representation
    # We can use the bitwise AND operator (&) to check this
    # If a number is a power of two, then it will have no bits in common with the number one less than it
    # For example, 8 (1000) and 7 (0111) have no bits in common
    return n > 0 and (n & (n - 1)) == 0
# Example usage:
if __name__ == "__main__":
    print(is_power_of_two(8))  # True
    print(is_power_of_two(10))  # False