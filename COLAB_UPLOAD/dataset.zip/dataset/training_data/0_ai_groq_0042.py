from collections import deque
from typing import Dict, List, Tuple
def bfs_shortest_path(graph: Dict[str, List[str]], start: str, end: str):
    """
    Performs a breadth-first search to find the shortest path between two nodes in a graph.
    """
    # Check if the start and end nodes are in the graph
    if start not in graph:
        raise ValueError("Start node not in graph")
    if end not in graph:
        raise ValueError("End node not in graph")
    # Create a queue for BFS, enqueue the start node
    queue = deque([[start]])
    # Create a set to store visited nodes
    visited = set()
    while queue:
        # Dequeue the first path from the queue
        path = queue.popleft()
        # Get the last node from the path
        node = path[-1]
        # If the node is not visited, mark it as visited
        if node not in visited:
            visited.add(node)
            # If the node is the end node, return the path and its length
            if node == end:
                return path, len(path) - 1
            # Get the neighbors of the node
            neighbors = graph.get(node, [])
            # For each neighbor, create a new path and enqueue it