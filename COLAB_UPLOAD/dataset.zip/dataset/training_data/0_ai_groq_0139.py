class TrieNode:
    """A node in the Trie data structure."""
    
    def __init__(self):
        """Initialize a TrieNode with an empty dictionary to store children and a boolean to mark the end of a word."""
        self.children: dict[str, 'TrieNode'] = {}
        self.is_end_of_word: bool = False
class Trie:
    """A Trie (Prefix Tree) data structure for autocomplete functionality."""
    
    def __init__(self):
        """Initialize a Trie with a root node."""
        self.root: TrieNode = TrieNode()
    def insert(self, word: str):
        """
        Insert a word into the Trie.
        """
        current_node: TrieNode = self.root
        for char in word:
            # If the character is not in the current node's children, add it
            if char not in current_node.children:
                current_node.children[char] = TrieNode()
            # Move to the child node
            current_node = current_node.children[char]
        # Mark the end of the word
        current_node.is_end_of_word = True
    def search(self, word: str):
        """
        Search for a word in the Trie.
        """
        current_node: TrieNode = self.root
        for char in word:
            # If the character is not in the current node's children, the word is not in the Trie
            if char not in current_node.children:
                return False