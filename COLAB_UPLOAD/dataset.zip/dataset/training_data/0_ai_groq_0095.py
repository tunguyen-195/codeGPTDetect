from typing import List, Dict, Tuple
def kosaraju(graph: Dict[int, List[int]]):
    """
    This function implements Kosaraju's algorithm to find strongly connected components in a graph.
    graph: A dictionary representing the graph, where each key is a node and its corresponding value is a list of its neighbors.
    A list of lists, where each sublist contains nodes that are strongly connected to each other.
    """
    
    # Step 1: Get the transpose of the graph
    transpose_graph = transpose(graph)
    
    # Step 2: Perform DFS on the original graph to fill the stack with a vertex
    visited = set()
    stack = []
    for vertex in graph:
        if vertex not in visited:
            fill_stack(graph, vertex, visited, stack)
    
    # Step 3: Perform DFS on the transpose graph in the order of the stack
    visited = set()
    strongly_connected_components = []
    while stack:
        vertex = stack.pop()
        if vertex not in visited:
            component = []
            dfs(transpose_graph, vertex, visited, component)
            strongly_connected_components.append(component)
    
    return strongly_connected_components
def transpose(graph: Dict[int, List[int]]):
    """
    This function returns the transpose of a graph.
    graph: A dictionary representing the graph, where each key is a node and its corresponding value is a list of its neighbors.
    A dictionary representing the transpose of the graph.