def are_anagrams(str1: str, str2: str):
    """
    Checks if two input strings are anagrams of each other.
    """
    # Check if both inputs are strings
    if not isinstance(str1, str) or not isinstance(str2, str):
        raise TypeError("Both inputs must be strings")
    # Remove any leading/trailing whitespaces from the input strings
    str1 = str1.strip()
    str2 = str2.strip()
    # If the strings are not of the same length, they cannot be anagrams
    if len(str1) != len(str2):
        return False
    # Convert the strings to lowercase to make the comparison case-insensitive
    str1 = str1.lower()
    str2 = str2.lower()
    # Sort the characters in each string and compare the results
    # If the sorted strings are equal, the original strings are anagrams
    return sorted(str1) == sorted(str2)