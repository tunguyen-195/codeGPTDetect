def find_median(nums1: list[int], nums2: list[int]):
    """
    Finds the median of two sorted arrays.
    - nums1 (list[int]): The first sorted array.
    - nums2 (list[int]): The second sorted array.
    - float: The median of the combined array.
    - ValueError: If either input array is empty.
    """
    if not nums1 or not nums2:
        raise ValueError("Input arrays cannot be empty")
    # Merge the two sorted arrays into one
    merged = []
    i, j = 0, 0
    while i < len(nums1) and j < len(nums2):
        if nums1[i] < nums2[j]:
            merged.append(nums1[i])
            i += 1
        else:
            merged.append(nums2[j])
            j += 1
    # Append any remaining elements from nums1 and nums2
    merged.extend(nums1[i:])
    merged.extend(nums2[j:])
    # Calculate the median
    n = len(merged)
    if n % 2 == 0:  # Even number of elements
        median = (merged[n // 2 - 1] + merged[n // 2]) / 2
    else:  # Odd number of elements
        median = merged[n // 2]
    return median