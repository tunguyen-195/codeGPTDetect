def bubble_sort(arr: list[int]):
    """
    Sorts an array in ascending order using the Bubble Sort algorithm.
    This implementation includes early termination, which stops the algorithm
    once no more swaps are needed, indicating that the array is already sorted.
    Time complexity:
        - Best-case: O(n) when the array is already sorted
        - Average-case: O(n^2) when the array is randomly ordered
        - Worst-case: O(n^2) when the array is reverse sorted
    """
    n = len(arr)
    for i in range(n - 1):
        # Create a flag that will allow the function to terminate early if there's nothing left to sort
        swapped = False
        for j in range(n - i - 1):
            # If the current element is greater than the next element, swap them
            if arr[j] > arr[j + 1]:
                arr[j], arr[j + 1] = arr[j + 1], arr[j]
                # Set the flag to True so we'll loop again
                swapped = True
        # If no two elements were swapped by the inner loop, the array is sorted and we can terminate
        if not swapped:
            break
    return arr
# Example usage:
arr = [64, 34, 25, 12, 22, 11, 90]
print("Original array:", arr)
print("Sorted array:", bubble_sort(arr))