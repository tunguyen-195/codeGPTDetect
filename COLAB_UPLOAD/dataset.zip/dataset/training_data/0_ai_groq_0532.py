from typing import Dict, List, Tuple
class Graph:
    """A class representing a graph with bridges."""
    def __init__(self, num_vertices: int):
        """Initialize the graph with a given number of vertices."""
        self.num_vertices = num_vertices
        self.adj_list: Dict[int, List[int]] = {i: [] for i in range(num_vertices)}
        self.time = 0
        self.low = [0] * num_vertices
        self.parent = [-1] * num_vertices
        self.art_points = set()
    def add_edge(self, u: int, v: int):
        """Add an edge between two vertices."""
        self.adj_list[u].append(v)
        self.adj_list[v].append(u)
    def dfs(self, u: int, visited: List[bool], stack: List[int]):
        """Perform a depth-first search from a given vertex."""
        visited[u] = True
        stack.append(u)
        self.low[u] = self.time
        self.time += 1
        for v in self.adj_list[u]:
            if not visited[v]:
                self.parent[v] = u
                self.dfs(v, visited, stack)
                self.low[u] = min(self.low[u], self.low[v])
                if self.low[v] > self.low[u]:
                    self.art_points.add((u, v))
            elif v != self.parent[u]:
                self.low[u] = min(self.low[u], self.low[v])
    def find_bridges(self):
        """Find all bridges in the graph."""
        visited = [False] * self.num_vertices
        stack = []
        self.dfs(0, visited, stack)