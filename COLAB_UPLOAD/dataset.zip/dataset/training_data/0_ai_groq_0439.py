class TrieNode:
    """A node in the Trie data structure."""
    
    def __init__(self):
        """Initialize a new Trie node."""
        self.children = {}  # Mapping of character to child node
        self.is_end_of_word = False  # Flag indicating if this node is the end of a word
class Trie:
    """A Trie data structure for autocomplete functionality."""
    
    def __init__(self):
        """Initialize a new Trie."""
        self.root = TrieNode()
    def insert(self, word: str):
        """Insert a word into the Trie.
        """
        node = self.root
        for char in word:
            if char not in node.children:
                node.children[char] = TrieNode()
            node = node.children[char]
        node.is_end_of_word = True
    def search(self, word: str):
        """Search for a word in the Trie.
        bool: True if the word is found, False otherwise.
        """
        node = self.root
        for char in word:
            if char not in node.children:
                return False
            node = node.children[char]
        return node.is_end_of_word