from typing import Dict, List, Set
class Graph:
    """Represents a directed graph using adjacency list representation."""
    def __init__(self):
        """Initializes an empty graph."""
        self.adjacency_list: Dict[int, List[int]] = {}
    def add_edge(self, u: int, v: int):
        """Adds a directed edge from node u to node v.
        """
        if u not in self.adjacency_list:
            self.adjacency_list[u] = []
        self.adjacency_list[u].append(v)
    def topological_sort(self):
        """Performs a topological sort on the graph using DFS.
        """
        visited: Set[int] = set()
        ordering: List[int] = []
        for node in self.adjacency_list:
            if node not in visited:
                self._dfs(node, visited, ordering)
        return ordering[::-1]
    def _dfs(self, node: int, visited: Set[int], ordering: List[int]):
        """Performs a depth-first search from the given node.
        """
        visited.add(node)
        for neighbor in self.adjacency_list[node]:
            if neighbor not in visited:
                self._dfs(neighbor, visited, ordering)
        ordering.append(node)
# Example usage:
if __name__ == "__main__":