def rotate_array(arr: list, k: int):
    """
    Rotate the input array to the right by k positions.
    """
    # Check if arr is a list and k is an integer
    if not isinstance(arr, list) or not isinstance(k, int):
        raise TypeError("arr must be a list and k must be an integer")
    # Check if k is a non-negative integer
    if k < 0:
        raise ValueError("k must be a non-negative integer")
    # Use Python's list slicing feature to rotate the array
    # The expression arr[-k:] gets the last k elements of the array
    # The expression arr[:-k] gets all elements except the last k elements
    # By concatenating these two expressions, we effectively rotate the array to the right by k positions
    rotated_arr = arr[-k:] + arr[:-k]
    return rotated_arr
# Example usage:
arr = [1, 2, 3, 4, 5]
k = 2
print(rotate_array(arr, k))  # Output: [4, 5, 1, 2, 3]
arr = [1, 2, 3, 4, 5]
k = 7
print(rotate_array(arr, k))  # Output: [4, 5, 1, 2, 3]
arr = [1, 2, 3, 4, 5]
k = -2
try:
    print(rotate_array(arr, k))
except ValueError as e:
    print(e)  # Output: k must be a non-negative integer
arr = '12345'
k = 2