import heapq
class Graph:
    """Represents a graph with weighted edges."""
    def __init__(self):
        self.nodes = set()
        self.edges = {}
    def add_node(self, node):
        """Adds a node to the graph."""
        self.nodes.add(node)
        if node not in self.edges:
            self.edges[node] = {}
    def add_edge(self, node1, node2, weight):
        """Adds a weighted edge between two nodes."""
        if node1 in self.nodes and node2 in self.nodes:
            self.edges[node1][node2] = weight
            self.edges[node2][node1] = weight  # For undirected graph
        else:
            raise ValueError("Both nodes must exist in the graph.")
    def dijkstra(self, start_node):
        """
        Finds the shortest path from the start node to all other nodes using Dijkstra's algorithm.
        """
        if start_node not in self.nodes:
            raise ValueError("Start node must exist in the graph.")
        # Initialize distances and previous nodes
        distances = {node: float('inf') for node in self.nodes}
        previous_nodes = {node: None for node in self.nodes}
        distances[start_node] = 0  # Distance to the start node is 0
        # Create a priority queue
        priority_queue = [(0, start_node)]  # (distance, node)
        while priority_queue:
            # Extract the node with the minimum distance