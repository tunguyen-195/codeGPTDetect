from collections import defaultdict, deque
class Graph:
    """Represents a directed acyclic graph (DAG) with nodes and edges."""
    
    def __init__(self):
        """Initializes an empty graph."""
        self.adjacency_list = defaultdict(list)
        self.in_degree = defaultdict(int)
        self.nodes = set()
    def add_edge(self, node1: str, node2: str):
        """Adds a directed edge from node1 to node2."""
        
        # Add nodes to the graph if they don't exist
        self.nodes.add(node1)
        self.nodes.add(node2)
        
        # Update in-degree of node2
        self.in_degree[node2] += 1
        
        # Add edge to adjacency list
        self.adjacency_list[node1].append(node2)
    def topological_sort(self):
        """Performs a topological sort on the graph using DFS."""
        
        # Initialize queue with nodes having in-degree 0
        queue = deque([node for node in self.nodes if self.in_degree[node] == 0])
        
        # Initialize result list
        result = []
        
        while queue:
            # Dequeue a node
            node = queue.popleft()
            
            # Add node to result list
            result.append(node)
            