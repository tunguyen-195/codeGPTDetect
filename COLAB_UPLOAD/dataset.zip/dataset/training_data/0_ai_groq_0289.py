class Fibonacci:
    """
    A class for calculating Fibonacci numbers using memoization.
    
    ----------
    memo : dict
        A dictionary to store the Fibonacci numbers for memoization.
        
    Methods:
    -------
    calculate(n: int) -> int
        Calculates the nth Fibonacci number using memoization.
    """
    def __init__(self):
        """
        Initializes the Fibonacci class with a dictionary for memoization.
        """
        self.memo = {0: 0, 1: 1}
    def calculate(self, n: int):
        """
        Calculates the nth Fibonacci number using memoization.
        
        ----------
        n : int
            The position of the Fibonacci number to calculate.
        
        -------
        int
            The nth Fibonacci number.
        
        ------
        ValueError
            If n is a negative integer.
        """
        if n < 0:
            raise ValueError("n must be a non-negative integer.")
        
        # Base case: If the Fibonacci number is already in the memo dictionary, return it.