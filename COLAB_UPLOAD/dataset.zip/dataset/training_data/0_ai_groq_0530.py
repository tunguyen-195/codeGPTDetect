from typing import List, Dict
class Graph:
    """Represents a directed graph using an adjacency list."""
    
    def __init__(self):
        """Initializes an empty graph."""
        self.adj_list: Dict[int, List[int]] = {}
    
    def add_edge(self, src: int, dst: int):
        """Adds a directed edge from src to dst."""
        if src not in self.adj_list:
            self.adj_list[src] = []
        self.adj_list[src].append(dst)
    
    def dfs(self, visited: List[bool], stack: List[int], vertex: int):
        """Performs a depth-first search from the given vertex."""
        visited[vertex] = True
        for neighbor in self.adj_list[vertex]:
            if not visited[neighbor]:
                self.dfs(visited, stack, neighbor)
        stack.append(vertex)
    
    def get_reversed_graph(self):
        """Returns a reversed version of the graph."""
        reversed_graph = Graph()
        for src in self.adj_list:
            for dst in self.adj_list[src]:
                reversed_graph.add_edge(dst, src)
        return reversed_graph
    
    def kosaraju(self):
        """Finds strongly connected components in the graph."""
        visited = [False] * len(self.adj_list)
        stack = []
        for vertex in range(len(self.adj_list)):
            if not visited[vertex]:
                self.dfs(visited, stack, vertex)
        
        reversed_graph = self.get_reversed_graph()