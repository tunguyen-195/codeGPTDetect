def house_robber(nums: list[int]):
    """
    This function solves the House Robber problem using dynamic programming.
    
    Time Complexity:
        O(n), where n is the number of houses.
        
    Space Complexity:
        O(n), where n is the number of houses.
    """
    
    if not nums:
        # If the list of houses is empty, return 0.
        return 0
    
    # Initialize a list to store the maximum amount of money that can be stolen up to each house.
    dp = [0] * len(nums)
    
    # The maximum amount of money that can be stolen from the first house is the amount in the first house.
    dp[0] = nums[0]
    
    # Iterate over the list of houses starting from the second house.
    for i in range(1, len(nums)):
        # For each house, the maximum amount of money that can be stolen is the maximum of the amount in the current house
        # plus the maximum amount of money that can be stolen from the houses before the second last house,
        # and the maximum amount of money that can be stolen from the houses before the current house.
        dp[i] = max(dp[i-1], dp[i-1] + nums[i])
    
    # The maximum amount of money that can be stolen from all houses is stored in the last element of the dp list.
    return dp[-1]
# Example usage:
nums = [1, 2, 3, 1]
print(house_robber(nums))  # Output: 4
nums = [1, 7, 1, 5, 9, 2]
print(house_robber(nums))  # Output: 16