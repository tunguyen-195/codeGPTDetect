def longest_increasing_subsequence(nums: list[int]):
    """
    This function returns the length of the longest increasing subsequence in a given list of numbers.
    int: The length of the longest increasing subsequence.
    Time Complexity: O(n^2)
    Space Complexity: O(n)
    """
    if not nums:
        return 0
    n = len(nums)
    dp = [1] * n  # Initialize dp array with 1s
    for i in range(1, n):
        # For each element in the list, compare it with all previous elements
        for j in range(i):
            # If the current element is greater than the previous element, update the dp array
            if nums[i] > nums[j]:
                dp[i] = max(dp[i], dp[j] + 1)
        # Update the maximum length of the subsequence
        dp[i] = max(dp[i], 1)
    return max(dp)
# Example usage
if __name__ == "__main__":
    nums = [10, 22, 9, 33, 21, 50, 41, 60]
    print("Length of the longest increasing subsequence is:", longest_increasing_subsequence(nums))