from typing import Dict, List
class Graph:
    """
    A class to represent an undirected graph.
    -----------
    num_vertices : int
        The number of vertices in the graph.
    adjacency_list : Dict[int, List[int]]
        The adjacency list representation of the graph.
    Methods:
    --------
    add_edge(u: int, v: int)
        Adds an edge between vertices u and v.
    cycle_detection()
        Detects whether a cycle exists in the graph using DFS.
    """
    def __init__(self, num_vertices: int):
        """
        Initializes an empty graph with the given number of vertices.
        -----
        num_vertices : int
            The number of vertices in the graph.
        """
        self.num_vertices = num_vertices
        self.adjacency_list = {i: [] for i in range(num_vertices)}
    def add_edge(self, u: int, v: int):
        """
        Adds an edge between vertices u and v.
        -----
        u : int
            The source vertex.
        v : int
            The destination vertex.