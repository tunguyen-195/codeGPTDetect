def rotate_array(nums: list[int], k: int):
    """
    Rotate the input array to the right by k positions.
    - nums (list[int]): The input array to be rotated.
    - k (int): The number of positions to rotate the array to the right.
    - None
    """
    if not nums:
        return
    k = k % len(nums)  # Handle cases where k is greater than the length of the array
    nums[:] = nums[-k:] + nums[:-k]  # Rotate the array using Python's list slicing feature