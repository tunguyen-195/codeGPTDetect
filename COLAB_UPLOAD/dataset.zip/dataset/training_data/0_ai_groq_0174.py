def jump_search(arr: list, target: int):
    """
    Jump Search algorithm implementation for sorted arrays.
    This algorithm works by skipping a certain number of elements in the array 
    and then performing a linear search for the target element in the block 
    where it is expected to be.
    """
    # Check if the input array is empty
    if not arr:
        raise ValueError("Input array is empty")
    # Check if the input array is sorted
    if arr != sorted(arr):
        raise ValueError("Input array is not sorted")
    # Calculate the block size to be jumped
    block_size = int(len(arr) ** 0.5)
    # Initialize the left and right pointers
    left, right = 0, 0
    # Find the block where the target element is expected to be
    while right < len(arr) and arr[right] <= target:
        # Move the left pointer to the start of the current block
        left = right
        # Move the right pointer to the end of the next block
        right += block_size
    # If the right pointer exceeds the array length, set it to the last index
    if right > len(arr) - 1:
        right = len(arr) - 1
    # Perform a linear search for the target element in the block
    index = left
    while index <= right and arr[index] <= target:
        # Check if the target element is found
        if arr[index] == target:
            return index