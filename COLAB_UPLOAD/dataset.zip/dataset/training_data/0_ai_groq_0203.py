def longest_common_prefix(strs: list[str]):
    """
    Finds the longest common prefix among a list of strings.
    """
    # Check for edge case where input list is empty
    if not strs:
        raise ValueError("Input list is empty")
    # Sort the list of strings to easily find the common prefix
    # This is because the common prefix will be the same in the first and last string
    strs.sort()
    # Get the first and last string in the sorted list
    first_str = strs[0]
    last_str = strs[-1]
    # Initialize the common prefix and the index to check
    common_prefix = ""
    i = 0
    # Loop through the characters of the first string
    while i < len(first_str):
        # If the character at the current index is the same in both strings, add it to the common prefix
        if i < len(last_str) and first_str[i] == last_str[i]:
            common_prefix += first_str[i]
            i += 1
        # If the characters are different, break the loop
        else:
            break
    return common_prefix
# Example usage:
print(longest_common_prefix(["flower","flow","flight"]))  # Output: "fl"
print(longest_common_prefix(["dog","racecar","car"]))  # Output: ""
print(longest_common_prefix([]))  # Raises ValueError