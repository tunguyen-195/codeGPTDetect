def jump_search(arr: list[int], x: int):
    """
    Jump Search algorithm for sorted arrays.
    int: The index of the target element if found, -1 otherwise.
    """
    # Calculate the jump size, which is the square root of the array length
    jump_size = int(len(arr) ** 0.5)
    # Find the block where the element is present (if it is present)
    # using the jump size
    i = 0
    while i <= len(arr) - jump_size and arr[i + jump_size - 1] < x:
        i += jump_size
    # If we reached the end of the array without finding the element,
    # it's not in the array
    if i + jump_size - 1 >= len(arr):
        return -1
    # Perform a linear search for the element in the block
    # where we think it might be
    l = i
    r = i + jump_size - 1
    while l <= r and arr[l] <= x:
        if arr[l] == x:
            return l
        l += 1
    # If the element is not found in the block, return -1
    return -1
def main():
    # Example usage
    arr = [0, 1, 1, 2, 3, 5, 8, 13, 21, 34, 55, 89, 144, 233, 377, 610]
    x = 55