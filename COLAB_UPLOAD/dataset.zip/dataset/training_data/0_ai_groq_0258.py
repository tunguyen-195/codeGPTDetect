class HashMapOpenAddressing:
    """
    A HashMap implementation using open addressing.
    
    """
    
    def __init__(self, size: int = 128):
        """
        Initializes a new instance of the HashMapOpenAddressing class.
        
        """
        self.size = size
        self.table = [None] * size
        self.load_factor = 0
        self.threshold = 0.7  # 70% load factor for resizing
    def _hash(self, key: int):
        """
        Computes the hash value for a given key.
        
        
        int: The hash value.
        """
        return key % self.size
    def _probe(self, index: int):
        """
        Computes the next probe index.
        
        
        int: The next probe index.
        """
        return (index + 1) % self.size