def selection_sort(arr: list[int]):
    """
    Sorts an array in ascending order using the Selection Sort algorithm.
    Time complexity:
    - Best case: O(n^2) when the array is already sorted
    - Average case: O(n^2) for random input
    - Worst case: O(n^2) when the array is sorted in reverse order
    Space complexity: O(1) as it only uses a constant amount of space
    :param arr: The input array to be sorted
    :return: The sorted array
    """
    # Check if input is a list
    if not isinstance(arr, list):
        raise ValueError("Input must be a list")
    # Check if list is empty
    if len(arr) == 0:
        return arr
    # Iterate over the array
    for i in range(len(arr)):
        # Assume the current element is the smallest
        min_idx = i
        # Check all other elements in the unsorted part of the array
        for j in range(i + 1, len(arr)):
            # If a smaller element is found, update min_idx
            if arr[j] < arr[min_idx]:
                min_idx = j
        # Swap the smallest element with the current element
        arr[i], arr[min_idx] = arr[min_idx], arr[i]
    return arr
# Example usage