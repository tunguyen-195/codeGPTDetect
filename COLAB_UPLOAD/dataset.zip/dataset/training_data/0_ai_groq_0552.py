class BinaryHeap:
    """
    A BinaryHeap class that implements both min and max binary heap operations.
    
    """
    def __init__(self, min_heap: bool = True):
        """
        Initializes a new BinaryHeap instance.
        
        """
        self.heap = []
        self.min_heap = min_heap
    def insert(self, value: int):
        """
        Inserts a new value into the heap.
        
        
        TypeError: If the value is not an integer.
        """
        if not isinstance(value, int):
            raise TypeError("Value must be an integer.")
        
        self.heap.append(value)
        self._heapify_up(len(self.heap) - 1)
    def delete(self, value: int):
        """
        Deletes a value from the heap.
        
        
        ValueError: If the value is not found in the heap.
        TypeError: If the value is not an integer.
        """