def find_duplicate(nums: list[int]):
    """
    Finds the duplicate number in the given array.
    This function uses Floyd's Tortoise and Hare (Cycle Detection) algorithm to find the duplicate number in O(n) time complexity.
    """
    # Phase 1: Detecting the cycle using tortoise and hare algorithm
    tortoise = nums[0]
    hare = nums[0]
    while True:
        tortoise = nums[tortoise]
        hare = nums[nums[hare]]
        if tortoise == hare:
            break
    # Phase 2: Finding the start of the cycle
    ptr1 = nums[0]
    ptr2 = tortoise
    while ptr1 != ptr2:
        ptr1 = nums[ptr1]
        ptr2 = nums[ptr2]
    return ptr1
def main():
    nums = [1, 3, 4, 2, 2]
    print("Duplicate number:", find_duplicate(nums))
if __name__ == "__main__":
    main()