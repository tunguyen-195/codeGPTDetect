class Node:
    """
    A class to represent a node in the circular linked list.
    """
    def __init__(self, value: any):
        """
        Initializes a new node with the given value.
        """
        self.value = value
        self.next = None
class CircularLinkedList:
    """
    A class to represent a circular linked list.
    """
    def __init__(self):
        """
        Initializes an empty circular linked list.
        """
        self.head = None
        self.size = 0
    def __len__(self):
        """
        Returns the number of elements in the list.
        int: The number of elements in the list.
        """
        return self.size
