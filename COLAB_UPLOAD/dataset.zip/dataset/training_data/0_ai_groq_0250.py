class MinHeap:
    """
    A binary heap implementation with a focus on minimization.
    The MinHeap class supports the following operations:
    - insert: Add a new element to the heap while maintaining the heap property.
    - extract_min: Remove and return the minimum element from the heap.
    """
    def __init__(self):
        """
        Initialize an empty MinHeap.
        """
        self.heap = []
    def insert(self, value: int):
        """
        Add a new element to the heap while maintaining the heap property.
        - value (int): The value to be inserted into the heap.
        - TypeError: If the value is not an integer.
        """
        if not isinstance(value, int):
            raise TypeError("Value must be an integer.")
        self.heap.append(value)
        self._heapify_up(len(self.heap) - 1)
    def extract_min(self):
        """
        Remove and return the minimum element from the heap.
        - IndexError: If the heap is empty.
        - int: The minimum element from the heap.
        """
        if len(self.heap) == 0:
            raise IndexError("Heap is empty.")
