def reverse_words(sentence: str):
    """
    Reverses the order of words in a given sentence.
    """
    if not isinstance(sentence, str):
        raise TypeError("Input must be a string.")
    # Remove leading and trailing whitespaces
    sentence = sentence.strip()
    # Split the sentence into words
    words = sentence.split()
    # Reverse the list of words
    reversed_words = words[::-1]
    # Join the reversed words back into a sentence
    reversed_sentence = ' '.join(reversed_words)
    return reversed_sentence
# Example usage
print(reverse_words("Hello World"))  # Output: "World Hello"
print(reverse_words("   Hello World  "))  # Output: "World Hello"
print(reverse_words(123))  # Raises TypeError