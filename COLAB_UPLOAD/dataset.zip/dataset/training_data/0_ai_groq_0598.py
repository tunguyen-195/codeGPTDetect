def rabin_karp(text: str, pattern: str):
    """
    Searches for the first occurrence of the pattern in the text using the Rabin-Karp algorithm.
    """
    if not pattern or len(pattern) > len(text):
        raise ValueError("Pattern must be non-empty and not longer than the text")
    # Calculate the base and modulus values for the hash function
    base = 256
    modulus = 101
    # Calculate the hash values for the pattern
    pattern_hash = 0
    text_hash = 0
    h = 1
    for i in range(len(pattern) - 1):
        h = (h * base) % modulus
    # Calculate the initial hash values for the text and pattern
    for i in range(len(pattern)):
        pattern_hash = (base * pattern_hash + ord(pattern[i])) % modulus
        text_hash = (base * text_hash + ord(text[i])) % modulus
    # Slide the pattern over the text and compare hash values
    for i in range(len(text) - len(pattern) + 1):
        if pattern_hash == text_hash:
            # Check if the pattern matches the text at this position
            match = True
            for j in range(len(pattern)):
                if text[i + j] != pattern[j]:
                    match = False
                    break
            if match:
                return i
        # Calculate the next hash value for the text
        if i < len(text) - len(pattern):
            text_hash = (base * (text_hash - ord(text[i]) * h) + ord(text[i + len(pattern)])) % modulus