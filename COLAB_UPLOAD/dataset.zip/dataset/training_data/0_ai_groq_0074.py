def rotate_array(nums: list[int], k: int):
    """
    Rotates the input array to the right by k positions in-place.
    """
    # Handle edge cases where k is greater than the length of the array
    k = k % len(nums)
    
    # Use Python's list slicing feature to rotate the array
    # This operation has a time complexity of O(n) where n is the length of the array
    # It works by slicing the array into two parts at the rotation point and then concatenating them in reverse order
    nums[:] = nums[-k:] + nums[:-k]
def main():
    """
    Example usage of the rotate_array function.
    """
    # Create a sample array
    nums = [1, 2, 3, 4, 5, 6, 7]
    
    # Print the original array
    print("Original array:", nums)
    
    # Rotate the array to the right by 3 positions
    rotate_array(nums, 3)
    
    # Print the rotated array
    print("Rotated array:", nums)
if __name__ == "__main__":
    main()