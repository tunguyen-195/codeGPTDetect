def heapify(arr: list, n: int, i: int):
    """
    Heapify the subtree rooted at index i.
    Time complexity: O(log n)
    """
    largest = i  # Initialize largest as root
    left = 2 * i + 1  # left child index
    right = 2 * i + 2  # right child index
    # See if the left child of root exists and is greater than root
    if left < n and arr[i] < arr[left]:
        largest = left
    # See if the right child of root exists and is greater than root
    if right < n and arr[largest] < arr[right]:
        largest = right
    # Change root, if needed
    if largest != i:
        arr[i], arr[largest] = arr[largest], arr[i]  # swap
        # Heapify the root.
        heapify(arr, n, largest)
def heap_sort(arr: list):
    """
    Sorts the input list using the heap sort algorithm.
    Time complexity: O(n log n)
    Space complexity: O(1)
    """
    n = len(arr)
    # Build a max heap.
    for i in range(n // 2 - 1, -1, -1):
        heapify(arr, n, i)
    # One by one extract elements
    for i in range(n - 1, 0, -1):