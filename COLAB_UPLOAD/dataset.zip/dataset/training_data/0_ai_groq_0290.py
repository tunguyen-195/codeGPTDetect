def climb_stairs(n: int):
    """
    This function calculates the number of distinct ways to climb 'n' stairs.
    
    
    int: The number of distinct ways to climb 'n' stairs.
    
    Time complexity: O(n)
    Space complexity: O(n)
    """
    
    # Create a list to store the number of ways to climb each stair
    ways = [0] * (n + 1)
    
    # There's only one way to climb 0 stairs (i.e., not climbing any)
    ways[0] = 1
    
    # There's only one way to climb 1 stair
    ways[1] = 1
    
    # For each stair from 2 to n
    for i in range(2, n + 1):
        # The number of ways to climb this stair is the sum of the number of ways to climb the previous two stairs
        ways[i] = ways[i - 1] + ways[i - 2]
    
    # Return the number of ways to climb 'n' stairs
    return ways[n]
# Example usage:
print(climb_stairs(2))  # Output: 2
print(climb_stairs(3))  # Output: 3
print(climb_stairs(4))  # Output: 5