from collections import defaultdict
class Graph:
    """
    A class to represent a graph.
    """
    def __init__(self, num_vertices: int):
        """
        Initialize the graph with the given number of vertices.
        """
        self.num_vertices = num_vertices
        self.adj_list = defaultdict(list)
    def add_edge(self, u: int, v: int):
        """
        Add an edge between two vertices in the graph.
        """
        self.adj_list[u].append(v)
    def dfs(self, visited: list, vertex: int):
        """
        Perform a depth-first search on the graph.
        """
        visited[vertex] = True
        for neighbor in self.adj_list[vertex]:
            if not visited[neighbor]:
                self.dfs(visited, neighbor)
    def transpose(self):
        """
        Create the transpose of the graph.