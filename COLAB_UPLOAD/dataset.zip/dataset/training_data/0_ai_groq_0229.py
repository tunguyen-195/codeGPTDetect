from typing import Dict, List, Tuple
class Graph:
    def __init__(self):
        """
        Initialize an empty graph.
        """
        self.adjacency_list: Dict[int, List[int]] = {}
    def add_edge(self, u: int, v: int):
        """
        Add an edge between two nodes in the graph.
        """
        if u not in self.adjacency_list:
            self.adjacency_list[u] = []
        if v not in self.adjacency_list:
            self.adjacency_list[v] = []
        self.adjacency_list[u].append(v)
        self.adjacency_list[v].append(u)
    def dfs(self, node: int, visited: set, recursion_stack: set):
        """
        Perform a Depth-First Search (DFS) on the graph.
        bool: True if a cycle is detected, False otherwise.
        """
        visited.add(node)
        recursion_stack.add(node)
        for neighbor in self.adjacency_list[node]:
            if neighbor not in visited:
                if self.dfs(neighbor, visited, recursion_stack):
                    return True