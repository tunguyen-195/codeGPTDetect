class Graph:
    """
    A class representing a weighted graph using the Bellman-Ford algorithm.
    """
    def __init__(self, num_vertices):
        """
        Initialize a graph with a specified number of vertices.
        """
        self.num_vertices = num_vertices
        self.edges = []
    def add_edge(self, u: int, v: int, weight: int):
        """
        Add an edge to the graph.
        """
        self.edges.append((u, v, weight))
    def bellman_ford(self, start_vertex: int):
        """
        Run the Bellman-Ford algorithm to find the shortest path from the start vertex to all other vertices.
        """
        distances = [float('inf')] * self.num_vertices
        predecessors = [None] * self.num_vertices
        distances[start_vertex] = 0
        for _ in range(self.num_vertices - 1):
            for u, v, weight in self.edges:
                if distances[u] != float('inf') and distances[u] + weight < distances[v]:
                    distances[v] = distances[u] + weight
                    predecessors[v] = u
        for u, v, weight in self.edges:
            if distances[u] != float('inf') and distances[u] + weight < distances[v]:
                raise ValueError("Graph contains a negative-weight cycle")