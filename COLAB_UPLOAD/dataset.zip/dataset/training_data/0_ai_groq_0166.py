def counting_sort(arr: list[int]):
    """
    Sorts an integer array using the Counting Sort algorithm.
    Time complexity: O(n + k), where n is the number of elements in the array and k is the range of input.
    Space complexity: O(n + k), as we need to store the count and output arrays.
    """
    # Check if the input array is empty
    if not arr:
        raise ValueError("Input array is empty")
    # Check if the input array contains non-integer values
    if not all(isinstance(x, int) for x in arr):
        raise ValueError("Input array contains non-integer values")
    # Find the minimum and maximum values in the array to determine the range of input
    min_val = min(arr)
    max_val = max(arr)
    # Initialize the count array with zeros, where the size is the range of input plus one
    count = [0] * (max_val - min_val + 1)
    # Count the occurrences of each value in the input array
    for num in arr:
        # Subtract the minimum value to shift the range to start from zero
        count[num - min_val] += 1
    # Calculate the cumulative count to determine the position of each value in the output array
    for i in range(1, len(count)):
        count[i] += count[i - 1]
    # Initialize the output array with zeros, where the size is the same as the input array
    output = [0] * len(arr)
    # Build the output array by placing each value at its correct position
    for num in arr:
        # Subtract the minimum value to shift the range to start from zero
        output[count[num - min_val] - 1] = num
        # Decrement the count to handle duplicate values