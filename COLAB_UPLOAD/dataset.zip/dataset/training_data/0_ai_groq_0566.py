def counting_sort(arr: list[int]):
    """
    Sorts an array of integers using the counting sort algorithm.
    Time Complexity:
    - Best: O(n + k) where n is the number of elements in the array and k is the range of input integers.
    - Average: O(n + k)
    - Worst: O(n + k)
    Space Complexity: O(n + k)
    list[int]: The sorted array.
    ValueError: If the input array contains non-integer values.
    """
    # Check if the input array contains non-integer values
    if not all(isinstance(x, int) for x in arr):
        raise ValueError("Input array must contain only integers.")
    # Find the maximum element in the array to determine the range of input integers
    max_element = max(arr)
    # Create a count array to store the count of individual elements
    count_arr = [0] * (max_element + 1)
    # Count the occurrences of each element in the input array
    for num in arr:
        count_arr[num] += 1
    # Calculate the cumulative sum of the count array
    for i in range(1, len(count_arr)):
        count_arr[i] += count_arr[i - 1]
    # Create a sorted array to store the sorted elements
    sorted_arr = [0] * len(arr)
    # Build the sorted array using the count array