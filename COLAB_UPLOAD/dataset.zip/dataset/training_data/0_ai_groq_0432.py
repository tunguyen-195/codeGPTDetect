from typing import Dict, List
class Graph:
    """
    A class representing a graph with weighted edges.
    
    ----------
    num_vertices : int
        The number of vertices in the graph.
    adjacency_list : Dict[int, List[Tuple[int, int]]]
        An adjacency list representing the graph, where each key is a vertex and its corresponding value is a list of tuples.
        Each tuple contains the destination vertex and the edge weight.
    """
    def __init__(self, num_vertices: int):
        """
        Initializes a graph with the specified number of vertices.
        
        ----------
        num_vertices : int
            The number of vertices in the graph.
        """
        self.num_vertices = num_vertices
        self.adjacency_list = {i: [] for i in range(num_vertices)}
    def add_edge(self, src: int, dst: int, weight: int):
        """
        Adds a weighted edge between two vertices in the graph.
        
        ----------
        src : int
            The source vertex of the edge.
        dst : int
            The destination vertex of the edge.
        weight : int
            The weight of the edge.
        """
        if 0 <= src < self.num_vertices and 0 <= dst < self.num_vertices:
            self.adjacency_list[src].append((dst, weight))
        else: