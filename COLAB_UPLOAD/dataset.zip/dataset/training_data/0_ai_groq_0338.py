class BTreeNode:
    """
    Represents a node in the B-Tree.
    
    """
    def __init__(self, leaf: bool = False):
        """
        Initializes a new B-Tree node.
        
        """
        self.leaf = leaf
        self.keys = []
        self.children = []
        self.values = []
class BTree:
    """
    Represents a B-Tree data structure for disk-based storage.
    
    """
    def __init__(self, t: int = 3):
        """
        Initializes a new B-Tree.
        
        """
        self.t = t
        self.root = BTreeNode()
    def _insert_non_full(self, node: BTreeNode, key: int):
        """