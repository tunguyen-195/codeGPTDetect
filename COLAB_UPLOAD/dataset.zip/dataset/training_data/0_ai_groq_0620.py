from collections import deque
def sliding_window_max(arr: list[int], k: int):
    """
    Compute the sliding window maximum of an array.
    list[int]: A list of maximum values for each window.
    ValueError: If k is larger than the array length.
    """
    if k > len(arr):
        raise ValueError("k cannot be larger than the array length")
    # Initialize the deque to store indices of elements in the current window
    dq = deque()
    # Initialize the result list
    result = []
    # Process the first window
    for i in range(k):
        # Remove indices of elements that are out of the current window
        while dq and dq[0] <= i - k:
            dq.popleft()
        
        # Remove indices of elements that are smaller than the current element
        while dq and arr[dq[-1]] < arr[i]:
            dq.pop()
        
        # Add the current index to the deque
        dq.append(i)
    # Add the maximum of the first window to the result
    result.append(arr[dq[0]])
    # Process the rest of the array
    for i in range(k, len(arr)):