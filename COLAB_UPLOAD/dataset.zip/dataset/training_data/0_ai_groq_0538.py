class BTreeNode:
    """Represents a node in the B-Tree data structure."""
    
    def __init__(self, degree: int, leaf: bool = False):
        """
        Initializes a new B-Tree node.
        - degree (int): The degree of the B-Tree, which determines the minimum and maximum number of keys in each node.
        - leaf (bool): A flag indicating whether this node is a leaf node or not.
        """
        self.degree = degree
        self.leaf = leaf
        self.keys = []
        self.children = []
class BTree:
    """Represents a B-Tree data structure for disk-based storage."""
    
    def __init__(self, degree: int):
        """
        Initializes a new B-Tree instance.
        - degree (int): The degree of the B-Tree, which determines the minimum and maximum number of keys in each node.
        """
        self.degree = degree
        self.root = BTreeNode(degree, leaf=True)
    def _insert(self, node: BTreeNode, key: int):
        """
        Inserts a new key into the given node.
        - node (BTreeNode): The node into which the key should be inserted.
        - key (int): The key to be inserted.
        """
        # If the node is a leaf node, insert the key directly
        if node.leaf:
            node.keys.append(key)
            node.keys.sort()  # Sort the keys in ascending order
            return
