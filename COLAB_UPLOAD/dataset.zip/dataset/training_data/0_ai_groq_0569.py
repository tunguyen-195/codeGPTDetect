def shell_sort(arr: list):
    """
    Shell Sort implementation with a custom gap sequence.
    Time complexity:
    - Best case: O(n log n) when the gap sequence is optimal (e.g., Shell's original sequence)
    - Average case: O(n log n) for most gap sequences
    - Worst case: O(n^2) for a gap sequence that is too small or too large
    :param arr: Input list to be sorted
    :return: Sorted list
    """
    def custom_gap_sequence(n: int):
        """
        Custom gap sequence implementation.
        This sequence starts with a large gap and gradually decreases it.
        The goal is to have a gap that is large enough to group the elements
        efficiently, but small enough to allow for efficient comparison.
        :param n: Length of the input list
        :return: Custom gap sequence
        """
        gaps = [n // 2]
        while gaps[-1] > 1:
            gaps.append(gaps[-1] // 2)
        return gaps[::-1]
    def shell_sort_helper(arr: list, gaps: list):
        """
        Recursive helper function for Shell Sort.
        :param arr: Input list to be sorted
        :param gaps: Custom gap sequence
        """
        # Base case: if the gap is 0, the list is already sorted
        if gaps[0] == 0:
            return
        # Select the current gap