from typing import Dict, List, Tuple
class Graph:
    """
    A directed graph implementation with cycle detection.
    ----------
    graph : Dict[int, List[int]]
        Adjacency list representation of the graph.
    """
    def __init__(self):
        """
        Initialize an empty graph.
        """
        self.graph = {}
    def add_edge(self, node: int, neighbor: int):
        """
        Add a directed edge to the graph.
        ----
        node : int
            The node to add the edge from.
        neighbor : int
            The node to add the edge to.
        ------
        ValueError
            If the node or neighbor is not a non-negative integer.
        """
        if not isinstance(node, int) or not isinstance(neighbor, int):
            raise ValueError("Node and neighbor must be integers")
        if node < 0 or neighbor < 0:
            raise ValueError("Node and neighbor must be non-negative integers")
        if node not in self.graph:
            self.graph[node] = []
        self.graph[node].append(neighbor)
    def has_cycle(self):