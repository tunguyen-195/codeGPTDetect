from typing import Dict, List, Set
class Graph:
    """
    A class representing an undirected graph.
    """
    def __init__(self, num_vertices: int):
        """
        Initializes the graph with a specified number of vertices.
        """
        self.num_vertices = num_vertices
        self.adj_list: Dict[int, List[int]] = {i: [] for i in range(num_vertices)}
    def add_edge(self, u: int, v: int):
        """
        Adds an edge between two vertices in the graph.
        """
        if u not in self.adj_list or v not in self.adj_list:
            raise ValueError("Both vertices must exist in the graph.")
        self.adj_list[u].append(v)
        self.adj_list[v].append(u)
    def detect_cycle(self):
        """
        Detects whether the graph contains a cycle using DFS.
        bool: True if the graph contains a cycle, False otherwise.
        """
        visited: Set[int] = set()
        rec_stack: Set[int] = set()
        def dfs(vertex: int):
            """
            Performs a depth-first search from the specified vertex.