def find_median_sorted_arrays(nums1: list[int], nums2: list[int]):
    """
    This function finds the median of two sorted arrays.
    """
    # Check if either of the arrays is empty
    if not nums1 and not nums2:
        raise ValueError("Both arrays cannot be empty")
    # Combine the two arrays into one
    combined = sorted(nums1 + nums2)
    # Calculate the length of the combined array
    length = len(combined)
    # If the length is even, the median is the average of the two middle numbers
    if length % 2 == 0:
        # Calculate the indices of the two middle numbers
        mid1 = length // 2 - 1
        mid2 = length // 2
        # Return the average of the two middle numbers
        return (combined[mid1] + combined[mid2]) / 2
    # If the length is odd, the median is the middle number
    else:
        # Calculate the index of the middle number
        mid = length // 2
        # Return the middle number
        return combined[mid]
def find_median_sorted_arrays_optimal(nums1: list[int], nums2: list[int]):
    """
    This function finds the median of two sorted arrays with optimal time complexity.
    """
    # Check if either of the arrays is empty
    if not nums1 and not nums2:
        raise ValueError("Both arrays cannot be empty")
    # Ensure that nums1 is the smaller array
    if len(nums1) > len(nums2):