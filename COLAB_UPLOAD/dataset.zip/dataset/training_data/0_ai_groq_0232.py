class Graph:
    """
    A class to represent a graph with bridges.
    
    ----------
    V : int
        The number of vertices in the graph.
    graph : list
        The adjacency list representation of the graph.
    parent : list
        The parent of each vertex in the DFS tree.
    rank : list
        The rank of each vertex in the DFS tree.
    bridges : list
        The list of bridges in the graph.
    time : int
        The current time in the DFS traversal.
    time1 : int
        The first time when the vertex is visited.
    time2 : int
        The second time when the vertex is visited.
    """
    def __init__(self, V):
        """
        Initialize the graph with V vertices.
        
        ----------
        V : int
            The number of vertices in the graph.
        """
        self.V = V
        self.graph = [[] for _ in range(V)]
        self.parent = [-1] * V
        self.rank = [0] * V
        self.bridges = []
        self.time = 0
        self.time1 = [0] * V
        self.time2 = [0] * V
