import random
class Node:
    """
    A class representing a node in the skip list.
    
    """
    def __init__(self, value: int, level: int):
        """
        Initializes a Node with a given value and level.
        
        """
        self.value = value
        self.next = [None] * (level + 1)
class SkipList:
    """
    A class representing a skip list data structure.
    
    """
    def __init__(self, max_level: int = 16, p: float = 0.5):
        """
        Initializes a SkipList with a given maximum level and probability.
        
        """
        self.max_level = max_level
        self.p = p
        self.head = Node(float('-inf'), max_level)