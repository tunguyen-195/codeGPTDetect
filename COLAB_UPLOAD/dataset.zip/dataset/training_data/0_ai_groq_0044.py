from typing import Dict, List, Tuple
import heapq
class Graph:
    """
    Represents a weighted graph.
                  The inner dictionary's keys are the node's neighbors and its values are the edge weights.
    """
    def __init__(self):
        """
        Initializes an empty graph.
        """
        self.graph = {}
    def add_node(self, node: str):
        """
        Adds a node to the graph.
        """
        if node not in self.graph:
            self.graph[node] = {}
    def add_edge(self, node1: str, node2: str, weight: int):
        """
        Adds an edge between two nodes in the graph.
        """
        if node1 in self.graph and node2 in self.graph:
            self.graph[node1][node2] = weight
            self.graph[node2][node1] = weight  # For undirected graph
    def dijkstra(self, start_node: str):
        """