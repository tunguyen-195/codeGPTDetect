from collections import deque
class Queue:
    """
    A class representing a queue data structure.
    """
    def __init__(self):
        """
        Initializes an empty queue.
        """
        self.queue = deque()
    def enqueue(self, item: any):
        """
        Adds an item to the end of the queue.
        """
        try:
            self.queue.append(item)
        except Exception as e:
            print(f"An error occurred: {str(e)}")
    def dequeue(self):
        """
        Removes and returns the item from the front of the queue.
        """
        try:
            if not self.is_empty():
                return self.queue.popleft()
            else:
                raise IndexError("Cannot dequeue from an empty queue")
        except Exception as e:
            print(f"An error occurred: {str(e)}")
    def is_empty(self):
        """
        Checks if the queue is empty.