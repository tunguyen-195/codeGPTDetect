def unbounded_knapsack(capacity: int, weights: list, values: list):
    """
    Solve the Unbounded Knapsack problem using dynamic programming.
    The Unbounded Knapsack problem is a variant of the 0/1 Knapsack problem where
    the capacity of the knapsack can be exceeded. This function calculates the
    maximum value that can be put in a knapsack of given capacity.
    - capacity (int): The maximum capacity of the knapsack.
    - weights (list): A list of weights of items.
    - values (list): A list of values of items.
    - int: The maximum value that can be put in the knapsack.
    Time Complexity: O(nW)
    Space Complexity: O(W)
    """
    # Initialize a list to store the maximum value for each subproblem
    dp = [0] * (capacity + 1)
    # Iterate over each item
    for i in range(len(weights)):
        # Iterate from the capacity down to the weight of the current item
        for j in range(capacity, weights[i] - 1, -1):
            # Update the maximum value for the current capacity
            dp[j] = max(dp[j], dp[j - weights[i]] + values[i])
    # Return the maximum value for the given capacity
    return dp[capacity]
# Example usage:
weights = [1, 2, 4, 2, 5]
values = [5, 3, 5, 3, 2]
capacity = 10
print(unbounded_knapsack(capacity, weights, values))  # Output: 14