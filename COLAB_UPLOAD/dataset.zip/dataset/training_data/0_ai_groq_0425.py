class Graph:
    """A class to represent a graph using an adjacency list."""
    
    def __init__(self, vertices: int):
        """
        Initialize the graph with the given number of vertices.
        """
        self.V = vertices
        self.graph = []
    def add_edge(self, u: int, v: int, w: int):
        """
        Add an edge to the graph.
        """
        self.graph.append((u, v, w))
    def find(self, parent: list, i: int):
        """
        Find the set of an element i.
        int: The set of the element i.
        """
        if parent[i] == i:
            return i
        return self.find(parent, parent[i])
    def union(self, parent: list, rank: list, x: int, y: int):
        """
        Union of two sets of x and y.
