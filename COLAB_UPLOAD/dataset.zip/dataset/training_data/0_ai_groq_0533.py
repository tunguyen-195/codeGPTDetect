from typing import List
def activity_selection(activities: List[tuple]):
    """
    Select maximum number of non-overlapping activities.
    List[tuple]: List of selected activities.
    ValueError: If the input list is empty.
    """
    if not activities:
        raise ValueError("Input list cannot be empty")
    # Sort activities based on their end time
    activities.sort(key=lambda x: x[1])
    selected_activities = [activities[0]]
    # Iterate through the remaining activities
    for activity in activities[1:]:
        # If the current activity does not overlap with the last selected activity, add it to the list
        if activity[0] >= selected_activities[-1][1]:
            selected_activities.append(activity)
    return selected_activities
def main():
    # Example usage
    activities = [
        (1, 4, 'A'),
        (3, 5, 'B'),
        (0, 6, 'C'),
        (5, 7, 'D'),
        (3, 8, 'E'),
        (5, 9, 'F'),
        (6, 10, 'G'),
        (8, 11, 'H'),
        (8, 12, 'I')