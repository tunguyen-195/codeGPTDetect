from typing import Any, Optional
class CircularQueue:
    """
    A class to implement a Circular Queue with a fixed size.
    """
    def __init__(self, size: int):
        """
        Initializes the Circular Queue with a given size.
        """
        self.size = size
        self.queue = [None] * size
        self.front = 0
        self.rear = 0
        self.count = 0
    def is_empty(self):
        """
        Checks if the queue is empty.
        bool: True if the queue is empty, False otherwise.
        """
        return self.count == 0
    def is_full(self):
        """
        Checks if the queue is full.
        bool: True if the queue is full, False otherwise.
        """
        return self.count == self.size