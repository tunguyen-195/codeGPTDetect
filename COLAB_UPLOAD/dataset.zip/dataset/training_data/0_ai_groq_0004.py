class TrieNode:
    """
    A node in the Trie data structure.
    """
    def __init__(self):
        """
        Initialize a new TrieNode.
        """
        self.children: dict[str, 'TrieNode'] = {}
        self.is_end_of_word: bool = False
class Trie:
    """
    A Trie (Prefix Tree) data structure for autocomplete functionality.
    """
    def __init__(self):
        """
        Initialize a new Trie.
        """
        self.root: TrieNode = TrieNode()
    def insert(self, word: str):
        """
        Insert a word into the Trie.
        """
        if not isinstance(word, str):
            raise TypeError("Input must be a string")
        current_node: TrieNode = self.root
        for char in word:
            if char not in current_node.children:
                current_node.children[char] = TrieNode()
            current_node = current_node.children[char]
        current_node.is_end_of_word = True
