def manacher_odd(s: str):
    """
    Manacher's algorithm for longest palindrome centered at an odd position.
    str: The longest palindrome centered at an odd position.
    """
    def manacher_helper(s: str):
        # Initialize the array to store the lengths of palindromes
        P = [0] * len(s)
        
        # Initialize the center and the maximum length
        center = 0
        max_length = 0
        
        # Iterate over the string
        for i in range(1, len(s) - 1):
            # If the current position is within the range of the palindrome centered at the center
            if i < center:
                # Calculate the mirrored position
                mirrored = 2 * center - i
                
                # Update the length of the palindrome
                P[i] = min(P[mirrored], center - i + max_length)
            
            # Expand the palindrome
            while s[i + 1 + P[i]] == s[i - 1 - P[i]]:
                P[i] += 1
            
            # Update the center and the maximum length
            if i + P[i] > max_length + center:
                center = i
                max_length = i + P[i]
        
        # Return the maximum length and the array of lengths
        return max_length, P
    
    # Handle the case when the input string is empty
    if not s: