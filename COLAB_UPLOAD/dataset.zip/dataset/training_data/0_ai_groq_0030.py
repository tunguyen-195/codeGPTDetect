def binary_insertion_sort(arr: list[int]):
    """
    Sorts an array using Insertion Sort with binary search optimization.
    Time complexity:
    - Best-case: O(n log n) when the array is already sorted.
    - Average-case: O(n log n) for random input.
    - Worst-case: O(n^2) when the array is reverse sorted.
    """
    # Check if the input is a list
    if not isinstance(arr, list):
        raise TypeError("Input must be a list")
    # Check if all elements in the list are integers
    if not all(isinstance(x, int) for x in arr):
        raise TypeError("All elements in the list must be integers")
    # Handle edge case where the input list is empty
    if len(arr) == 0:
        return arr
    # Iterate over the array starting from the second element
    for i in range(1, len(arr)):
        # Store the current element to be inserted
        current_element = arr[i]
        # Find the position to insert the current element using binary search
        insert_position = binary_search(arr, current_element, 0, i)
        # Shift elements to the right to make space for the current element
        for j in range(i, insert_position, -1):
            arr[j] = arr[j - 1]
        # Insert the current element at the correct position
        arr[insert_position] = current_element
    return arr
def binary_search(arr: list[int], target: int, start: int, end: int):