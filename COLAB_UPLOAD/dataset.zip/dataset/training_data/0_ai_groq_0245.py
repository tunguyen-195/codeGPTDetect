class Stack:
    """
    A basic implementation of a Stack data structure using a list.
    
    ----------
    stack : list
        The underlying list used to store elements of the stack.
    """
    def __init__(self):
        """
        Initializes an empty stack.
        """
        self.stack: list = []
    def push(self, item: any):
        """
        Pushes an item onto the top of the stack.
        
        ----
        item : any
            The item to be pushed onto the stack.
        
        ------
        TypeError
            If the item is not of a valid type.
        """
        try:
            self.stack.append(item)
        except Exception as e:
            print(f"Error pushing item onto stack: {str(e)}")
    def pop(self):
        """
        Removes and returns the top item from the stack.
        
        -------
        any
            The item removed from the stack.
        