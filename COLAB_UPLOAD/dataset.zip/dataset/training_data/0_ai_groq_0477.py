from collections import deque
from typing import Dict, List, Optional
class Graph:
    """
    A basic graph implementation for BFS.
    """
    def __init__(self):
        """
        Initialize an empty graph.
        """
        self.adjacency_list: Dict[int, List[int]] = {}
    def add_edge(self, node: int, neighbor: int):
        """
        Add an edge between two nodes in the graph.
        """
        if node not in self.adjacency_list:
            self.adjacency_list[node] = []
        self.adjacency_list[node].append(neighbor)
    def bfs_shortest_path(self, start_node: int, end_node: int):
        """
        Perform BFS to find the shortest path between two nodes.
        """
        if start_node not in self.adjacency_list or end_node not in self.adjacency_list:
            raise ValueError("Both start and end nodes must be in the graph")
        visited: Set[int] = set()
        queue: deque = deque([(start_node, [start_node])])
        while queue:
            current_node, path = queue.popleft()
            if current_node == end_node:
                return path
            if current_node not in visited: