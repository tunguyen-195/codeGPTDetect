def reverse_bits(n: int):
    """
    Reverses the bits of a given integer using bit manipulation.
    """
    if not isinstance(n, int):
        raise TypeError("Input must be an integer.")
    # Initialize result variable to store the reversed bits
    result = 0
    # We will iterate over the number of bits in the integer
    # Since Python's integers can be arbitrarily large, we'll use the bit_length method
    for _ in range(n.bit_length()):
        # Left shift the result by 1 bit to make space for the new bit
        result <<= 1
        
        # Use the bitwise AND operator with 1 to get the least significant bit of n
        # If the bit is 1, it will be 1, otherwise it will be 0
        # Then, use the bitwise OR operator to add this bit to the result
        result |= n & 1
        
        # Right shift n by 1 bit to move to the next bit
        n >>= 1
    return result
# Example usage:
if __name__ == "__main__":
    print(reverse_bits(18))  # Output: 9
    print(reverse_bits(0))  # Output: 0
    print(reverse_bits(1))  # Output: 1