class Node:
    """Represents a node in the Binary Search Tree."""
    def __init__(self, value: int):
        """
        Initializes a Node with a given value.
        """
        self.value = value
        self.left = None
        self.right = None
class BinarySearchTree:
    """Represents a Binary Search Tree with insert, delete, search, and in-order traversal methods."""
    def __init__(self):
        """
        Initializes an empty Binary Search Tree.
        """
        self.root = None
    def insert(self, value: int):
        """
        Inserts a new value into the Binary Search Tree.
        """
        if self.root is None:
            self.root = Node(value)
        else:
            self._insert_recursive(self.root, value)
    def _insert_recursive(self, node: Node, value: int):
        """
        Recursively inserts a new value into the Binary Search Tree.
        """
        if value < node.value:
            if node.left is None:
                node.left = Node(value)
            else:
                self._insert_recursive(node.left, value)
        elif value > node.value: