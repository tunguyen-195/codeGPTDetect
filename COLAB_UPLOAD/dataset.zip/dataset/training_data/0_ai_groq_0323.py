from typing import Dict, List
class BellmanFord:
    """
    Implementation of Bellman-Ford algorithm for finding shortest paths from a source node to all other nodes in a weighted graph.
    ----------
    graph : Dict[int, Dict[int, int]]
        The input graph represented as an adjacency list.
    source : int
        The source node.
    distances : Dict[int, int]
        The shortest distances from the source node to all other nodes.
    """
    def __init__(self, graph: Dict[int, Dict[int, int]], source: int):
        """
        Initializes the BellmanFord object.
        ----
        graph : Dict[int, Dict[int, int]]
            The input graph represented as an adjacency list.
        source : int
            The source node.
        """
        self.graph = graph
        self.source = source
        self.distances = {node: float('inf') for node in graph}
        self.distances[source] = 0  # Initialize distance to source as 0
    def relax(self, u: int, v: int, weight: int):
        """
        Relax the edge from node u to node v if it leads to a shorter path.
        ----
        u : int
            The source node.
        v : int
            The destination node.
        weight : int