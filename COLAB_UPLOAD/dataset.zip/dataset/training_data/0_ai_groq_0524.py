def floyd_warshall(graph: list[list[int]]):
    """
    Implement Floyd-Warshall algorithm to find all-pairs shortest path in a weighted graph.
    graph: A 2D list representing the adjacency matrix of the graph, where graph[i][j] is the weight of the edge from node i to node j.
    A 2D list representing the shortest distance matrix, where dist[i][j] is the shortest distance from node i to node j.
    ValueError: If the graph is not a square matrix or if the weights are not non-negative.
    """
    # Check if the graph is a square matrix
    num_nodes = len(graph)
    if any(len(row) != num_nodes for row in graph):
        raise ValueError("The graph must be a square matrix")
    # Check if the weights are non-negative
    if any(weight < 0 for row in graph for weight in row):
        raise ValueError("All weights must be non-negative")
    # Create a copy of the graph to store the shortest distances
    dist = [[graph[i][j] for j in range(num_nodes)] for i in range(num_nodes)]
    # Initialize the diagonal elements to 0 (distance from a node to itself is 0)
    for i in range(num_nodes):
        dist[i][i] = 0
    # Iterate over all intermediate nodes
    for k in range(num_nodes):
        # Iterate over all pairs of nodes
        for i in range(num_nodes):
            for j in range(num_nodes):
                # Update the shortest distance if a shorter path is found through the intermediate node k
                dist[i][j] = min(dist[i][j], dist[i][k] + dist[k][j])
    return dist
def print_distance_matrix(dist: list[list[int]]):
    """
    Print the shortest distance matrix in a human-readable format.