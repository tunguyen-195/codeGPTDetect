from typing import List, Tuple
def find_pairs(nums: List[int], target: int):
    """
    Finds all pairs in the given list of numbers that sum to the target value.
    - nums (List[int]): A list of integers.
    - target (int): The target sum.
    - List[Tuple[int, int]]: A list of tuples, where each tuple contains a pair of numbers that sum to the target.
    Time Complexity: O(n)
    Space Complexity: O(n)
    """
    if not nums:
        return []
    num_set = set()
    pairs = set()
    for num in nums:
        complement = target - num
        if complement in num_set:
            # Add the pair to the result set, but sort the numbers to avoid duplicates
            pair = tuple(sorted((num, complement)))
            pairs.add(pair)
        num_set.add(num)
    return list(pairs)