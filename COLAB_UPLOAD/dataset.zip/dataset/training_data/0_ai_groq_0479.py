import heapq
class Graph:
    """
    A weighted graph data structure.
    
    - vertices (set): A set of unique vertices in the graph.
    - edges (dict): A dictionary mapping each vertex to its neighbors and edge weights.
    """
    
    def __init__(self):
        """
        Initializes an empty graph.
        """
        self.vertices = set()
        self.edges = {}
    
    def add_vertex(self, vertex: str):
        """
        Adds a new vertex to the graph.
        
        - vertex (str): The label of the vertex to add.
        """
        self.vertices.add(vertex)
        if vertex not in self.edges:
            self.edges[vertex] = {}
    
    def add_edge(self, vertex1: str, vertex2: str, weight: float):
        """
        Adds a new edge to the graph.
        
        - vertex1 (str): The label of the first vertex.
        - vertex2 (str): The label of the second vertex.
        - weight (float): The weight of the edge between the two vertices.
        
        - ValueError: If either vertex is not in the graph.
        """
        if vertex1 not in self.vertices:
            raise ValueError(f"Vertex '{vertex1}' not found in the graph.")
        if vertex2 not in self.vertices: