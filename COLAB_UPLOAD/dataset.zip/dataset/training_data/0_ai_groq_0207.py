from typing import Dict
def longest_substring_without_repeating_chars(s: str):
    """
    Finds the longest substring without repeating characters in a given string.
    str: The longest substring without repeating characters.
    TypeError: If the input is not a string.
    ValueError: If the input string is empty.
    """
    if not isinstance(s, str):
        raise TypeError("Input must be a string.")
    if not s:
        raise ValueError("Input string cannot be empty.")
    char_index_map: Dict[str, int] = {}
    max_length = 0
    max_substring = ""
    window_start = 0
    for window_end in range(len(s)):
        right_char = s[window_end]
        if right_char in char_index_map:
            window_start = max(window_start, char_index_map[right_char] + 1)
        char_index_map[right_char] = window_end
        if window_end - window_start + 1 > max_length:
            max_length = window_end - window_start + 1
            max_substring = s[window_start:window_end + 1]
    return max_substring