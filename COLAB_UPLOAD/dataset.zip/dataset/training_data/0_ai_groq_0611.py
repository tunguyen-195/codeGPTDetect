from typing import List
def merge_intervals(intervals: List[List[int]]):
    """
    Merge overlapping intervals in a list of intervals.
    intervals: A list of intervals, where each interval is a list of two integers.
    A list of merged intervals.
    >>> merge_intervals([[1, 3], [2, 6], [8, 10], [15, 18]])
    [[1, 6], [8, 10], [15, 18]]
    """
    # Handle the case where the input list is empty
    if not intervals:
        return []
    # Sort the intervals by their start value
    intervals.sort(key=lambda x: x[0])
    # Initialize the result with the first interval
    merged_intervals = [intervals[0]]
    # Iterate over the remaining intervals
    for current_interval in intervals[1:]:
        # Get the last merged interval
        last_merged_interval = merged_intervals[-1]
        # Check if the current interval overlaps with the last merged interval
        if current_interval[0] <= last_merged_interval[1]:
            # Merge the current interval with the last merged interval
            merged_intervals[-1] = [last_merged_interval[0], max(last_merged_interval[1], current_interval[1])]
        else:
            # Add the current interval to the result
            merged_intervals.append(current_interval)
    return merged_intervals