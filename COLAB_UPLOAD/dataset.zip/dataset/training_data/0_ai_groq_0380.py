def knapsack(weights: list[int], values: list[int], capacity: int):
    """
    Solves the 0-1 Knapsack problem using dynamic programming.
    list[tuple[int, int]]: A list of tuples, where each tuple contains the index of an item and its value.
    """
    # Initialize a 2D table to store the maximum value for each subproblem
    dp = [[0] * (capacity + 1) for _ in range(len(weights) + 1)]
    # Initialize a 2D table to store the items included in the optimal solution for each subproblem
    included_items = [[[] for _ in range(capacity + 1)] for _ in range(len(weights) + 1)]
    # Iterate over each item
    for i in range(1, len(weights) + 1):
        # Iterate over each possible capacity from 1 to the maximum capacity
        for w in range(1, capacity + 1):
            # If the current item's weight is greater than the current capacity, skip it
            if weights[i - 1] > w:
                dp[i][w] = dp[i - 1][w]
                included_items[i][w] = included_items[i - 1][w]
            # Otherwise, choose the maximum value between including the current item and excluding it
            else:
                # Calculate the value if the current item is included
                included_value = dp[i - 1][w - weights[i - 1]] + values[i - 1]
                # If including the current item results in a higher value, include it
                if included_value > dp[i - 1][w]:
                    dp[i][w] = included_value
                    included_items[i][w] = included_items[i - 1][w - weights[i - 1]] + [(i - 1, values[i - 1])]
                # Otherwise, exclude the current item
                else:
                    dp[i][w] = dp[i - 1][w]
                    included_items[i][w] = included_items[i - 1][w]
    # Return the items included in the optimal solution for the maximum capacity
    return included_items[-1][-1]