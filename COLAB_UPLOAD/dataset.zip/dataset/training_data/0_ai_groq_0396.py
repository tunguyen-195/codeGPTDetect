from typing import List, Generator
def get_permutations(s: str):
    """
    Generate all permutations of a given string.
    List[str]: A permutation of the input string.
    TypeError: If the input is not a string.
    """
    if not isinstance(s, str):
        raise TypeError("Input must be a string.")
    # Base case: if the string is empty or has only one character, yield it
    if len(s) <= 1:
        yield [s]
    else:
        # Get the permutations of the rest of the string
        for p in get_permutations(s[1:]):
            # Insert the first character at each position in the permutation
            for i in range(len(p) + 1):
                yield p[:i] + [s[0]] + p[i:]
# Example usage:
if __name__ == "__main__":
    s = "abc"
    print("Permutations of '{}'".format(s))
    for p in get_permutations(s):
        print("".join(p))