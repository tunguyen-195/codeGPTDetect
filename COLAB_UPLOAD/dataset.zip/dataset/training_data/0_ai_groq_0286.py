def coin_change_ways(coins: list[int], amount: int):
    """
    Calculate the number of ways to make a given amount using the provided coins.
    - coins (list[int]): A list of coin denominations.
    - amount (int): The target amount.
    - int: The number of ways to make the target amount.
    - ValueError: If the amount is negative.
    """
    if amount < 0:
        raise ValueError("Amount cannot be negative")
    # Initialize a list to store the number of ways for each amount from 0 to the target amount
    ways = [0] * (amount + 1)
    ways[0] = 1  # There is 1 way to make 0 amount (using no coins)
    # Iterate over each coin denomination
    for coin in coins:
        # Iterate from the coin denomination to the target amount
        for i in range(coin, amount + 1):
            # The number of ways to make the current amount is the sum of the number of ways to make the current amount without using the current coin and the number of ways to make the current amount minus the current coin
            ways[i] += ways[i - coin]
    # Return the number of ways to make the target amount
    return ways[amount]
# Example usage:
coins = [1, 2, 5]
amount = 5
print(f"Number of ways to make {amount} using coins {coins}: {coin_change_ways(coins, amount)}")
# Time complexity analysis:
# The time complexity of this solution is O(n*m), where n is the target amount and m is the number of coin denominations.
# This is because we have two nested loops, one iterating over each coin denomination and the other iterating from the coin denomination to the target amount.
# Space complexity analysis:
# The space complexity of this solution is O(n), where n is the target amount.
# This is because we need to store the number of ways to make each amount from 0 to the target amount in the `ways` list.