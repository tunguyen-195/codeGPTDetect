def sieve_of_eratosthenes(n: int):
    """
    Implement the Sieve of Eratosthenes algorithm to find all primes up to n.
    """
    if n < 2:
        raise ValueError("Input must be greater than or equal to 2")
    # Create a boolean array, prime, of size n+1
    prime = [True] * (n + 1)
    prime[0] = prime[1] = False
    # Iterate from 2 to sqrt(n)
    for p in range(2, int(n ** 0.5) + 1):
        # If p is a prime, mark as composite all the multiples of p
        if prime[p]:
            # Start from p*p because all the multiples of p less than p*p have already been marked
            for i in range(p * p, n + 1, p):
                prime[i] = False
    # Return a list of all prime numbers in the range [2, n]
    return [p for p in range(2, n + 1) if prime[p]]
def main():
    # Example usage
    n = 30
    primes = sieve_of_eratosthenes(n)
    print(f"Primes up to {n}: {primes}")
if __name__ == "__main__":
    main()