from typing import Any
class Deque:
    """
    A class to implement Deque (Double-ended Queue) data structure.
    """
    def __init__(self):
        """
        Initializes an empty deque.
        """
        self.deque = []
    def is_empty(self):
        """
        Checks if the deque is empty.
        bool: True if the deque is empty, False otherwise.
        """
        return len(self.deque) == 0
    def add_front(self, value: Any):
        """
        Adds an element to the front of the deque.
        TypeError: If the input is None.
        """
        if value is None:
            raise TypeError("Input cannot be None")
        self.deque.insert(0, value)
    def add_rear(self, value: Any):
        """
        Adds an element to the rear of the deque.
