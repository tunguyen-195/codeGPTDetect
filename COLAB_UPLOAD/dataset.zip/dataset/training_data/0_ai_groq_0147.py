import heapq
from typing import Any, Tuple
class PriorityQueue:
    """
    A class to implement a Priority Queue using heapq.
    """
    def __init__(self):
        """
        Initialize an empty Priority Queue.
        """
        self.queue = []
    def push(self, item: Any, priority: int):
        """
        Push an item onto the Priority Queue with a given priority.
        TypeError: If the priority is not an integer.
        """
        if not isinstance(priority, int):
            raise TypeError("Priority must be an integer")
        # Push the item and priority onto the queue as a tuple
        heapq.heappush(self.queue, (priority, item))
    def pop(self):
        """
        Pop the item with the highest priority from the Priority Queue.
        Tuple[int, Any]: A tuple containing the priority and the item.
        IndexError: If the queue is empty.
        """
        if not self.queue:
            raise IndexError("Queue is empty")