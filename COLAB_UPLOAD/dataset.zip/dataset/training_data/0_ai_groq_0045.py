def knapsack(weights: list[int], values: list[int], capacity: int):
    """
    Solves the 0-1 Knapsack problem using dynamic programming.
    """
    # Check if the input lists are of the same length
    if len(weights) != len(values):
        raise ValueError("The input lists must be of the same length.")
    # Create a 2D table to store the results of subproblems
    # The table has (len(weights) + 1) rows and (capacity + 1) columns
    dp = [[0] * (capacity + 1) for _ in range(len(weights) + 1)]
    # Fill the table in a bottom-up manner
    for i in range(1, len(weights) + 1):
        for w in range(1, capacity + 1):
            # If the weight of the current item is greater than the current capacity,
            # we cannot include it in the knapsack
            if weights[i - 1] > w:
                # The maximum value is the same as the maximum value without the current item
                dp[i][w] = dp[i - 1][w]
            else:
                # The maximum value is the maximum of two options:
                # 1. Exclude the current item
                # 2. Include the current item
                dp[i][w] = max(dp[i - 1][w], values[i - 1] + dp[i - 1][w - weights[i - 1]])
    # The maximum value that can be put in the knapsack is stored in the last cell of the table
    return dp[-1][-1]
# Example usage:
weights = [2, 3, 4, 5]
values = [10, 20, 30, 40]
capacity = 10
max_value = knapsack(weights, values, capacity)
print(f"Maximum value: {max_value}")
# Time complexity: O(nW), where n is the number of items and W is the capacity of the knapsack
# Space complexity: O(nW), where n is the number of items and W is the capacity of the knapsack