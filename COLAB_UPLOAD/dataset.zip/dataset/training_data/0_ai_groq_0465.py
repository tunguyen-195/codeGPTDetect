def insertion_sort(arr: list):
    """
    Sorts an array using Insertion Sort with binary search optimization.
    Time complexity:
        - Best case: O(n log n) due to binary search
        - Average case: O(n^2) due to the need to shift elements in the unsorted portion
        - Worst case: O(n^2) when the input array is reverse sorted
    """
    if not isinstance(arr, list) or len(arr) <= 1:
        return arr
    for i in range(1, len(arr)):
        key = arr[i]
        j = binary_search(arr, key, 0, i)
        # Shift elements to the right to make space for the key
        arr = arr[:j] + [key] + arr[j:i] + arr[i+1:]
        # Update the sorted portion
        arr[j:i+1] = sorted(arr[j:i+1])
    return arr
def binary_search(arr: list, key: int, low: int, high: int):
    """
    Finds the insertion point for the key in the sorted portion of the array.
    """
    if not isinstance(arr, list) or low > high:
        raise ValueError("Invalid input")
    while low <= high:
        mid = (low + high) // 2
        if arr[mid] == key:
            return mid
        elif arr[mid] < key:
            low = mid + 1
        else:
            high = mid - 1
