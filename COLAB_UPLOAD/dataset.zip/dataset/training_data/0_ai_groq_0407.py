from typing import Dict
def longest_substring_without_repeating_characters(s: str):
    """
    This function finds the longest substring without repeating characters.
    """
    if not isinstance(s, str):
        raise ValueError("Input must be a string")
    if not s:
        return ""
    # Initialize two pointers for the sliding window
    left = 0
    max_length = 0
    max_substring = ""
    char_index: Dict[str, int] = {}
    for right, char in enumerate(s):
        # If the character is already in the window, update the left pointer
        if char in char_index and char_index[char] >= left:
            left = char_index[char] + 1
        # Update the character index
        char_index[char] = right
        # Update the maximum length and substring if necessary
        if right - left + 1 > max_length:
            max_length = right - left + 1
            max_substring = s[left:right + 1]
    return max_substring