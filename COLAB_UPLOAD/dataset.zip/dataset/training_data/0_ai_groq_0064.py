def calculate_z_array(string: str):
    """
    Calculate the Z-array for a given string.
    The Z-array is an array where the value at each index i represents the length
    of the longest substring starting at i that matches a prefix of the string.
    """
    n = len(string)
    z = [0] * n
    left = right = 0
    # Initialize the Z-array for the first character
    z[0] = n
    # Iterate over the string to fill the Z-array
    for i in range(1, n):
        # If the current character is within the current Z-box
        if i <= right:
            # Calculate the minimum value between the current Z-value and the
            # remaining Z-box length
            z[i] = min(right - i + 1, z[i - left])
        # Try to extend the current Z-value
        while i + z[i] < n and string[z[i]] == string[i + z[i]]:
            z[i] += 1
        # If the current Z-value exceeds the current Z-box, update the Z-box
        if i + z[i] - 1 > right:
            left = i
            right = i + z[i] - 1
    return z
def z_algorithm(string: str, pattern: str):
    """
    Find all occurrences of a pattern in a string using the Z-algorithm.
    """
    # Concatenate the pattern and string with a special character in between