from typing import Dict, List, Tuple
class WeightedGraph:
    """
    A class representing a weighted graph with edge weights.
    
                                           The inner dictionary's keys are the adjacent vertices and its values are the edge weights.
    """
    def __init__(self, vertices: int):
        """
        Initializes a weighted graph with the given number of vertices.
        """
        self.vertices = vertices
        self.edges = {i: {} for i in range(vertices)}
    def add_edge(self, u: int, v: int, weight: float):
        """
        Adds an edge to the graph between vertices u and v with the given weight.
        ValueError: If the vertices are not in the graph.
        """
        if u < 0 or v < 0 or u >= self.vertices or v >= self.vertices:
            raise ValueError("Vertices must be in the range [0, vertices)")
        
        self.edges[u][v] = weight
        self.edges[v][u] = weight  # For undirected graph, add the reverse edge as well
    def remove_edge(self, u: int, v: int):
        """
        Removes the edge between vertices u and v.
