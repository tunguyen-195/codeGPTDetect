from typing import List
def partition(s: str):
    """
    Partition a string into all possible palindromic sub-strings.
    List[List[str]]: A list of lists, where each sublist contains a partition of the input string into palindromic sub-strings.
    Time complexity: O(n^3) due to the two nested loops and the recursive call inside the is_palindrome function.
    Space complexity: O(n^2) for storing the dynamic programming table and the recursion stack.
    """
    def is_palindrome(sub_s: str):
        """
        Check if a string is a palindrome.
        bool: True if the string is a palindrome, False otherwise.
        """
        return sub_s == sub_s[::-1]
    n = len(s)
    dp = [[False] * n for _ in range(n)]
    partitions = [[] for _ in range(n)]
    # Initialize the diagonal of the dp table to True, since single characters are always palindromes
    for i in range(n):
        dp[i][i] = True
        partitions[i] = [s[i]]
    # Fill the dp table in a bottom-up manner
    for length in range(2, n + 1):
        for i in range(n - length + 1):
            j = i + length - 1
            if length == 2:
                # For substrings of length 2, check if they are palindromes
                dp[i][j] = is_palindrome(s[i:j+1])
                if dp[i][j]: