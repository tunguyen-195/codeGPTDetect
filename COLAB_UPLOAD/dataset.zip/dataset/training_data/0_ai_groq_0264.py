def selection_sort(arr: list):
    """
    Sorts an array in ascending order using the Selection Sort algorithm.
    Time complexity:
    - Best-case: O(n^2) when the array is already sorted
    - Average-case: O(n^2) when the array is randomly ordered
    - Worst-case: O(n^2) when the array is sorted in reverse order
    Space complexity: O(1) as it only uses a constant amount of additional space
    :param arr: The input array to be sorted
    :raises TypeError: If the input is not a list
    """
    # Check if input is a list
    if not isinstance(arr, list):
        raise TypeError("Input must be a list")
    # Get the length of the array
    n = len(arr)
    # Iterate over the array
    for i in range(n):
        # Assume the current element is the smallest
        min_idx = i
        # Find the smallest element in the unsorted part of the array
        for j in range(i + 1, n):
            # If a smaller element is found, update the minimum index
            if arr[j] < arr[min_idx]:
                min_idx = j
        # Swap the smallest element with the current element
        arr[i], arr[min_idx] = arr[min_idx], arr[i]
# Example usage:
arr = [64, 34, 25, 12, 22, 11, 90]
print("Original array:", arr)
selection_sort(arr)