def reverse_words(sentence: str):
    """
    Reverses the order of words in a sentence.
    str: The sentence with words in reverse order.
    ValueError: If the input sentence is empty.
    TypeError: If the input is not a string.
    """
    if not isinstance(sentence, str):
        raise TypeError("Input must be a string.")
    if not sentence.strip():
        raise ValueError("Input sentence cannot be empty.")
    # Split the sentence into words
    words = sentence.split()
    # Reverse the list of words
    reversed_words = words[::-1]
    # Join the reversed words back into a sentence
    reversed_sentence = ' '.join(reversed_words)
    return reversed_sentence
# Example usage
print(reverse_words("Hello World"))  # Output: "World Hello"
print(reverse_words(""))  # Raises ValueError: "Input sentence cannot be empty."
print(reverse_words(123))  # Raises TypeError: "Input must be a string."