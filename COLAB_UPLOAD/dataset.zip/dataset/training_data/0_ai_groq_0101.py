from typing import List, Tuple
def job_sequencing(jobs: List[Tuple[str, int, int]]):
    """
    Solves the Job Sequencing problem using a greedy approach.
    jobs: A list of tuples, where each tuple contains the job ID, deadline, and profit.
    A tuple containing the maximum profit and the sequence of jobs that yields this profit.
    """
    # Sort the jobs based on their profits in descending order
    jobs.sort(key=lambda x: x[2], reverse=True)
    # Initialize a list to store the job sequence and a variable to store the maximum profit
    max_profit = 0
    job_sequence = []
    slots = [False] * len(jobs)
    # Iterate over the sorted jobs
    for job_id, deadline, profit in jobs:
        # Find a free slot for the current job
        for i in range(min(deadline - 1, len(jobs) - 1), -1, -1):
            if not slots[i]:
                # Assign the job to the free slot
                slots[i] = True
                max_profit += profit
                job_sequence.append(job_id)
                break
    return max_profit, job_sequence
def main():
    # Example usage:
    jobs = [("a", 2, 100), ("b", 1, 19), ("c", 2, 27), ("d", 1, 25), ("e", 3, 15)]
    max_profit, job_sequence = job_sequencing(jobs)
    print("Maximum Profit:", max_profit)
    print("Job Sequence:", job_sequence)
if __name__ == "__main__":
    main()