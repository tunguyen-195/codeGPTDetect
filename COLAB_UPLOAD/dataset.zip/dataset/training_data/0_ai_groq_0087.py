import sys
import heapq
from typing import Dict, List, Tuple
def dijkstra(graph: Dict[str, Dict[str, int]], start: str):
    """
    Dijkstra's algorithm to find the shortest path from the start node to all other nodes in the graph.
    graph: A dictionary representing the graph, where each key is a node and its corresponding value is another dictionary.
           The inner dictionary has the neighboring nodes as keys and the edge weights as values.
    start: The node to start the search from.
    A tuple of two dictionaries. The first dictionary contains the shortest distances from the start node to all other nodes.
    The second dictionary contains the previous node in the shortest path from the start node to each node.
    """
    # Initialize the distance to the start node as 0 and all other nodes as infinity
    distances: Dict[str, int] = {node: 0 if node == start else sys.maxsize for node in graph}
    # Initialize the previous node in the shortest path as None for all nodes
    previous: Dict[str, str] = {node: None for node in graph}
    # Create a priority queue to store nodes to be processed, with the start node as the first node
    priority_queue: List[Tuple[int, str]] = [(0, start)]
    while priority_queue:
        # Extract the node with the minimum distance from the priority queue
        current_distance, current_node = heapq.heappop(priority_queue)
        # If the current distance is greater than the already known distance, skip this node
        if current_distance > distances[current_node]:
            continue
        # Iterate over the neighbors of the current node
        for neighbor, weight in graph[current_node].items():
            # Calculate the distance to the neighbor through the current node
            distance = current_distance + weight
            # If this distance is less than the already known distance, update the distance and previous node
            if distance < distances[neighbor]:
                distances[neighbor] = distance
                previous[neighbor] = current_node