def bubble_sort(arr: list):
    """
    Sorts an array in ascending order using the Bubble Sort algorithm with early termination.
    list: The sorted list.
    Time Complexity:
    - Best-case: O(n) when the input list is already sorted.
    - Average-case: O(n^2) for random input lists.
    - Worst-case: O(n^2) when the input list is sorted in reverse order.
    TypeError: If the input is not a list.
    ValueError: If the list contains non-comparable elements.
    """
    # Check if input is a list
    if not isinstance(arr, list):
        raise TypeError("Input must be a list.")
    # Create a copy of the input list to avoid modifying it in-place
    arr = arr.copy()
    # Get the length of the input list
    n = len(arr)
    # Iterate over the list until no more swaps are needed
    for i in range(n):
        # Initialize a flag to track if any swaps were made
        swapped = False
        # Iterate over the unsorted portion of the list
        for j in range(n - i - 1):
            # Check if the current element is greater than the next element
            try:
                if arr[j] > arr[j + 1]:
                    # Swap the elements
                    arr[j], arr[j + 1] = arr[j + 1], arr[j]
                    # Set the flag to indicate a swap was made
                    swapped = True