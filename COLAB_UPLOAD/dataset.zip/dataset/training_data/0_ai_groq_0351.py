class MaxHeap:
    """
    A class to implement a Max Heap data structure.
    Methods:
        __init__: Initializes the max heap.
        insert: Inserts a new element into the max heap.
        extract_max: Removes and returns the maximum element from the max heap.
        heapify: Transforms a list into a max heap.
        _heapify_up: Moves an element up the heap to maintain the max heap property.
        _heapify_down: Moves an element down the heap to maintain the max heap property.
    """
    def __init__(self, iterable: list = None):
        """
        Initializes the max heap.
        """
        self.heap = []
        if iterable is not None:
            self.heapify(iterable)
    def insert(self, value: int):
        """
        Inserts a new element into the max heap.
        """
        if not isinstance(value, int):
            raise TypeError("Value must be an integer.")
        self.heap.append(value)
        self._heapify_up(len(self.heap) - 1)
    def extract_max(self):
        """
        Removes and returns the maximum element from the max heap.
        """
        if not self.heap:
            raise IndexError("Heap is empty.")
        if len(self.heap) == 1: