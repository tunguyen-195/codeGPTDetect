from typing import Dict, List, Optional
class Graph:
    """
    A class to represent a graph using adjacency list.
    ----------
    adjacency_list : Dict[int, List[int]]
        A dictionary where each key is a node and its corresponding value is a list of its neighbors.
    Methods:
    -------
    add_node(node: int):
        Adds a new node to the graph.
    add_edge(node1: int, node2: int):
        Adds a new edge between two nodes in the graph.
    dfs(start_node: int):
        Performs a depth-first search traversal of the graph starting from the given node.
    bfs(start_node: int):
        Performs a breadth-first search traversal of the graph starting from the given node.
    """
    def __init__(self):
        """
        Initializes an empty graph.
        """
        self.adjacency_list: Dict[int, List[int]] = {}
    def add_node(self, node: int):
        """
        Adds a new node to the graph.
        ----
        node : int
            The node to be added.
        """
        if node not in self.adjacency_list:
            self.adjacency_list[node] = []
    def add_edge(self, node1: int, node2: int):