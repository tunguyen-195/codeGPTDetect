def longest_palindrome_substring(s: str):
    """
    This function finds the longest palindromic substring in a given string.
    """
    if not isinstance(s, str):
        raise TypeError("Input must be a string.")
    def expand_around_center(left: int, right: int):
        """
        Expands around the center of the palindrome to find the longest palindromic substring.
        """
        while left >= 0 and right < len(s) and s[left] == s[right]:
            left -= 1
            right += 1
        return s[left + 1:right]
    longest_palindrome = ""
    for i in range(len(s)):
        # Odd length palindrome
        palindrome = expand_around_center(i, i)
        if len(palindrome) > len(longest_palindrome):
            longest_palindrome = palindrome
        # Even length palindrome
        palindrome = expand_around_center(i, i + 1)
        if len(palindrome) > len(longest_palindrome):
            longest_palindrome = palindrome
    return longest_palindrome
# Example usage:
print(longest_palindrome_substring("babad"))  # Output: "bab"
print(longest_palindrome_substring("cbbd"))   # Output: "bb"
print(longest_palindrome_substring("a"))      # Output: "a"