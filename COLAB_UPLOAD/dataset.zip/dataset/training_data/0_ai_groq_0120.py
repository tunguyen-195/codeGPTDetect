def calculate_gcd(a: int, b: int):
    """
    Calculate the Greatest Common Divisor (GCD) of two integers using the Euclidean algorithm.
    """
    # Check if inputs are integers
    if not isinstance(a, int) or not isinstance(b, int):
        raise TypeError("Both inputs must be integers.")
    # Check if inputs are non-negative
    if a < 0 or b < 0:
        raise ValueError("Both inputs must be non-negative.")
    # Base case: If b is zero, the GCD is a
    while b != 0:
        # Swap a and b, and replace b with the remainder of a divided by b
        # This is the core of the Euclidean algorithm
        a, b = b, a % b
    # At this point, b is zero, so a is the GCD
    return a
# Example usage
if __name__ == "__main__":
    try:
        print(calculate_gcd(48, 18))  # Output: 6
        print(calculate_gcd(101, 103))  # Output: 1
    except (TypeError, ValueError) as e:
        print(f"Error: {e}")