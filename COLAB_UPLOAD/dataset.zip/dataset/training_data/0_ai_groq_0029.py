def selection_sort(arr: list[int]):
    """
    Sorts an array in ascending order using the Selection Sort algorithm.
    Time complexity:
    - Best-case: O(n^2)
    - Average-case: O(n^2)
    - Worst-case: O(n^2)
    Space complexity: O(1)
    :param arr: A list of integers to be sorted
    :return: A sorted list of integers
    :raises ValueError: If the input array is empty
    """
    # Check if the input array is empty
    if not arr:
        raise ValueError("Input array is empty")
    # Iterate over the array
    for i in range(len(arr)):
        # Initialize the minimum index to the current index
        min_index = i
        
        # Find the minimum element in the unsorted part of the array
        for j in range(i + 1, len(arr)):
            # If a smaller element is found, update the minimum index
            if arr[j] < arr[min_index]:
                min_index = j
        
        # Swap the found minimum element with the first element of the unsorted part
        arr[i], arr[min_index] = arr[min_index], arr[i]
    
    return arr
def main():
    # Example usage
    try:
        arr = [64, 34, 25, 12, 22, 11, 90]
        print("Original array:", arr)
        sorted_arr = selection_sort(arr)