from collections import deque
from typing import Dict, List, Tuple
class Graph:
    """
    A graph data structure representing a weighted graph.
    """
    def __init__(self):
        """
        Initializes an empty graph.
        """
        self.adjacency_list = {}
    def add_edge(self, node1: int, node2: int, weight: int):
        """
        Adds an edge between two nodes in the graph.
        """
        if node1 not in self.adjacency_list:
            self.adjacency_list[node1] = []
        if node2 not in self.adjacency_list:
            self.adjacency_list[node2] = []
        self.adjacency_list[node1].append((node2, weight))
        self.adjacency_list[node2].append((node1, weight))  # Assuming an undirected graph
    def bfs_shortest_path(self, start_node: int, end_node: int):
        """
        Finds the shortest path between two nodes using Breadth-First Search.
        """
        if start_node not in self.adjacency_list:
            raise ValueError("Start node is not in the graph")
        if end_node not in self.adjacency_list:
            raise ValueError("End node is not in the graph")
        # Create a queue for BFS and enqueue the start node
        queue = deque([(start_node, [start_node])])