from collections import OrderedDict
class LRUCache:
    """
    A class to implement LRU Cache.
    """
    def __init__(self, capacity: int):
        """
        Initializes the LRU Cache.
        """
        self.capacity = capacity
        self.cache = OrderedDict()
    def get(self, key: int):
        """
        Retrieves the value for the given key from the cache.
        """
        if key in self.cache:
            # Move the key to the end to mark it as recently used
            value = self.cache.pop(key)
            self.cache[key] = value
            return value
        else:
            return -1
    def put(self, key: int, value: int):
        """
        Adds or updates the value for the given key in the cache.
        """
        if key in self.cache:
            # Remove the key to update its value
            self.cache.pop(key)
        elif len(self.cache) >= self.capacity:
            # Remove the least recently used item if the cache is full
            self.cache.popitem(last=False)