def longest_common_prefix(strs: list[str]):
    """
    Finds the longest common prefix among a list of strings.
    str: The longest common prefix.
    TypeError: If the input is not a list of strings.
    """
    # Check if input is a list
    if not isinstance(strs, list):
        raise TypeError("Input must be a list of strings.")
    # Check if all elements in the list are strings
    if not all(isinstance(s, str) for s in strs):
        raise TypeError("Input must be a list of strings.")
    # Handle edge case where the list is empty
    if not strs:
        return ""
    # Sort the list of strings to easily find the common prefix
    # This works because the common prefix will be the same for all strings
    # and sorting will put the most similar strings next to each other
    strs.sort()
    # Take the first and last string from the sorted list
    # The common prefix will be a prefix of both of these strings
    first_str = strs[0]
    last_str = strs[-1]
    # Initialize the common prefix as an empty string
    common_prefix = ""
    # Iterate over the characters in the first string
    for i in range(len(first_str)):
        # If the character at the current position in the first string
        # is the same as the character at the same position in the last string,