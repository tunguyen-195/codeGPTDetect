from collections import OrderedDict
class LRUCache:
    """
    A Least Recently Used (LRU) cache implementation using OrderedDict.
    The cache is initialized with a maximum size. When the cache is full and
    a new item is added, the least recently used item is removed to make room
    for the new item.
    """
    def __init__(self, max_size: int):
        """
        Initialize the LRU cache with a maximum size.
        """
        if not isinstance(max_size, int) or max_size <= 0:
            raise ValueError("max_size must be a positive integer")
        self.max_size = max_size
        self.cache = OrderedDict()
    def get(self, key: any):
        """
        Retrieve a value from the cache by its key.
        If the key exists in the cache, move it to the end to mark it as recently used.
        """
        if key in self.cache:
            value = self.cache.pop(key)
            self.cache[key] = value  # move to end to mark as recently used
            return value
        return None
    def put(self, key: any, value: any):
        """
        Add a new item to the cache.
        If the key already exists in the cache, update its value and move it to the end.