from typing import Dict, List
class Graph:
    """Represents a graph using an adjacency list."""
    
    def __init__(self, num_vertices: int):
        """
        Initializes a graph with the given number of vertices.
        
        """
        self.num_vertices = num_vertices
        self.adj_list = [[] for _ in range(num_vertices)]
        self.time = 0  # Initialize the time counter
    def add_edge(self, u: int, v: int):
        """
        Adds an edge between two vertices in the graph.
        
        """
        self.adj_list[u].append(v)
        self.adj_list[v].append(u)  # For undirected graph
    def find_bridges(self):
        """
        Finds all bridges in the graph using DFS.
        
        List[List[int]]: A list of bridges, where each bridge is represented as a list of two vertices.
        """
        visited = [False] * self.num_vertices
        disc_time = [float('inf')] * self.num_vertices
        low = [float('inf')] * self.num_vertices
        parent = [-1] * self.num_vertices
        bridges = []
        def dfs(vertex: int):
            """
            Performs DFS from the given vertex.