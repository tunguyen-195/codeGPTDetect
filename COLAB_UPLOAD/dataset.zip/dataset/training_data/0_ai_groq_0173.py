def exponential_search(arr: list, target: int):
    """
    Exponential Search for unbounded arrays.
    This function performs an exponential search on an unbounded array to find the range where the target element may be present.
    It then performs a binary search in the determined range to find the target element.
    """
    if not arr:
        raise ValueError("Input list is empty")
    # If the target is at the first index, return it
    if arr[0] == target:
        return 0
    # Initialize the range boundaries
    i = 1
    # Exponentially increase the range until we find the target or exceed it
    while i < len(arr) and arr[i] <= target:
        i *= 2
    # If we exceeded the target, adjust the range
    return binary_search(arr, target, i // 2, min(i, len(arr) - 1))
def binary_search(arr: list, target: int, low: int, high: int):
    """
    Binary Search for a sorted list.
    This function performs a binary search on a sorted list to find the target element.
    """
    while low <= high:
        # Calculate the middle index
        mid = (low + high) // 2
        # If the target is at the middle index, return it
        if arr[mid] == target:
            return mid
        # If the target is less than the middle element, search the left half
        elif arr[mid] > target:
            high = mid - 1