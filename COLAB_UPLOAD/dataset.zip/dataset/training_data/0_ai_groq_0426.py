import sys
import heapq
class Graph:
    """
    A class representing a graph data structure.
    
    """
    def __init__(self, num_vertices):
        """
        Initializes a graph with the given number of vertices.
        
        """
        self.num_vertices = num_vertices
        self.adjacency_list = {i: [] for i in range(num_vertices)}
    def add_edge(self, u: int, v: int, weight: int):
        """
        Adds an edge to the graph.
        
        """
        self.adjacency_list[u].append((v, weight))
        self.adjacency_list[v].append((u, weight))
    def prim_mst(self):
        """
        Computes the minimum spanning tree of the graph using Prim's algorithm.
        
        list: A list of edges in the minimum spanning tree.
        """
        # Create a set to store the visited vertices
        visited = set()
        