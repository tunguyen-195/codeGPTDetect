from collections import deque
from typing import Any
class Queue:
    """
    A class to implement a Queue data structure using collections.deque.
    """
    def __init__(self):
        """
        Initializes an empty queue.
        """
        self.queue = deque()
    def enqueue(self, value: Any):
        """
        Adds an element to the end of the queue.
        """
        self.queue.append(value)
    def dequeue(self):
        """
        Removes an element from the front of the queue.
        Any: The removed element.
        IndexError: If the queue is empty.
        """
        if self.is_empty():
            raise IndexError("Cannot dequeue from an empty queue")
        return self.queue.popleft()
    def is_empty(self):
        """
        Checks if the queue is empty.
