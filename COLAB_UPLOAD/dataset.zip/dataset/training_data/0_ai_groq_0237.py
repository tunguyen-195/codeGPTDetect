class Node:
    """Represents a node in the Red-Black Tree.
    """
    def __init__(self, key, value, color: str = 'R'):
        self.key = key
        self.value = value
        self.color = color
        self.left = None
        self.right = None
        self.parent = None
class RedBlackTree:
    """Represents a Red-Black Tree data structure.
    """
    def __init__(self):
        self.root = None
    def pre_order_traversal(self, node: Node):
        """Performs a pre-order traversal of the tree.
        """
        if node:
            print(f"({node.key}, {node.value}, {node.color})")
            self.pre_order_traversal(node.left)
            self.pre_order_traversal(node.right)
    def post_order_traversal(self, node: Node):
        """Performs a post-order traversal of the tree.
        """
        if node:
            self.post_order_traversal(node.left)
            self.post_order_traversal(node.right)
            print(f"({node.key}, {node.value}, {node.color})")
    def in_order_traversal(self, node: Node):