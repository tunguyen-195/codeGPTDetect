from collections import deque
def sliding_window_max(nums: list[int], k: int):
    """
    Returns the maximum element in each window of size k in the given list.
    - nums: The list of integers.
    - k: The size of the window.
    - A list of maximum elements in each window.
    - ValueError: If k is larger than the list length.
    """
    if k > len(nums):
        raise ValueError("k cannot be larger than the list length")
    # Initialize the deque and result list
    dq = deque()
    result = []
    # Process the first window
    for i in range(k):
        # Remove elements from the back of the deque that are smaller than the current element
        while dq and nums[dq[-1]] < nums[i]:
            dq.pop()
        dq.append(i)
    # Process the rest of the list
    for i in range(k, len(nums)):
        # Add the maximum element of the previous window to the result
        result.append(nums[dq[0]])
        # Remove elements from the front of the deque that are out of the current window
        while dq and dq[0] <= i - k:
            dq.popleft()
        # Remove elements from the back of the deque that are smaller than the current element
        while dq and nums[dq[-1]] < nums[i]:
            dq.pop()
        dq.append(i)