def counting_sort(arr: list[int]):
    """
    Sorts an integer array using the Counting Sort algorithm.
    Time complexity:
    - Best case: O(n + k), where n is the number of elements in the array and k is the range of input.
    - Worst case: O(n + k)
    Space complexity: O(n + k)
    :param arr: The input integer array to be sorted.
    :return: A new sorted integer array.
    """
    if not arr:
        return []
    # Find the maximum element in the array to determine the size of the count array
    max_element = max(arr)
    # Create a count array of size max_element + 1 to store the count of each element
    count_arr = [0] * (max_element + 1)
    # Count the occurrences of each element in the input array
    for num in arr:
        count_arr[num] += 1
    # Calculate the cumulative count of each element to determine the position in the output array
    for i in range(1, len(count_arr)):
        count_arr[i] += count_arr[i - 1]
    # Create the output array by placing each element at its correct position based on the cumulative count
    output_arr = [0] * len(arr)
    for num in arr:
        output_arr[count_arr[num] - 1] = num
        count_arr[num] -= 1
    return output_arr
# Example usage:
arr = [4, 2, 2, 8, 3, 3, 1]