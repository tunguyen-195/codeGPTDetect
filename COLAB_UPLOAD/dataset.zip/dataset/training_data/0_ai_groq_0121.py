def calculate_lcm(num1: int, num2: int):
    """
    Calculate the Least Common Multiple (LCM) of two numbers.
    """
    # Check if inputs are integers
    if not isinstance(num1, int) or not isinstance(num2, int):
        raise TypeError("Both inputs must be integers.")
    
    # Check if inputs are positive
    if num1 < 1 or num2 < 1:
        raise ValueError("Both inputs must be positive integers.")
    # Calculate the Greatest Common Divisor (GCD) of num1 and num2
    def calculate_gcd(a: int, b: int):
        """
        Calculate the Greatest Common Divisor (GCD) of two numbers using the Euclidean algorithm.
        """
        while b:
            # Swap a and b, and replace b with the remainder of a divided by b
            a, b = b, a % b
        return a
    # Calculate the LCM using the formula: lcm(a, b) = |a * b| / gcd(a, b)
    lcm = abs(num1 * num2) // calculate_gcd(num1, num2)
    return lcm
# Example usage:
if __name__ == "__main__":
    num1 = 12
    num2 = 15
    try:
        lcm = calculate_lcm(num1, num2)
        print(f"The LCM of {num1} and {num2} is {lcm}.")
    except (TypeError, ValueError) as e:
        print(f"Error: {e}")