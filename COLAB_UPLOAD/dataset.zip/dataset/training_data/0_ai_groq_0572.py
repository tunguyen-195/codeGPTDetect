class InterpolationSearch:
    """
    Interpolation Search algorithm implementation.
    Interpolation search is an improvement over Binary Search for cases where the elements in the array are uniformly distributed.
    """
    def __init__(self, arr: list):
        """
        Initializes the Interpolation Search object.
        """
        if not arr:
            raise ValueError("Input list cannot be empty")
        self.arr = arr
        self.n = len(arr)
    def interpolation_search(self, target: any):
        """
        Searches for the target element in the input list using Interpolation Search.
        """
        low = 0
        high = self.n - 1
        while low <= high and target >= self.arr[low] and target <= self.arr[high]:
            # Calculate the index using interpolation formula
            index = low + ((target - self.arr[low]) * (high - low)) // (self.arr[high] - self.arr[low])
            # If the target element is found, return its index
            if self.arr[index] == target:
                return index
            # If the target element is less than the element at the calculated index,
            # then move the high pointer to the left
            if self.arr[index] > target:
                high = index - 1
            # If the target element is greater than the element at the calculated index,