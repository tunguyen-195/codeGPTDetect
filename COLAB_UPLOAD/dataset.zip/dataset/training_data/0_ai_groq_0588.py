def rod_cutting(prices: list[int], n: int):
    """
    Solve the Rod Cutting problem using dynamic programming.
    int: The maximum revenue that can be obtained by cutting the rod.
    Time Complexity: O(n^2)
    Space Complexity: O(n)
    """
    # Initialize a list to store the maximum revenue for each rod length
    dp = [0] * (n + 1)
    # Iterate over each possible rod length
    for i in range(1, n + 1):
        # Initialize the maximum revenue for the current rod length to 0
        max_revenue = 0
        # Iterate over each possible cut length
        for j in range(i):
            # Calculate the revenue for the current cut
            revenue = prices[j] + dp[i - j - 1]
            # Update the maximum revenue if the current revenue is higher
            max_revenue = max(max_revenue, revenue)
        # Store the maximum revenue for the current rod length
        dp[i] = max_revenue
    # Return the maximum revenue for the given rod length
    return dp[n]
# Example usage
prices = [0, 1, 5, 8, 9, 10, 17, 17, 20]
n = 8
print(f"Maximum revenue: {rod_cutting(prices, n)}")