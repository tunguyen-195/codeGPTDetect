def find_all_substrings(input_string: str):
    """
    Returns a list of all substrings in the input string.
    """
    if not isinstance(input_string, str):
        raise TypeError("Input must be a string.")
    # Initialize an empty list to store substrings
    substrings = []
    # Iterate over the string, considering each character as a potential start of a substring
    for i in range(len(input_string)):
        # For each start character, iterate over the rest of the string to consider all substrings
        for j in range(i + 1, len(input_string) + 1):
            # Append the substring to the list
            substrings.append(input_string[i:j])
    # Return the list of substrings
    return substrings
# Example usage:
input_string = "hello"
print(find_all_substrings(input_string))
# Output: ['h', 'he', 'hel', 'hell', 'hello', 'e', 'el', 'ell', 'llo', 'lo', 'o']
input_string = ""
print(find_all_substrings(input_string))
# Output: ['']
input_string = None
try:
    print(find_all_substrings(input_string))
except TypeError as e:
    print(e)
# Output: Input must be a string.