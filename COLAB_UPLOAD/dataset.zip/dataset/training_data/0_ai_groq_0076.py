from typing import List, Tuple
def merge_intervals(intervals: List[Tuple[int, int]]):
    """
    Merge overlapping intervals in a list of intervals.
    intervals: A list of tuples, where each tuple represents an interval with a start and end value.
    A list of merged intervals.
    ValueError: If the input intervals are not in the correct format.
    """
    # Check if the input intervals are valid
    if not all(isinstance(interval, tuple) and len(interval) == 2 for interval in intervals):
        raise ValueError("Invalid input intervals. Intervals must be tuples with two values.")
    # Sort the intervals by their start value
    # This is done to ensure that we can merge overlapping intervals in a single pass
    intervals.sort(key=lambda x: x[0])
    # Initialize the merged intervals with the first interval
    merged_intervals = [intervals[0]]
    # Iterate over the remaining intervals
    for current_interval in intervals[1:]:
        # Get the last merged interval
        last_merged_interval = merged_intervals[-1]
        # Check if the current interval overlaps with the last merged interval
        if current_interval[0] <= last_merged_interval[1]:
            # Merge the current interval with the last merged interval
            merged_intervals[-1] = (last_merged_interval[0], max(last_merged_interval[1], current_interval[1]))
        else:
            # Add the current interval to the list of merged intervals
            merged_intervals.append(current_interval)
    return merged_intervals
# Example usage