def merge_sort(arr: list[int]):
    """
    Sorts the input list in-place using the MergeSort algorithm.
    Time complexity: O(n log n) in all cases (best, average, worst)
    Space complexity: O(n) for auxiliary space
    :param arr: The list to be sorted
    :return: None
    """
    _merge_sort_helper(arr, 0, len(arr) - 1)
def _merge_sort_helper(arr: list[int], low: int, high: int):
    """
    Recursive helper function for MergeSort.
    :param arr: The list to be sorted
    :param low: The starting index of the current subarray
    :param high: The ending index of the current subarray
    :return: None
    """
    # Base case: If the subarray has 1 or 0 elements, it is already sorted
    if low >= high:
        return
    # Find the middle index to split the subarray into two halves
    mid = (low + high) // 2
    # Recursively sort the left and right halves
    _merge_sort_helper(arr, low, mid)
    _merge_sort_helper(arr, mid + 1, high)
    # Merge the sorted halves back into the original array
    _merge(arr, low, mid, high)
def _merge(arr: list[int], low: int, mid: int, high: int):
    """
    Merges two sorted subarrays into a single sorted subarray.
    :param arr: The original list