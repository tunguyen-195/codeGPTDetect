class SegmentTree:
    """
    A class representing a Segment Tree data structure.
    Methods:
        __init__: Initializes the Segment Tree.
        build: Builds the Segment Tree from the input array.
        query: Performs a range query on the Segment Tree.
        update: Updates a value in the Segment Tree.
    """
    def __init__(self, array: list):
        """
        Initializes the Segment Tree.
        """
        self.n = len(array)
        if self.n == 0:
            raise ValueError("Input array cannot be empty")
        self.tree = [0] * (4 * self.n)
        self.array = array
        self.build(0, 0, self.n - 1)
    def build(self, node: int, start: int, end: int):
        """
        Builds the Segment Tree recursively.
        """
        if start == end:
            self.tree[node] = self.array[start]
        else:
            mid = (start + end) // 2
            self.build(2 * node + 1, start, mid)
            self.build(2 * node + 2, mid + 1, end)
            self.tree[node] = self.tree[2 * node + 1] + self.tree[2 * node + 2]
    def query(self, node: int, start: int, end: int, left: int, right: int):
        """
        Performs a range query on the Segment Tree.
