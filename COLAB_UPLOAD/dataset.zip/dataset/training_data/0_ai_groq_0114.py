def generate_permutations(input_string: str):
    """
    Generates all permutations of a given string.
    """
    if not isinstance(input_string, str):
        raise TypeError("Input must be a string")
    # Base case: if the string is empty or contains only one character, return a list containing the string itself
    if len(input_string) <= 1:
        return [input_string]
    # Initialize an empty list to store the permutations
    permutations = []
    # Iterate over each character in the input string
    for i, char in enumerate(input_string):
        # Remove the current character from the input string to generate the remaining string
        remaining_string = input_string[:i] + input_string[i + 1:]
        # Recursively generate all permutations of the remaining string
        for perm in generate_permutations(remaining_string):
            # Append the current character to the beginning of each permutation of the remaining string
            permutations.append(char + perm)
    return permutations
# Example usage:
if __name__ == "__main__":
    input_str = "abc"
    permutations = generate_permutations(input_str)
    print(f"Permutations of '{input_str}': {permutations}")