from typing import List, Dict
class Graph:
    """Represents a directed graph."""
    
    def __init__(self, num_vertices: int):
        """
        Initializes a graph with a specified number of vertices.
        """
        self.num_vertices = num_vertices
        self.adj_list: List[List[int]] = [[] for _ in range(num_vertices)]
        self.stack: List[int] = []
        self.visited: List[bool] = [False] * num_vertices
        self.scc_id: List[int] = [-1] * num_vertices
    def add_edge(self, u: int, v: int):
        """
        Adds a directed edge from vertex u to vertex v.
        """
        self.adj_list[u].append(v)
    def dfs(self, vertex: int):
        """
        Performs a depth-first search from a given vertex.
        """
        self.visited[vertex] = True
        for neighbor in self.adj_list[vertex]:
            if not self.visited[neighbor]:
                self.dfs(neighbor)
        self.stack.append(vertex)
    def fill_scc_id(self):
        """