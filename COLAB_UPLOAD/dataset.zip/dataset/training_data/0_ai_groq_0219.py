def max_area(heights: list[int]):
    """
    This function calculates the maximum area that can be trapped between two parallel lines.
    int: The maximum area that can be trapped.
    Time Complexity:
    O(n), where n is the number of elements in the input list.
    Space Complexity:
    O(1), as we only use a constant amount of space.
    """
    if not heights:
        return 0  # Return 0 if the input list is empty
    left, right = 0, len(heights) - 1  # Initialize two pointers, one at the start and one at the end
    max_area = 0  # Initialize the maximum area to 0
    while left < right:  # Continue until the two pointers meet
        # Calculate the width of the current area
        width = right - left
        # Calculate the height of the current area, which is the minimum of the two lines
        height = min(heights[left], heights[right])
        # Calculate the current area
        current_area = width * height
        # Update the maximum area if the current area is larger
        max_area = max(max_area, current_area)
        # Move the pointer of the shorter line towards the other pointer
        if heights[left] < heights[right]:
            left += 1
        else:
            right -= 1
    return max_area  # Return the maximum area