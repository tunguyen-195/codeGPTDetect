def trap(rain: list[int]):
    """
    Calculate the total amount of rainwater that can be trapped in a given list of heights.
    int: The total amount of rainwater that can be trapped.
    ValueError: If the input list is empty or contains negative numbers.
    """
    # Check if the input list is empty
    if not rain:
        raise ValueError("Input list cannot be empty")
    # Check if the input list contains negative numbers
    if any(height < 0 for height in rain):
        raise ValueError("Input list cannot contain negative numbers")
    # Initialize two pointers, one at the beginning and one at the end of the list
    left, right = 0, len(rain) - 1
    # Initialize the maximum heights on the left and right sides
    max_left, max_right = 0, 0
    # Initialize the total amount of trapped rainwater
    total_water = 0
    # Traverse the list from both ends
    while left <= right:
        # If the height on the left is less than the height on the right
        if rain[left] < rain[right]:
            # If the height on the left is greater than the maximum height on the left
            if rain[left] > max_left:
                # Update the maximum height on the left
                max_left = rain[left]
            else:
                # Add the trapped rainwater to the total
                total_water += max_left - rain[left]
            # Move the left pointer to the right