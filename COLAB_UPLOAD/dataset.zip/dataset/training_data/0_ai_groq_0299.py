def compute_lps_array(pattern: str):
    """
    Compute the LPS (Longest Proper Prefix which is also a Proper Suffix) array for the given pattern.
    list: The LPS array for the given pattern.
    TypeError: If the input pattern is not a string.
    ValueError: If the input pattern is an empty string.
    """
    if not isinstance(pattern, str):
        raise TypeError("Input pattern must be a string.")
    if len(pattern) == 0:
        raise ValueError("Input pattern cannot be an empty string.")
    lps = [0] * len(pattern)
    length = 0
    i = 1
    while i < len(pattern):
        if pattern[i] == pattern[length]:
            length += 1
            lps[i] = length
            i += 1
        elif length != 0:
            length = lps[length - 1]
        else:
            lps[i] = 0
            i += 1
    return lps
def compute_z_array(text: str, pattern: str):
    """
    Compute the Z-array for the given text and pattern.
