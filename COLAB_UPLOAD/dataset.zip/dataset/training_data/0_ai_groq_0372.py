def interpolation_search(arr: list[int], x: int):
    """
    Interpolation Search algorithm for uniformly distributed data.
    - arr (list[int]): The sorted list of integers to search in.
    - x (int): The target value to search for.
    - int: The index of the target value in the list if found, -1 otherwise.
    - ValueError: If the input list is not sorted.
    - TypeError: If the input list contains non-integer values.
    """
    # Check if the input list is sorted
    if arr != sorted(arr):
        raise ValueError("Input list must be sorted")
    # Check if the input list contains only integers
    if not all(isinstance(i, int) for i in arr):
        raise TypeError("Input list must contain only integers")
    # Find the position to start searching from
    low: int = 0
    high: int = len(arr) - 1
    # Continue searching until the search space is not empty
    while low <= high and x >= arr[low] and x <= arr[high]:
        # Calculate the index to search at using interpolation formula
        index: int = low + ((high - low) // (arr[high] - arr[low])) * (x - arr[low])
        # Check if the value at the calculated index is equal to the target value
        if arr[index] == x:
            return index
        # If the value at the calculated index is less than the target value, move the search space to the right
        if arr[index] < x:
            low = index + 1
        # If the value at the calculated index is greater than the target value, move the search space to the left
        else:
            high = index - 1