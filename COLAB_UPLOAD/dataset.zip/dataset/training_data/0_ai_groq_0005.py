class SegmentTree:
    """
    A class to implement Segment Tree for range queries.
    """
    def __init__(self, arr: list):
        """
        Initializes the SegmentTree object.
        """
        self.arr = arr
        self.n = len(arr)
        self.tree = [0] * (4 * self.n)
        self.build_tree(0, 0, self.n - 1)
    def build_tree(self, node: int, start: int, end: int):
        """
        Builds the segment tree.
        """
        # If the start and end indices are the same, the segment contains only one element
        if start == end:
            self.tree[node] = self.arr[start]
        else:
            # Calculate the mid index of the current segment
            mid = (start + end) // 2
            # Recursively build the left and right subtrees
            self.build_tree(2 * node + 1, start, mid)
            self.build_tree(2 * node + 2, mid + 1, end)
            # The value of the current node is the sum of the values of its children
            self.tree[node] = self.tree[2 * node + 1] + self.tree[2 * node + 2]
    def query(self, node: int, start: int, end: int, left: int, right: int):
        """
        Queries the segment tree for the sum of elements in the range [left, right].
        """
        # If the query range is outside the current segment, return 0
        if start > right or end < left: