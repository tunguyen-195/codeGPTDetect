def edit_distance(word1: str, word2: str):
    """
    Calculate the Levenshtein distance between two words using dynamic programming.
    The Levenshtein distance is a measure of the minimum number of single-character edits (insertions, deletions or substitutions) required to change one word into the other.
    Time complexity: O(m * n), where m and n are the lengths of the two words.
    Space complexity: O(m * n), where m and n are the lengths of the two words.
    """
    m, n = len(word1), len(word2)
    dp = [[0] * (n + 1) for _ in range(m + 1)]
    # Initialize the base cases
    for i in range(m + 1):
        dp[i][0] = i
    for j in range(n + 1):
        dp[0][j] = j
    # Fill in the rest of the table
    for i in range(1, m + 1):
        for j in range(1, n + 1):
            cost = 0 if word1[i - 1] == word2[j - 1] else 1
            dp[i][j] = min(
                dp[i - 1][j] + 1,  # Deletion
                dp[i][j - 1] + 1,  # Insertion
                dp[i - 1][j - 1] + cost  # Substitution
            )
    # The Levenshtein distance is stored in the bottom-right corner of the table
    return dp[m][n]