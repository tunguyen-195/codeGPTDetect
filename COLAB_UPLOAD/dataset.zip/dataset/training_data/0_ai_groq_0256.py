from typing import Dict, List, Tuple
class WeightedGraph:
    """
    A class representing a weighted graph.
    ----------
    num_vertices : int
        The number of vertices in the graph.
    adjacency_list : Dict[int, Dict[int, float]]
        A dictionary representing the adjacency list of the graph.
        Each key is a vertex, and its corresponding value is another dictionary.
        The inner dictionary's keys are neighboring vertices, and its values are the edge weights.
    Methods:
    -------
    add_vertex(vertex: int) -> None
        Adds a new vertex to the graph.
    add_edge(vertex1: int, vertex2: int, weight: float) -> None
        Adds a new edge to the graph with a given weight.
    remove_vertex(vertex: int) -> None
        Removes a vertex from the graph.
    remove_edge(vertex1: int, vertex2: int) -> None
        Removes an edge from the graph.
    get_neighbors(vertex: int) -> List[int]
        Returns a list of neighboring vertices for a given vertex.
    get_edge_weight(vertex1: int, vertex2: int) -> float
        Returns the weight of an edge between two vertices.
    """
    def __init__(self):
        """
        Initializes an empty weighted graph.
        """
        self.num_vertices = 0
        self.adjacency_list: Dict[int, Dict[int, float]] = {}
    def add_vertex(self, vertex: int):
        """
        Adds a new vertex to the graph.