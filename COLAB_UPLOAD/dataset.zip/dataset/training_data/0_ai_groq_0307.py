def longest_substring_without_repeating_characters(s: str):
    """
    Finds the length of the longest substring without repeating characters.
    """
    if not isinstance(s, str):
        raise TypeError("Input must be a string.")
    if not s:
        return 0  # Edge case: empty string
    left = 0  # Left pointer of the sliding window
    max_length = 0  # Maximum length of substring without repeating characters
    char_index_map = {}  # Map to store the last seen index of each character
    for right, char in enumerate(s):
        # If the character is already in the map and its index is greater than or equal to the left pointer,
        # it means we have a repeating character, so we move the left pointer to the right of the previous occurrence
        if char in char_index_map and char_index_map[char] >= left:
            left = char_index_map[char] + 1
        # Update the last seen index of the character
        char_index_map[char] = right
        # Update the maximum length
        max_length = max(max_length, right - left + 1)
    return max_length
# Example usage:
print(longest_substring_without_repeating_characters("abcabcbb"))  # Output: 3
print(longest_substring_without_repeating_characters("bbbbb"))  # Output: 1
print(longest_substring_without_repeating_characters("pwwkew"))  # Output: 3
print(longest_substring_without_repeating_characters(""))  # Output: 0
print(longest_substring_without_repeating_characters("a"))  # Output: 1