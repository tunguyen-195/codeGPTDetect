def compute_prefix_function(pattern: str):
    """
    Compute the prefix function for the KMP algorithm.
    The prefix function is used to determine the maximum number of characters
    that can be matched without a mismatch.
    list[int]: The prefix function values.
    """
    m = len(pattern)
    prefix = [0] * m
    # Initialize the prefix function value for the first character
    prefix[0] = 0
    # Initialize the length of the longest proper prefix which is also a suffix
    length = 0
    # Iterate over the pattern to compute the prefix function values
    for i in range(1, m):
        # If the current character does not match the character at the current length,
        # reset the length to the value of the prefix function at the previous index
        while length > 0 and pattern[i] != pattern[length]:
            length = prefix[length - 1]
        # If the current character matches the character at the current length,
        # increment the length
        if pattern[i] == pattern[length]:
            length += 1
        # Update the prefix function value
        prefix[i] = length
    return prefix
def kmp_pattern_matching(text: str, pattern: str):
    """
    Find all occurrences of a pattern in a text using the KMP algorithm.