def two_sum(nums: list[int], target: int):
    """
    Returns the indices of the two numbers in the list that add up to the target value.
    """
    num_map = {}  # Hash map to store the numbers we have seen so far and their indices
    for i, num in enumerate(nums):
        # Calculate the complement of the current number
        complement = target - num
        # Check if the complement is in the hash map
        if complement in num_map:
            # If the complement is in the hash map, return its index and the current index
            return (num_map[complement], i)
        else:
            # If the complement is not in the hash map, add the current number and its index to the hash map
            num_map[num] = i
    # If we have iterated over the entire list and not found a pair of numbers that add up to the target value, raise an error
    raise ValueError("No two numbers in the list add up to the target value")