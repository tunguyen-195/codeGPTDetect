import heapq
import math
class AStarSearch:
    """
    AStarSearch class implements the A* search algorithm for pathfinding.
    """
    def __init__(self, graph, heuristic, start, goal):
        """
        Initializes the AStarSearch instance.
        """
        self.graph = graph
        self.heuristic = heuristic
        self.start = start
        self.goal = goal
        if start not in graph or goal not in graph:
            raise ValueError("Start or goal node not in the graph")
    def _reconstruct_path(self, came_from, current):
        """
        Reconstructs the path from the start node to the current node.
        """
        path = [current]
        while current in came_from:
            current = came_from[current]
            path.insert(0, current)
        return path
    def search(self):
        """
        Performs the A* search algorithm.
        """
        # Initialize the open list as a priority queue
        open_list = []