def matrix_chain_order(p: list[int]):
    """
    Solve the matrix chain multiplication problem using dynamic programming.
    tuple[int, list[int], list[int]]: A tuple containing the minimum number of scalar multiplications,
                                      the optimal order of multiplication, and the minimum number of scalar multiplications
                                      for each subproblem.
    """
    n = len(p) - 1  # number of matrices
    # Initialize a 2D table to store the minimum number of scalar multiplications for each subproblem
    m = [[0] * n for _ in range(n)]
    # Initialize a 2D table to store the optimal order of multiplication for each subproblem
    s = [[0] * n for _ in range(n)]
    # Fill the table in a bottom-up manner
    for chain_length in range(2, n + 1):
        for i in range(n - chain_length + 1):
            j = i + chain_length - 1
            m[i][j] = float('inf')
            for k in range(i, j):
                # Calculate the cost of multiplying matrices i to k and k + 1 to j
                cost = m[i][k] + m[k + 1][j] + p[i] * p[k + 1] * p[j + 1]
                # Update the minimum cost and the optimal order if a better solution is found
                if cost < m[i][j]:
                    m[i][j] = cost
                    s[i][j] = k
    # Reconstruct the optimal order of multiplication from the table
    def print_optimal_parens(s: list[list[int]], i: int, j: int):
        if i == j:
            print("A{}".format(i + 1), end="")
        else:
            print("(", end="")
            print_optimal_parens(s, i, s[i][j])
            print_optimal_parens(s, s[i][j] + 1, j)
            print(")", end="")