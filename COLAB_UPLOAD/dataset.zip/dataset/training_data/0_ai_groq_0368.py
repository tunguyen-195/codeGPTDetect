class BucketSort:
    """
    Bucket Sort implementation for uniformly distributed data.
    Time complexity:
        - Best: O(n + k) where n is the number of elements and k is the number of buckets
        - Average: O(n + k)
        - Worst: O(n^2) when all elements are in one bucket
    """
    def __init__(self, data: list):
        """
        Initialize the Bucket Sort algorithm
        """
        if not isinstance(data, list) or len(data) == 0:
            raise ValueError("Input data must be a non-empty list")
        self.data = data
    def sort(self):
        """
        Sort the input data using Bucket Sort
        """
        # Handle edge case: empty list
        if len(self.data) == 0:
            return []
        # Determine the minimum and maximum values in the data
        min_val = min(self.data)
        max_val = max(self.data)
        # Calculate the range of values
        val_range = max_val - min_val + 1
        # Create empty buckets
        buckets = [[] for _ in range(val_range)]
        # Distribute elements into buckets