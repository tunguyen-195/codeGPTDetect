def min_platforms(arrivals: list[int], departures: list[int]):
    """
    Calculate the minimum number of platforms required for a railway station.
    int: The minimum number of platforms required.
    """
    if len(arrivals) != len(departures):
        raise ValueError("Arrivals and departures lists must be of the same length")
    # Sort the arrival and departure times
    arrivals.sort()
    departures.sort()
    # Initialize variables to keep track of the minimum platforms and the current platforms
    min_platforms = 0
    current_platforms = 0
    # Initialize pointers for the arrival and departure times
    arrival_pointer = 0
    departure_pointer = 0
    # Iterate through the arrival and departure times
    while arrival_pointer < len(arrivals) and departure_pointer < len(departures):
        # If the arrival time is less than or equal to the departure time, increment the current platforms and the arrival pointer
        if arrivals[arrival_pointer] <= departures[departure_pointer]:
            current_platforms += 1
            arrival_pointer += 1
        # If the arrival time is greater than the departure time, decrement the current platforms and the departure pointer
        else:
            current_platforms -= 1
            departure_pointer += 1
        # Update the minimum platforms
        min_platforms = max(min_platforms, current_platforms)
    return min_platforms
