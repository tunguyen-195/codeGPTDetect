def find_median_two_sorted_arrays(nums1: list[int], nums2: list[int]):
    """
    Finds the median of two sorted arrays.
    - nums1: The first sorted array.
    - nums2: The second sorted array.
    - The median of the combined array.
    Time complexity: O(log(min(m, n)))
    Space complexity: O(1)
    """
    # Ensure that nums1 is the smaller array
    if len(nums1) > len(nums2):
        nums1, nums2 = nums2, nums1
    # Calculate the total length of both arrays
    total_length = len(nums1) + len(nums2)
    # If the total length is odd, the median is the middle element
    # If the total length is even, the median is the average of the two middle elements
    half_length = total_length // 2
    # Initialize the binary search range
    left, right = 0, len(nums1) - 1
    while True:
        # Calculate the partition point for nums1
        i = (left + right) // 2
        # Calculate the corresponding partition point for nums2
        j = half_length - i - 2
        # Calculate the values at the partition points
        nums1_left = nums1[i] if i >= 0 else float('-infinity')
        nums1_right = nums1[i + 1] if (i + 1) < len(nums1) else float('infinity')
        nums2_left = nums2[j] if j >= 0 else float('-infinity')
        nums2_right = nums2[j + 1] if (j + 1) < len(nums2) else float('infinity')
        # Check if the partition is correct