class SegmentTree:
    """
    A class representing a Segment Tree data structure.
    The Segment Tree is a binary tree where each node represents an interval.
    For each node, it stores the minimum or maximum value in that interval.
    This allows for efficient range queries.
    """
    def __init__(self, arr: list):
        """
        Initializes the Segment Tree.
        """
        if not arr:
            raise ValueError("Input array cannot be empty")
        self.arr = arr
        self.n = len(arr)
        self.tree = [0] * (4 * self.n)
        # Build the Segment Tree
        self._build_tree(0, 0, self.n - 1)
    def _build_tree(self, node: int, start: int, end: int):
        """
        Builds the Segment Tree recursively.
        """
        # Base case: If the start and end indices are the same, store the value in the tree
        if start == end:
            self.tree[node] = self.arr[start]
        else:
            # Calculate the mid index
            mid = (start + end) // 2
            # Recursively build the left and right subtrees
            self._build_tree(2 * node + 1, start, mid)
            self._build_tree(2 * node + 2, mid + 1, end)