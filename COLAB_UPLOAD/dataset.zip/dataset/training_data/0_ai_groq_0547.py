import heapq
class PriorityQueue:
    """
    A class to implement a priority queue using the heapq module in Python.
    
    The priority queue is a data structure where elements are ordered based on their priority.
    The element with the highest priority is at the front of the queue.
    
    This implementation uses the heapq module which provides an implementation of the heap queue algorithm, also known as the priority queue algorithm.
    """
    def __init__(self):
        """
        Initializes an empty priority queue.
        """
        self._queue = []
        self._index = 0
    def push(self, item: object, priority: int):
        """
        Adds an item to the priority queue with a given priority.
        
        """
        # Use the heapq.heappush function to add the item to the queue
        # The item is represented as a tuple where the first element is the priority and the second element is the item itself
        # This is done to ensure that the item with the highest priority is at the front of the queue
        heapq.heappush(self._queue, (-priority, self._index, item))
        self._index += 1
    def pop(self):
        """
        Removes and returns the item with the highest priority from the queue.
        
        """
        # Check if the queue is empty
        if not self._queue:
            raise IndexError("pop from an empty queue")
        
        # Use the heapq.heappop function to remove and return the item with the highest priority