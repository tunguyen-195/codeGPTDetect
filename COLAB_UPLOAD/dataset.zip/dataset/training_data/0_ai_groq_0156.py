class WeightedGraph:
    """
    A class to represent a weighted graph.
    """
    def __init__(self):
        """
        Initializes an empty weighted graph.
        """
        self.graph: dict = {}
    def add_vertex(self, vertex: str):
        """
        Adds a vertex to the graph if it does not already exist.
        """
        if not isinstance(vertex, str):
            raise TypeError("Vertex must be a string")
        if vertex not in self.graph:
            self.graph[vertex] = {}
    def add_edge(self, vertex1: str, vertex2: str, weight: float):
        """
        Adds an edge between two vertices with a specified weight.
        """
        if not isinstance(vertex1, str) or not isinstance(vertex2, str):
            raise TypeError("Vertices must be strings")
        if not isinstance(weight, (int, float)):
            raise TypeError("Weight must be a number")
        if vertex1 not in self.graph or vertex2 not in self.graph:
            raise ValueError("Both vertices must exist in the graph")
        self.graph[vertex1][vertex2] = weight
        self.graph[vertex2][vertex1] = weight  # For undirected graph
    def remove_edge(self, vertex1: str, vertex2: str):
        """
        Removes an edge between two vertices.
