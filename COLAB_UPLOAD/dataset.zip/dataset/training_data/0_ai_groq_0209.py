def rotate_array(nums: list[int], k: int):
    """
    Rotate the input array to the right by k positions.
    """
    # Check if the input array is empty
    if not nums:
        raise ValueError("Input array is empty")
    # Calculate the effective number of positions to rotate
    # This is to handle cases where k is greater than the length of the array
    k = k % len(nums)
    # Use list slicing to rotate the array
    # The expression nums[-k:] gets the last k elements of the array
    # The expression nums[:-k] gets all elements except the last k elements
    # By concatenating these two parts in reverse order, we get the rotated array
    return nums[-k:] + nums[:-k]
def main():
    # Example usage
    nums = [1, 2, 3, 4, 5, 6, 7]
    k = 3
    print(rotate_array(nums, k))  # Output: [5, 6, 7, 1, 2, 3, 4]
if __name__ == "__main__":
    main()