def activity_selection(activities: list[tuple[int, int]]):
    """
    This function solves the activity selection problem using a greedy approach.
    The activity selection problem is a classic problem in computer science and operations research that involves selecting the maximum number of activities that can be performed by a single person or machine, given a set of activities and their start and end times.
    The greedy approach works by first sorting the activities based on their end times. Then, it iterates over the sorted activities and selects the activities that do not conflict with the previously selected activities.
    """
    # Check if the input list is empty
    if not activities:
        raise ValueError("Input list is empty")
    # Sort the activities based on their end times
    activities.sort(key=lambda x: x[1])  # O(n log n)
    # Initialize the list of selected activities with the first activity
    selected_activities = [activities[0]]
    # Iterate over the remaining activities
    for activity in activities[1:]:  # O(n)
        # Check if the current activity does not conflict with the last selected activity
        if activity[0] >= selected_activities[-1][1]:
            # Add the current activity to the list of selected activities
            selected_activities.append(activity)
    return selected_activities
def main():
    # Example usage:
    activities = [(1, 4), (3, 5), (0, 6), (5, 7), (3, 8), (5, 9), (6, 10), (8, 11), (8, 12), (2, 13), (12, 14)]
    selected_activities = activity_selection(activities)
    print("Selected activities:", selected_activities)
if __name__ == "__main__":
    main()