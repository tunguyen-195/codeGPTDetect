class Graph:
    """
    A class to represent a Directed Graph.
    ----------
    vertices : dict
        A dictionary to store the adjacency list of the graph.
    """
    def __init__(self):
        """
        Initializes an empty graph.
        """
        self.vertices = {}
    def add_vertex(self, vertex: str):
        """
        Adds a vertex to the graph.
        ----------
        vertex : str
            The vertex to be added.
        """
        if vertex not in self.vertices:
            self.vertices[vertex] = []
    def add_edge(self, from_vertex: str, to_vertex: str):
        """
        Adds a directed edge to the graph.
        ----------
        from_vertex : str
            The starting vertex of the edge.
        to_vertex : str
            The ending vertex of the edge.
        ------
        ValueError
            If the from_vertex or to_vertex does not exist in the graph.
        """