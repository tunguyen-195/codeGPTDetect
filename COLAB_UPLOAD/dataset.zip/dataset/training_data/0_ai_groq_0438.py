class BTreeNode:
    """Represents a node in the B-Tree."""
    
    def __init__(self, leaf: bool, degree: int):
        """
        Initializes a B-Tree node.
        """
        self.leaf = leaf
        self.degree = degree
        self.keys = []
        self.children = []
class BTree:
    """Represents a B-Tree data structure for disk-based storage."""
    
    def __init__(self, degree: int):
        """
        Initializes a B-Tree.
        """
        self.degree = degree
        self.root = BTreeNode(True, degree)
    def _insert_non_full(self, node: BTreeNode, key: int):
        """
        Inserts a key into a non-full node.
        """
        i = len(node.keys) - 1
        if node.leaf:
            node.keys.append(None)
            while i >= 0 and key < node.keys[i]:
                node.keys[i + 1] = node.keys[i]
                i -= 1