from typing import List, Tuple
def bucket_sort(data: List[float], num_buckets: int = 10):
    """
    Sorts uniformly distributed data using the bucket sort algorithm.
    Time Complexity:
        O(n + k), where n is the number of elements in the data and k is the number of buckets.
    Space Complexity:
        O(n + k), where n is the number of elements in the data and k is the number of buckets.
    """
    # Check if the input data is a list
    if not isinstance(data, list):
        raise TypeError("Input data must be a list")
    # Check if the list is empty
    if len(data) == 0:
        return []
    # Initialize empty buckets
    buckets = [[] for _ in range(num_buckets)]
    # Distribute data into buckets
    for num in data:
        # Calculate the index of the bucket where the number should be placed
        index = int((num - data[0]) / (data[-1] - data[0]) * (num_buckets - 1))
        # Handle edge cases where index is out of bounds
        if index < 0:
            index = 0
        elif index >= num_buckets:
            index = num_buckets - 1
        buckets[index].append(num)
    # Sort each bucket individually
    for i in range(num_buckets):
        # Use built-in sort function for simplicity
        # In a real-world scenario, you might want to use a more efficient sorting algorithm
        buckets[i].sort()
