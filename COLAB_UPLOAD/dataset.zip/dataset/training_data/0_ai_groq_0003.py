class BTreeNode:
    """
    A class representing a node in the B-Tree.
    """
    def __init__(self, leaf: bool, t: int):
        """
        Initializes a BTreeNode.
        """
        self.leaf = leaf
        self.keys = []
        self.children = []
        self.t = t
class BTree:
    """
    A class representing a B-Tree.
    """
    def __init__(self, t: int):
        """
        Initializes a BTree.
        """
        self.root = BTreeNode(True, t)
        self.t = t
    def insert(self, key: int):
        """
        Inserts a key into the B-Tree.
        """
        root = self.root
        if len(root.keys) == (2 * self.t) - 1:
            # If the root is full, create a new root
            temp = BTreeNode(False, self.t)
            self.root = temp