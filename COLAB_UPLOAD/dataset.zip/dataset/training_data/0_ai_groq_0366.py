def counting_sort(arr: list[int]):
    """
    Sorts an array of integers using the Counting Sort algorithm.
    Time complexity:
    - Best case: O(n + k) where n is the number of elements in the array and k is the range of input
    - Worst case: O(n + k)
    - Average case: O(n + k)
    Space complexity: O(n + k)
    """
    # Check for edge cases
    if not arr:
        return arr  # Return an empty array for an empty input array
    # Check if the array contains non-integer values
    if not all(isinstance(x, int) for x in arr):
        raise ValueError("Input array must contain only integers")
    # Find the maximum element in the array to determine the range of input
    max_element = max(arr)
    # Create a count array to store the count of individual elements
    count_arr = [0] * (max_element + 1)
    # Count the occurrences of each element in the input array
    for num in arr:
        count_arr[num] += 1
    # Calculate the cumulative count to determine the position of each element in the sorted array
    for i in range(1, len(count_arr)):
        count_arr[i] += count_arr[i - 1]
    # Create the sorted array by placing each element at its correct position based on its count
    sorted_arr = [0] * len(arr)
    for num in arr:
        sorted_arr[count_arr[num] - 1] = num
        count_arr[num] -= 1