def exponential_search(arr: list, target: int):
    """
    Searches for the target element in the given array using the Exponential Search algorithm.
    int: The index of the target element if found, -1 otherwise.
    TypeError: If the input array is not a list or the target is not an integer.
    ValueError: If the input array is empty.
    """
    # Check if the input array is a list and the target is an integer
    if not isinstance(arr, list) or not isinstance(target, int):
        raise TypeError("Input array must be a list and target must be an integer.")
    # Check if the input array is empty
    if len(arr) == 0:
        raise ValueError("Input array cannot be empty.")
    # If the array is empty, raise a ValueError
    if not arr:
        raise ValueError("Input array cannot be empty.")
    # Find the range of the array using the exponential search
    bound = 1
    while bound < len(arr) and arr[bound] <= target:
        # Double the bound until the target is found or the bound exceeds the array length
        bound *= 2
    # Perform a binary search in the range of the array
    return binary_search(arr, target, min(bound, len(arr) - 1))
def binary_search(arr: list, target: int, low: int, high: int):
    """
    Searches for the target element in the given array using the Binary Search algorithm.
