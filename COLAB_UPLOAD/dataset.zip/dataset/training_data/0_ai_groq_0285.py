def coin_change(coins: list[int], amount: int):
    """
    Returns the minimum number of coins needed to reach the given amount.
    Time complexity: O(amount * len(coins))
    Space complexity: O(amount)
    """
    # Create a list to store the minimum number of coins needed for each amount from 0 to the target amount
    dp = [float('inf')] * (amount + 1)
    dp[0] = 0  # We need 0 coins to reach an amount of 0
    # Iterate over each coin denomination
    for coin in coins:
        # Iterate over each amount from the coin denomination to the target amount
        for i in range(coin, amount + 1):
            # Update the minimum number of coins needed for the current amount
            dp[i] = min(dp[i], dp[i - coin] + 1)
    # Return the minimum number of coins needed to reach the target amount, or -1 if it's impossible
    return dp[amount] if dp[amount] != float('inf') else -1
# Example usage:
coins = [1, 2, 5]
amount = 11
print(coin_change(coins, amount))  # Output: 3 (11 = 5 + 5 + 1)