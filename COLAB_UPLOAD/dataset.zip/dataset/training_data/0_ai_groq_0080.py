def three_sum(nums: list[int]):
    """
    Returns all triplets in the given list of numbers that sum up to zero.
    """
    nums.sort()  # Sort the list to apply the two-pointer technique
    triplets = []  # Initialize an empty list to store the result
    for i in range(len(nums) - 2):  # Iterate over the list
        # Skip the same result to avoid duplicates
        if i > 0 and nums[i] == nums[i - 1]:
            continue
        left, right = i + 1, len(nums) - 1  # Initialize two pointers
        while left < right:
            total = nums[i] + nums[left] + nums[right]
            if total < 0:
                # If the total is less than zero, move the left pointer to increase the total
                left += 1
            elif total > 0:
                # If the total is greater than zero, move the right pointer to decrease the total
                right -= 1
            else:
                # If the total is equal to zero, add the triplet to the result and move both pointers
                triplets.append([nums[i], nums[left], nums[right]])
                while left < right and nums[left] == nums[left + 1]:
                    # Skip the same result to avoid duplicates
                    left += 1
                while left < right and nums[right] == nums[right - 1]:
                    # Skip the same result to avoid duplicates
                    right -= 1
                left += 1
                right -= 1
    return triplets
def main():
    try:
        nums = [-1, 0, 1, 2, -1, -4]
        result = three_sum(nums)