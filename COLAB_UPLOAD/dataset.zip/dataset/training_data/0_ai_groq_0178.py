from heapq import heappop, heappush
from typing import List, Tuple
class Node:
    """
    Represents a node in the graph with its coordinates and cost.
    
    """
    def __init__(self, x: int, y: int, cost: float = 0.0, parent=None):
        """
        Initializes a new node.
        """
        self.x = x
        self.y = y
        self.cost = cost
        self.parent = parent
    def __lt__(self, other):
        """
        Compares two nodes based on their costs.
        bool: True if this node's cost is less than the other node's cost, False otherwise.
        """
        return self.cost < other.cost
def heuristic(node: Node, goal: Node):
    """
    Calculates the heuristic cost from a node to the goal node.