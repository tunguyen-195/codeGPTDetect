class TrieNode:
    """A node in the Trie data structure."""
    
    def __init__(self):
        """Initialize a new TrieNode."""
        self.children = {}  # Mapping of character to child node
        self.is_end_of_word = False  # Flag indicating if this node is the end of a word
class Trie:
    """A Trie data structure for efficient string lookup and autocomplete."""
    
    def __init__(self):
        """Initialize a new Trie."""
        self.root = TrieNode()  # Root node of the Trie
    def insert(self, word: str):
        """Insert a word into the Trie."""
        node = self.root
        for char in word:
            if char not in node.children:
                node.children[char] = TrieNode()  # Create a new child node
            node = node.children[char]
        node.is_end_of_word = True  # Mark the end of the word
    def search(self, word: str):
        """Check if a word exists in the Trie."""
        node = self.root
        for char in word:
            if char not in node.children:
                return False  # Word not found
            node = node.children[char]
        return node.is_end_of_word  # Return True if word exists
    def starts_with(self, prefix: str):
        """Check if there are any words that start with the given prefix."""
        node = self.root
        for char in prefix:
            if char not in node.children:
                return False  # Prefix not found
            node = node.children[char]