def z_algorithm(text: str):
    """
    Calculate the Z-array for the given text.
    The Z-array is an array where each element at index i represents the length of the longest substring starting at i that is a prefix of the text.
    """
    if not text:
        raise ValueError("Input text cannot be empty")
    n = len(text)
    z = [0] * n  # Initialize the Z-array
    left = 0  # Initialize the left pointer
    right = 0  # Initialize the right pointer
    for i in range(1, n):
        # If i is within the right pointer's range, calculate the Z-value using the previous Z-value
        if i <= right:
            z[i] = min(right - i + 1, z[i - left])
        
        # Try to extend the current Z-value
        while i + z[i] < n and text[z[i]] == text[i + z[i]]:
            z[i] += 1
        
        # Update the left and right pointers
        if i + z[i] - 1 > right:
            left = i
            right = i + z[i] - 1
    
    return z
def z_search(pattern: str, text: str):
    """
    Search for the given pattern in the text using the Z-algorithm.
    """
    if not pattern or not text:
        raise ValueError("Input pattern and text cannot be empty")
    # Preprocess the text using the Z-algorithm