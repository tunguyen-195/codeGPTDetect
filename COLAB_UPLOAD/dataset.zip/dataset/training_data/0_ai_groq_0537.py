class Node:
    """Represents a node in the Red-Black Tree."""
    
    def __init__(self, key: int, color: str = 'red', left: 'Node' = None, right: 'Node' = None, parent: 'Node' = None):
        """
        Initializes a new Node.
        """
        self.key = key
        self.color = color
        self.left = left
        self.right = right
        self.parent = parent
class RedBlackTree:
    """Represents a Red-Black Tree."""
    
    def __init__(self):
        """Initializes a new Red-Black Tree."""
        self.NIL = Node(None, 'black')
        self.root = self.NIL
    def pre_order(self, node: 'Node'):
        """Performs a pre-order traversal of the tree.
        """
        if node != self.NIL:
            print(f"Key: {node.key}, Color: {node.color}")
            self.pre_order(node.left)
            self.pre_order(node.right)
    def left_rotate(self, x: 'Node'):
        """Rotates the tree to the left around the given node.
        """
        y = x.right
        x.right = y.left
        if y.left != self.NIL:
            y.left.parent = x
        y.parent = x.parent