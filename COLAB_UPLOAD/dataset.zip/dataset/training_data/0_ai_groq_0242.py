class Node:
    """
    A class to represent a node in the doubly linked list.
    """
    def __init__(self, data: any):
        """
        Initializes a new node with the given data.
        """
        self.data = data
        self.prev = None
        self.next = None
class DoublyLinkedList:
    """
    A class to represent a doubly linked list.
    """
    def __init__(self):
        """
        Initializes an empty doubly linked list.
        """
        self.head = None
        self.tail = None
    def append(self, data: any):
        """
        Adds a new node with the given data to the end of the list.
        """
        node = Node(data)
        if self.tail is None:
            self.head = node
            self.tail = node
        else:
            node.prev = self.tail
            self.tail.next = node
            self.tail = node
