def max_subarray_sum(arr: list[int]):
    """
    Returns the maximum sum of a contiguous subarray within the given array.
    Time complexity: O(n)
    Space complexity: O(1)
    """
    if not arr:
        raise ValueError("Input array cannot be empty")
    max_current = max_global = arr[0]
    for num in arr[1:]:
        # Update max_current to be the maximum of the current number and the sum of the current number and max_current
        max_current = max(num, max_current + num)
        
        # Update max_global to be the maximum of max_global and max_current
        max_global = max(max_global, max_current)
    return max_global