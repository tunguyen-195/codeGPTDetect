def climb_stairs(n: int):
    """
    This function calculates the number of distinct ways to climb n stairs.
    
    
    int: The number of distinct ways to climb n stairs.
    """
    
    # Base cases: there's 1 way to climb 0 stairs (i.e., not climbing) and 1 way to climb 1 stair.
    if n <= 1:
        return n
    
    # Initialize a list to store the number of ways to climb i stairs, where i ranges from 0 to n.
    ways = [0] * (n + 1)
    
    # There's 1 way to climb 0 stairs and 1 way to climb 1 stair.
    ways[0] = 1
    ways[1] = 1
    
    # For each stair from 2 to n, calculate the number of ways to climb it.
    for i in range(2, n + 1):
        # The number of ways to climb i stairs is the sum of the number of ways to climb i-1 stairs and i-2 stairs.
        ways[i] = ways[i - 1] + ways[i - 2]
    
    # Return the number of ways to climb n stairs.
    return ways[n]
# Example usage:
print(climb_stairs(4))  # Output: 5
print(climb_stairs(5))  # Output: 8
# Time complexity: O(n), where n is the number of stairs.
# Space complexity: O(n), where n is the number of stairs.