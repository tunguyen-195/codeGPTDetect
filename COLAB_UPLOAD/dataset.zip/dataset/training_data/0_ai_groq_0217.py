def product_except_self(nums: list[int]):
    """
    Calculate the product of all numbers in the given array except self.
    - nums: A list of integers.
    - A list of integers where each element at index i is the product of all numbers in nums except nums[i].
    Time complexity: O(n)
    Space complexity: O(1)
    """
    length = len(nums)
    # Initialize the output array with 1's
    output = [1] * length
    # Calculate prefix products
    prefix_product = 1
    for i in range(length):
        output[i] *= prefix_product
        prefix_product *= nums[i]
    # Calculate suffix products
    suffix_product = 1
    for i in range(length - 1, -1, -1):
        output[i] *= suffix_product
        suffix_product *= nums[i]
    return output
# Example usage:
nums = [1, 2, 3, 4]
result = product_except_self(nums)
print(result)  # Output: [24, 12, 8, 6]