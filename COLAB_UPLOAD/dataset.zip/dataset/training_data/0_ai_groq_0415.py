def three_sum(nums: list[int]):
    """
    Returns all unique triplets in the given list of integers that sum up to zero.
    list[list[int]]: A list of unique triplets that sum up to zero.
    """
    if len(nums) < 3:
        # If the list has less than 3 elements, it's impossible to form a triplet.
        return []
    nums.sort()  # Sort the list to apply the two-pointer technique
    triplets = []  # Initialize an empty list to store the result
    for i in range(len(nums) - 2):  # Iterate over the list with three pointers
        # Skip the same result
        if i > 0 and nums[i] == nums[i - 1]:
            continue
        left, right = i + 1, len(nums) - 1  # Initialize two pointers
        while left < right:
            total = nums[i] + nums[left] + nums[right]
            if total < 0:
                # If the total is less than zero, move the left pointer to the right
                left += 1
            elif total > 0:
                # If the total is greater than zero, move the right pointer to the left
                right -= 1
            else:
                # If the total is equal to zero, add the triplet to the result and move both pointers
                triplets.append([nums[i], nums[left], nums[right]])
                # Skip the same result
                while left < right and nums[left] == nums[left + 1]:
                    left += 1
                while left < right and nums[right] == nums[right - 1]:
                    right -= 1
                left += 1
                right -= 1