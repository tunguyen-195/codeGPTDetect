def z_algorithm(text: str):
    """
    Compute the Z-array for the given text.
    The Z-array is a list where each element at index i represents the length of the longest substring
    starting at position i that is also a substring of the entire text.
    list[int]: The Z-array for the given text.
    ValueError: If the input text is empty.
    TypeError: If the input text is not a string.
    """
    if not isinstance(text, str):
        raise TypeError("Input text must be a string.")
    if not text:
        raise ValueError("Input text cannot be empty.")
    n = len(text)
    z = [0] * n
    left, right = 0, 0
    for i in range(1, n):
        # If current position is outside the current window, ignore it
        if i > right:
            left, right = i, i
            while right < n and text[right - left] == text[right]:
                right += 1
            z[i] = right - left
            right -= 1
        else:
            # Check if current position is within the current window
            k = i - left
            if z[k] < right - i + 1:
                z[i] = z[k]
            else:
                left = i
                while right < n and text[right - left] == text[right]: