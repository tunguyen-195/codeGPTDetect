class LinearSearch:
    """
    A class representing a Linear Search algorithm with sentinel.
    
    ----------
    sentinel : int
        The sentinel value that marks the end of the list.
        
    Methods:
    -------
    search(target: int) -> int
        Searches for the target element in the list.
    """
    def __init__(self, sentinel: int):
        """
        Initializes the Linear Search algorithm with the sentinel value.
        ----
        sentinel : int
            The sentinel value that marks the end of the list.
        """
        self.sentinel = sentinel
    def search(self, target: int):
        """
        Searches for the target element in the list using Linear Search with sentinel.
        ----
        target : int
            The target element to search for.
        -------
        int
            The index of the target element if found, -1 otherwise.
        ------
        ValueError
            If the target element is not found in the list.
        """