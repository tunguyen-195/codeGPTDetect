def max_subarray_sum(nums: list[int]):
    """
    This function calculates the maximum subarray sum using Kadane's algorithm.
    int: The maximum subarray sum.
    Time complexity: O(n)
    Space complexity: O(1)
    """
    if not nums:
        raise ValueError("Input list is empty")
    max_current = max_global = nums[0]
    # Iterate over the list starting from the second element
    for num in nums[1:]:
        # Update max_current to be the maximum of the current number and the sum of the current number and max_current
        # This is the key step in Kadane's algorithm
        max_current = max(num, max_current + num)
        
        # Update max_global to be the maximum of max_global and max_current
        max_global = max(max_global, max_current)
    return max_global
# Example usage:
print(max_subarray_sum([-2, 1, -3, 4, -1, 2, 1, -5, 4]))  # Output: 6