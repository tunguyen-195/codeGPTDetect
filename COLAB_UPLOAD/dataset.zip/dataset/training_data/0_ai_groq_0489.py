from typing import Dict
def fibonacci(n: int, memo: Dict[int, int] = {}):
    """
    Calculate the nth Fibonacci number using memoization.
        Defaults to an empty dictionary.
    int: The nth Fibonacci number.
    ValueError: If n is a negative integer.
    """
    if n < 0:
        raise ValueError("n must be a non-negative integer")
    # Base cases
    if n <= 1:
        return n
    # Check if the Fibonacci number is already in the memo dictionary
    if n not in memo:
        # If not, calculate it and store it in the memo dictionary
        memo[n] = fibonacci(n - 1, memo) + fibonacci(n - 2, memo)
    # Return the calculated Fibonacci number
    return memo[n]
# Example usage
if __name__ == "__main__":
    n = 10  # The position of the Fibonacci number to calculate
    result = fibonacci(n)
    print(f"The {n}th Fibonacci number is: {result}")