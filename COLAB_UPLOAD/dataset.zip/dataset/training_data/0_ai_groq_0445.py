class Stack:
    """
    A basic implementation of a Stack data structure using a list.
    
    Methods:
        push(element): Adds an element to the top of the stack.
        pop(): Removes and returns the top element from the stack.
        peek(): Returns the top element from the stack without removing it.
        is_empty(): Checks if the stack is empty.
        size(): Returns the number of elements in the stack.
    """
    def __init__(self):
        """
        Initializes an empty stack.
        """
        self.elements = []
    def push(self, element: any):
        """
        Adds an element to the top of the stack.
        """
        self.elements.append(element)
    def pop(self):
        """
        Removes and returns the top element from the stack.
        """
        if self.is_empty():
            raise IndexError("Cannot pop from an empty stack")
        return self.elements.pop()
    def peek(self):
        """
        Returns the top element from the stack without removing it.
        """
        if self.is_empty():