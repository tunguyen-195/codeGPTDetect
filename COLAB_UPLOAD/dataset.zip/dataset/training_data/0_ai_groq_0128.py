import csv
from typing import List, Dict
def read_csv_file(file_path: str):
    """
    Reads a CSV file and returns its contents as a list of dictionaries.
    """
    try:
        with open(file_path, 'r') as file:
            # Create a CSV reader object
            csv_reader = csv.DictReader(file)
            
            # Initialize an empty list to store the rows
            rows = []
            
            # Iterate over each row in the CSV file
            for row in csv_reader:
                # Add the row to the list
                rows.append(dict(row))
            
            # Return the list of rows
            return rows
    
    except FileNotFoundError:
        print(f"File not found: {file_path}")
        return []
    
    except csv.Error as e:
        print(f"An error occurred while reading the CSV file: {e}")
        return []
# Example usage:
if __name__ == "__main__":
    file_path = "example.csv"
    rows = read_csv_file(file_path)
    for row in rows:
        print(row)