def radix_sort(numbers: list[int]):
    """
    Sorts a list of integers using Radix Sort algorithm.
    Time complexity: O(nk), where n is the number of elements and k is the number of digits in the maximum number.
    Space complexity: O(n + k), where n is the number of elements and k is the number of digits in the maximum number.
    """
    # Check if the input list is empty
    if not numbers:
        raise ValueError("Input list is empty")
    # Check if the input list contains non-integer values
    if not all(isinstance(num, int) for num in numbers):
        raise ValueError("Input list contains non-integer values")
    # Find the maximum number to determine the number of digits
    max_number = max(numbers)
    # Perform counting sort for every digit
    exp = 1
    while max_number // exp > 0:
        # Initialize the count array
        count = [0] * 10
        # Count the occurrences of each digit
        for num in numbers:
            digit = (num // exp) % 10
            count[digit] += 1
        # Calculate the cumulative count
        for i in range(1, 10):
            count[i] += count[i - 1]
        # Build the output array
        output = [0] * len(numbers)
        for i in range(len(numbers) - 1, -1, -1):
            digit = (numbers[i] // exp) % 10
            output[count[digit] - 1] = numbers[i]
            count[digit] -= 1