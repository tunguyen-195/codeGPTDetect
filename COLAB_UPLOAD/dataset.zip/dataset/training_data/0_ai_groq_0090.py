class DisjointSet:
    """
    A disjoint set data structure to keep track of connected components.
    """
    def __init__(self, vertices: int):
        """
        Initialize the disjoint set with the given number of vertices.
        """
        self.parent = list(range(vertices))
        self.rank = [0] * vertices
    def find(self, vertex: int):
        """
        Find the root of the set containing the given vertex.
        int: The root of the set containing the vertex.
        """
        if self.parent[vertex] != vertex:
            self.parent[vertex] = self.find(self.parent[vertex])
        return self.parent[vertex]
    def union(self, vertex1: int, vertex2: int):
        """
        Union the sets containing the given vertices.
        """
        root1 = self.find(vertex1)
        root2 = self.find(vertex2)
        if root1 != root2:
            if self.rank[root1] > self.rank[root2]:
                self.parent[root2] = root1
            else: