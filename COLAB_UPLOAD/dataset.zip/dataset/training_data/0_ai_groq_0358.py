class HashMap:
    """
    A Python implementation of a hash map using open addressing.
    
    """
    def __init__(self, capacity: int = 10):
        """
        Initializes a new instance of the HashMap class.
        """
        self.capacity = capacity
        self.size = 0
        self.table = [[] for _ in range(capacity)]
    def _hash(self, key: str):
        """
        Computes the hash value of a given key.
        """
        return sum(ord(c) for c in key) % self.capacity
    def put(self, key: str, value: any):
        """
        Inserts or updates a key-value pair in the hash map.
        """
        index = self._hash(key)
        bucket = self.table[index]
        for i, (k, v) in enumerate(bucket):
            if k == key:
                bucket[i] = (key, value)
                return
        if len(bucket) >= self.capacity // 2:
            self._resize()
        bucket.append((key, value))
        self.size += 1