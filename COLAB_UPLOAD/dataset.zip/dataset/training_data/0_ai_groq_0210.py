def find_pairs_with_sum(nums: list[int], target: int):
    """
    Find all pairs in the given list of numbers that sum to the target value.
    - nums (list[int]): A list of integers.
    - target (int): The target sum.
    - list[tuple[int, int]]: A list of pairs (i, j) where nums[i] + nums[j] equals the target.
    Time complexity: O(n)
    Space complexity: O(n)
    """
    if not nums:
        return []
    seen = set()
    pairs = set()
    for num in nums:
        complement = target - num
        if complement in seen:
            # Sort the pair to ensure (a, b) and (b, a) are not counted as different pairs
            pair = tuple(sorted((num, complement)))
            pairs.add(pair)
        seen.add(num)
    return list(pairs)
# Example usage:
numbers = [1, 2, 3, 4, 5, 6, 7, 8, 9]
target_sum = 10
print(find_pairs_with_sum(numbers, target_sum))
# Output: [(1, 9), (2, 8), (3, 7), (4, 6)]