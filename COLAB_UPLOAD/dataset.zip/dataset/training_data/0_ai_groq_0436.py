class Node:
    """Represents a node in the AVL tree."""
    
    def __init__(self, key: int, value: str = None):
        """
        Initializes a new node with the given key and value.
        
        """
        self.key = key
        self.value = value
        self.left = None
        self.right = None
        self.height = 1
class AVLTree:
    """Represents an AVL tree data structure."""
    
    def __init__(self):
        """Initializes an empty AVL tree."""
        self.root = None
    def insert(self, key: int, value: str = None):
        """
        Inserts a new node with the given key and value into the AVL tree.
        
        
        TypeError: If the key is not an integer.
        """
        if not isinstance(key, int):
            raise TypeError("Key must be an integer.")
        
        self.root = self._insert(self.root, key, value)
    def _insert(self, node: Node, key: int, value: str):
        """
        Recursively inserts a new node into the AVL tree.