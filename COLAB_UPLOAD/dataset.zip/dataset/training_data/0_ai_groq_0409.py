def rotate_array(nums: list[int], k: int):
    """
    Rotate the input array to the right by k positions.
    - nums (list[int]): The input array to be rotated.
    - k (int): The number of positions to rotate the array to the right.
    Time Complexity: O(n)
    Space Complexity: O(1)
    """
    if not nums:
        # Handle edge case where input array is empty
        return
    k = k % len(nums)
    # Calculate the effective number of positions to rotate, handling cases where k > n
    nums[:] = nums[-k:] + nums[:-k]
    # Use list slicing to rotate the array in-place