def coin_change_ways(coins: list[int], amount: int):
    """
    Calculate the number of ways to make a given amount with a list of coins.
    int: The number of ways to make the given amount.
    Time complexity: O(amount * len(coins))
    Space complexity: O(amount)
    """
    if not coins or amount < 0:
        # Base case: If there are no coins or the amount is negative, return 0.
        return 0
    # Initialize a list to store the number of ways to make each amount from 0 to the target amount.
    ways = [0] * (amount + 1)
    ways[0] = 1  # Base case: There is 1 way to make 0 amount (using no coins).
    for coin in coins:
        # Iterate over each coin denomination.
        for i in range(coin, amount + 1):
            # For each amount from the coin denomination to the target amount, add the number of ways to make the amount without using the current coin.
            ways[i] += ways[i - coin]
    return ways[amount]
# Example usage:
coins = [1, 2, 5]
amount = 5
print(f"Number of ways to make {amount} with coins {coins}: {coin_change_ways(coins, amount)}")