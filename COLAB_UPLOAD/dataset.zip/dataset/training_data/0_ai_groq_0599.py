def z_algorithm(pattern: str):
    """
    Compute the Z-array for a given pattern string.
    The Z-array is a list of integers where Z[i] represents the length of the
    longest substring starting at position i that is equal to the pattern.
    """
    if not pattern:
        raise ValueError("Pattern cannot be empty")
    n = len(pattern)
    z = [0] * n  # Initialize the Z-array with zeros
    # Initialize variables to keep track of the current window
    left = 0
    right = 0
    # Iterate over the pattern string
    for i in range(n):
        # If the current position is within the current window, use the
        # previously computed value
        if i <= right:
            z[i] = min(right - i + 1, z[i - left])
        # Try to extend the current window to the right
        while i + z[i] < n and pattern[z[i]] == pattern[i + z[i]]:
            z[i] += 1
        # If the current window extends beyond the right boundary, update the
        # right boundary
        if i + z[i] - 1 > right:
            left = i
            right = i + z[i] - 1
    return z
def find_pattern(text: str, pattern: str):
    """