class Node:
    """Node class representing a single node in the circular linked list."""
    
    def __init__(self, data: any):
        """
        Initialize a new Node with given data.
        """
        self.data = data
        self.next = None
class CircularLinkedList:
    """CircularLinkedList class representing a circular linked list."""
    
    def __init__(self):
        """
        Initialize an empty circular linked list.
        """
        self.head = None
    def append(self, data: any):
        """
        Append a new node with given data to the end of the list.
        """
        if not self.head:
            self.head = Node(data)
            self.head.next = self.head
        else:
            new_node = Node(data)
            current = self.head
            while current.next != self.head:
                current = current.next
            current.next = new_node
            new_node.next = self.head
    def prepend(self, data: any):
        """
        Prepend a new node with given data to the beginning of the list.
