def ternary_search(func: callable, low: float, high: float, tol: float = 1e-6):
    """
    Ternary search for unimodal functions.
    func: The unimodal function to search for a minimum.
    low: The lower bound of the search interval.
    high: The upper bound of the search interval.
    tol: The tolerance for the minimum value (default is 1e-6).
    The minimum value of the function in the given interval.
    ValueError: If the function is not unimodal.
    """
    if not is_unimodal(func, low, high):
        raise ValueError("The function is not unimodal.")
    while high - low > tol:
        # Calculate the third point using the formula: (low + high) / 3
        third = (low + high) / 3
        # Evaluate the function at the third point
        third_value = func(third)
        # Evaluate the function at the first and second points
        first_value = func(low)
        second_value = func(high)
        # If the function value at the third point is less than the function value at the first and second points,
        # update the search interval to be [low, third]
        if third_value < first_value and third_value < second_value:
            high = third
        # If the function value at the third point is greater than the function value at the first and second points,
        # update the search interval to be [third, high]
        elif third_value > first_value and third_value > second_value:
            low = third
        # If the function value at the third point is equal to the function value at the first and second points,
        # update the search interval to be [low, third] or [third, high] randomly
        else:
            if third_value == first_value: