def binary_search(arr: list, target: int):
    """
    Searches for a target element in a sorted array using Binary Search algorithm.
    """
    # Check if the input array is sorted
    if arr != sorted(arr):
        raise ValueError("Input array must be sorted")
    # Initialize the low and high pointers
    low = 0
    high = len(arr) - 1
    # Continue the search until the low pointer is less than or equal to the high pointer
    while low <= high:
        # Calculate the mid index
        mid = (low + high) // 2
        # If the target element is found at the mid index, return the index
        if arr[mid] == target:
            return mid
        # If the target element is less than the mid element, update the high pointer
        elif arr[mid] > target:
            high = mid - 1
        # If the target element is greater than the mid element, update the low pointer
        else:
            low = mid + 1
    # If the target element is not found, return -1
    return -1
def main():
    # Example usage
    arr = [2, 5, 8, 12, 16, 23, 38, 56, 72, 91]
    target = 23
    result = binary_search(arr, target)
    if result != -1:
        print(f"Target element {target} found at index {result}")
    else: