def manacher(s: str):
    """
    Manacher's algorithm to find the longest palindromic substring.
    str: Longest palindromic substring.
    TypeError: If input is not a string.
    """
    if not isinstance(s, str):
        raise TypeError("Input must be a string.")
    # Preprocess the string to handle even-length palindromes
    # and odd-length palindromes separately
    T = '#'.join('^{}$'.format(s))
    n = len(T)
    P = [0] * n
    C = R = 0
    # Loop through the preprocessed string
    for i in range(1, n-1):
        # Mirror property of palindromes
        P[i] = (R > i) and min(R - i, P[2*C - i])  # Mirror property
        # Attempt to expand the palindrome centered at i
        while T[i + 1 + P[i]] == T[i - 1 - P[i]]:
            P[i] += 1
        # If palindrome centered at i expand past R,
        # adjust center based on expanded palindrome
        if i + P[i] > R:
            C, R = i, i + P[i]
    # Find the maximum element in P
    maxLen, centerIndex = max((n, i) for i, n in enumerate(P))
    # Return the longest palindromic substring
    return s[(centerIndex - maxLen)//2: (centerIndex + maxLen)//2]
# Example usage