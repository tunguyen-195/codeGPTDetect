class Node:
    """Represents a node in the Binary Search Tree."""
    
    def __init__(self, value: int):
        """
        Initializes a new Node with the given value.
        
        """
        self.value = value
        self.left: Node | None = None
        self.right: Node | None = None
class BinarySearchTree:
    """Represents a Binary Search Tree."""
    
    def __init__(self):
        """Initializes an empty Binary Search Tree."""
        self.root: Node | None = None
    def insert(self, value: int):
        """
        Inserts a new value into the Binary Search Tree.
        
        
        TypeError: If the value is not an integer.
        """
        if not isinstance(value, int):
            raise TypeError("Value must be an integer.")
        
        if self.root is None:
            self.root = Node(value)
        else:
            self._insert_recursive(self.root, value)
    def _insert_recursive(self, node: Node, value: int):
        """
        Recursively inserts a new value into the Binary Search Tree.
        