def three_sum(nums: list[int]):
    """
    Returns all unique triplets in the given list of integers that sum up to zero.
    """
    # Sort the input list to apply the two-pointer technique
    nums.sort()
    # Initialize an empty list to store the result
    triplets = []
    # Iterate over the list with the first pointer
    for i in range(len(nums) - 2):
        # Skip the same result
        if i > 0 and nums[i] == nums[i - 1]:
            continue
        # Initialize the second pointer at the next element
        left = i + 1
        # Initialize the third pointer at the end of the list
        right = len(nums) - 1
        while left < right:
            # Calculate the sum of the three elements
            total = nums[i] + nums[left] + nums[right]
            # If the sum is zero, add the triplet to the result and move both pointers
            if total == 0:
                triplets.append((nums[i], nums[left], nums[right]))
                # Move the left pointer to find the next triplet
                left += 1
                # Skip the same result
                while left < right and nums[left] == nums[left - 1]:
                    left += 1
                # Move the right pointer to find the next triplet
                right -= 1
                # Skip the same result
                while left < right and nums[right] == nums[right + 1]:
                    right -= 1