class HeapSort:
    """
    HeapSort implementation using a max heap.
    Time complexity:
    - Best case: O(n log n)
    - Average case: O(n log n)
    - Worst case: O(n log n)
    """
    def __init__(self, arr: list):
        """
        Initialize the HeapSort object.
        :param arr: The input array to be sorted
        """
        self.arr = arr
    def build_max_heap(self):
        """
        Build a max heap from the input array.
        Time complexity: O(n)
        """
        for i in range(len(self.arr) // 2 - 1, -1, -1):
            self.max_heapify(i)
    def max_heapify(self, i: int):
        """
        Max heapify the subtree rooted at index i.
        Time complexity: O(log n)
        """
        largest = i
        left = 2 * i + 1
        right = 2 * i + 2
        if left < len(self.arr) and self.arr[left] > self.arr[largest]:
            largest = left
