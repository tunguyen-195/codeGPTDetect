def heapify(arr: list[int], n: int, i: int):
    """
    Transforms a subtree rooted at index i into a max heap.
    Time complexity: O(log n)
    """
    largest = i
    left = 2 * i + 1
    right = 2 * i + 2
    # Check if the left child exists and is greater than the root
    if left < n and arr[left] > arr[largest]:
        largest = left
    # Check if the right child exists and is greater than the largest so far
    if right < n and arr[right] > arr[largest]:
        largest = right
    # If the largest is not the root, swap them and recursively heapify the affected subtree
    if largest != i:
        arr[i], arr[largest] = arr[largest], arr[i]
        heapify(arr, n, largest)
def heap_sort(arr: list[int]):
    """
    Sorts an array in ascending order using the HeapSort algorithm.
    Time complexity: O(n log n)
    Space complexity: O(1)
    """
    n = len(arr)
    # Build a max heap
    for i in range(n // 2 - 1, -1, -1):
        heapify(arr, n, i)
    # Extract elements one by one
    for i in range(n - 1, 0, -1):
        # Swap the root (max element) with the last element
        arr[0], arr[i] = arr[i], arr[0]