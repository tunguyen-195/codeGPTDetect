def linear_search_sentinel(array: list, target: int):
    """
    Searches for a target value in a list using linear search with sentinel.
    """
    if not array:
        raise ValueError("Input list is empty")
    # Create a copy of the original array to avoid modifying it
    array_copy = array.copy()
    # Append the target value to the end of the array as a sentinel
    array_copy.append(target)
    # Initialize the index to 0
    index = 0
    # Loop through the array until we find the target value
    while array_copy[index] != target:
        index += 1
    # If the index is equal to the length of the original array, the target value was not found
    if index == len(array):
        return -1
    else:
        return index
def main():
    # Example usage
    array = [3, 5, 2, 7, 9, 1, 4]
    target = 7
    result = linear_search_sentinel(array, target)
    if result != -1:
        print(f"Target {target} found at index {result}")
    else:
        print(f"Target {target} not found in the array")
if __name__ == "__main__":
    main()