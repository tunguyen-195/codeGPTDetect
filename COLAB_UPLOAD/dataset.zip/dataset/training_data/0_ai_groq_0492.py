def max_subarray_sum(nums: list[int]):
    """
    Returns the maximum sum of a contiguous subarray within the given list of numbers.
    - nums: A list of integers.
    - The maximum sum of a contiguous subarray.
    Time Complexity: O(n)
    Space Complexity: O(1)
    """
    if not nums:
        raise ValueError("Input list is empty")
    max_current = max_global = nums[0]
    for num in nums[1:]:
        # Update max_current to be the maximum of the current number and the sum of max_current and the current number
        max_current = max(num, max_current + num)
        
        # Update max_global to be the maximum of max_global and max_current
        max_global = max(max_global, max_current)
    return max_global
# Example usage:
numbers = [-2, -3, 4, -1, -2, 1, 5, -3]
result = max_subarray_sum(numbers)
print("Maximum subarray sum:", result)
# Time and space complexity analysis:
# - Time complexity: O(n), where n is the length of the input list, because we're iterating through the list once.
# - Space complexity: O(1), because we're using a constant amount of space to store the maximum current and global sums.