def manacher(s: str):
    """
    Manacher's algorithm to find the longest palindrome in a given string.
    str: The longest palindrome in the input string.
    ValueError: If the input string is empty.
    """
    # Handle edge case: empty string
    if not s:
        raise ValueError("Input string cannot be empty")
    # Preprocess the string to handle odd-length palindromes
    # by inserting a special character between each pair of characters
    T = '#'.join('^{}$'.format(s))
    n = len(T)
    P = [0] * n
    C = R = 0
    for i in range(1, n - 1):
        # Mirror the current position around the center of the current palindrome
        P[i] = (R > i) and min(R - i, P[2 * C - i])
        # Attempt to expand the current palindrome
        while T[i + 1 + P[i]] == T[i - 1 - P[i]]:
            P[i] += 1
        # If the current palindrome is larger than the previous one,
        # update the center and right boundary of the current palindrome
        if i + P[i] > R:
            C, R = i, i + P[i]
    # Find the maximum palindrome and its center
    max_len, max_center = max((n, i) for i, n in enumerate(P))
    # Return the longest palindrome
    return s[(max_center - max_len) // 2: (max_center + max_len) // 2]
# Example usage:
print(manacher("babad"))  # Output: "bab"