def manacher(s: str):
    """
    Manacher's algorithm to find the longest palindrome in a given string.
    str: The longest palindrome in the input string.
    ValueError: If the input is not a string.
    """
    # Check if input is a string
    if not isinstance(s, str):
        raise ValueError("Input must be a string.")
    # Preprocess the string to handle even length palindromes
    s = '#'.join('^{}$'.format(s))
    n = len(s)
    P = [0] * n
    C = R = 0
    # Iterate over the string to find the longest palindrome
    for i in range(1, n - 1):
        # If i is within the current right boundary, use the mirror property
        if R > i:
            i_mirror = 2 * C - i
            P[i] = min(R - i, P[i_mirror])
        # Attempt to expand the palindrome centered at i
        while s[i + 1 + P[i]] == s[i - 1 - P[i]]:
            P[i] += 1
        # If palindrome centered at i expand past R,
        # adjust center based on expanded palindrome.
        if i + P[i] > R:
            C, R = i, i + P[i]
    # Find the maximum even length palindrome
    maxLen, centerIndex = max((n, i) for i, n in enumerate(P))
    return s[centerIndex - maxLen:centerIndex + maxLen].replace('#', '')