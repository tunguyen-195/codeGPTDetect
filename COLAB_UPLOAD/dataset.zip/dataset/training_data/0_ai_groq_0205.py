def find_substrings(input_string: str):
    """
    Generate all possible substrings of a given string.
    """
    if not isinstance(input_string, str):
        raise TypeError("Input must be a string.")
    # Initialize an empty list to store substrings
    substrings = []
    # Iterate over the string with two nested loops to generate all substrings
    for i in range(len(input_string)):
        # The outer loop determines the starting index of the substring
        for j in range(i + 1, len(input_string) + 1):
            # The inner loop determines the ending index of the substring
            substrings.append(input_string[i:j])
    return substrings
def main():
    # Example usage:
    input_str = "abcde"
    substrings = find_substrings(input_str)
    print("Substrings of '{}' are: {}".format(input_str, substrings))
if __name__ == "__main__":
    main()