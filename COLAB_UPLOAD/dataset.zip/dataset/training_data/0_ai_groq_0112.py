from typing import Dict
def fibonacci(n: int, memo: Dict[int, int] = {}):
    """
    Calculate the nth Fibonacci number using recursion with memoization.
    """
    # Check if n is a negative integer
    if n < 0:
        raise ValueError("n must be a non-negative integer")
    # Base cases
    if n == 0:
        return 0
    elif n == 1:
        return 1
    # Check if the Fibonacci number is already in the memo dictionary
    elif n in memo:
        return memo[n]
    else:
        # Calculate the nth Fibonacci number and store it in the memo dictionary
        result = fibonacci(n-1, memo) + fibonacci(n-2, memo)
        memo[n] = result
        return result
# Example usage:
if __name__ == "__main__":
    try:
        n = 10
        result = fibonacci(n)
        print(f"The {n}th Fibonacci number is: {result}")
    except ValueError as e:
        print(f"Error: {e}")