class CircularQueue:
    """
    A class representing a Circular Queue data structure.
    ----------
    size : int
        The fixed size of the queue.
    queue : list
        The underlying list representing the queue.
    Methods:
    -------
    enqueue(item: T) -> None
        Adds an item to the end of the queue.
    dequeue() -> T | None
        Removes an item from the front of the queue.
    is_empty() -> bool
        Checks if the queue is empty.
    is_full() -> bool
        Checks if the queue is full.
    peek() -> T | None
        Returns the item at the front of the queue without removing it.
    clear() -> None
        Removes all items from the queue.
    """
    def __init__(self, size: int):
        """
        Initializes a new instance of the CircularQueue class.
        ----
        size : int
            The fixed size of the queue.
        """
        self.size = size
        self.queue = [None] * size
        self.front = 0
        self.rear = 0
        self.count = 0
