def three_sum(nums: list[int]):
    """
    Returns all unique triplets in the given list of integers that sum up to zero.
    list[tuple[int, int, int]]: A list of unique triplets that sum up to zero.
    """
    if len(nums) < 3:
        return []
    # Sort the list to apply the two-pointer technique
    nums.sort()
    result = []
    for i in range(len(nums) - 2):
        # Skip the same result
        if i > 0 and nums[i] == nums[i - 1]:
            continue
        left, right = i + 1, len(nums) - 1
        while left < right:
            total = nums[i] + nums[left] + nums[right]
            if total < 0:
                left += 1
            elif total > 0:
                right -= 1
            else:
                result.append((nums[i], nums[left], nums[right]))
                # Skip the same result
                while left < right and nums[left] == nums[left + 1]:
                    left += 1
                while left < right and nums[right] == nums[right - 1]:
                    right -= 1
                left += 1
                right -= 1
    return result