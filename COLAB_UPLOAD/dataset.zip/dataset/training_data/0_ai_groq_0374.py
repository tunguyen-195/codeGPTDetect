def jump_search(arr: list[int], x: int):
    """
    Jump Search algorithm implementation.
    int: The index of the target value if found, -1 otherwise.
    """
    n = len(arr)
    step = int(n ** 0.5)  # Calculate the step size
    # Find the block where the target value is present
    prev = 0
    while arr[min(step, n) - 1] < x:
        prev = step
        step += int(n ** 0.5)
        if prev >= n:
            return -1
    # Perform a linear search for the target value in the block
    while arr[prev] < x:
        prev += 1
        if prev == min(step, n):
            return -1
    # If the target value is found, return its index
    if arr[prev] == x:
        return prev
    # If the target value is not found, return -1
    return -1
def main():
    """
    Example usage of the Jump Search algorithm.
    """
    arr = [0, 1, 1, 2, 3, 5, 8, 13, 21, 34, 55, 89, 144, 233, 377, 610]
    x = 55
    index = jump_search(arr, x)