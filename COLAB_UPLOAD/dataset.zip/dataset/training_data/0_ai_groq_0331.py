from typing import Dict, List, Set
class Graph:
    """
    A class representing an undirected graph using adjacency list representation.
    
    ----------
    num_vertices : int
        The number of vertices in the graph.
    adj_list : Dict[int, List[int]]
        The adjacency list representation of the graph.
    visited : Set[int]
        A set of visited vertices.
    ap : Set[int]
        A set of articulation points.
    time : int
        The discovery time of the current vertex.
    parent : Dict[int, int]
        The parent of the current vertex in the DFS tree.
    low : Dict[int, int]
        The lowest reachable ancestor of the current vertex.
    """
    def __init__(self, num_vertices: int):
        """
        Initializes an empty graph with the given number of vertices.
        
        ----------
        num_vertices : int
            The number of vertices in the graph.
        """
        self.num_vertices = num_vertices
        self.adj_list = {i: [] for i in range(num_vertices)}
        self.visited = set()
        self.ap = set()
        self.time = 0
        self.parent = {}
        self.low = {}
        self.disc = {}
