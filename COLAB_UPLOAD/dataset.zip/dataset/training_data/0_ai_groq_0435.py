class Node:
    """Represents a node in the Binary Search Tree."""
    
    def __init__(self, value: int):
        """
        Initializes a Node with a value and two children (left and right).
        
        """
        self.value = value
        self.left: Node = None
        self.right: Node = None
class BinarySearchTree:
    """Represents a Binary Search Tree."""
    
    def __init__(self):
        """
        Initializes an empty Binary Search Tree.
        """
        self.root: Node = None
    def insert(self, value: int):
        """
        Inserts a value into the Binary Search Tree.
        
        
        ValueError: If the value is already in the tree.
        """
        if self.root is None:
            self.root = Node(value)
        else:
            self._insert(self.root, value)
    def _insert(self, node: Node, value: int):
        """
        Recursively inserts a value into the Binary Search Tree.
        
