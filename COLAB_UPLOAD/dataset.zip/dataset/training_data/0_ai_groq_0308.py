def max_subarray_sum(nums: list[int]):
    """
    Find the maximum subarray sum using Kadane's algorithm.
    """
    if not nums:
        raise ValueError("Input list cannot be empty")
    max_current = max_global = nums[0]
    # Initialize max_current and max_global with the first element of the list
    for num in nums[1:]:
        # For each element in the list starting from the second element
        max_current = max(num, max_current + num)
        # Update max_current to be the maximum of the current number and the sum of the current number and max_current
        max_global = max(max_global, max_current)
        # Update max_global to be the maximum of max_global and max_current
    return max_global