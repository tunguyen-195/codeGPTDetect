def longest_increasing_subsequence(nums: list[int]):
    """
    Returns the length of the longest increasing subsequence in the given list of numbers.
    nums: A list of integers.
    An integer representing the length of the longest increasing subsequence.
    Time Complexity:
    O(n^2) where n is the number of elements in the list.
    Space Complexity:
    O(n) for storing the lengths of the longest increasing subsequences ending at each position.
    """
    if not nums:
        return 0
    # Initialize a list to store the lengths of the longest increasing subsequences
    # ending at each position. The length of the longest increasing subsequence
    # ending at the first position is 1, as a single number is always an increasing subsequence.
    lengths = [1] * len(nums)
    # Iterate over the list to fill in the lengths of the longest increasing subsequences.
    for i in range(1, len(nums)):
        for j in range(i):
            # If the current number is greater than the number at position j, it can be appended
            # to the increasing subsequence ending at position j, resulting in a longer increasing subsequence.
            if nums[i] > nums[j]:
                lengths[i] = max(lengths[i], lengths[j] + 1)
    # The length of the longest increasing subsequence is the maximum length found in the list.
    return max(lengths)
def longest_increasing_subsequence_with_indices(nums: list[int]):
    """
    Returns the indices of the longest increasing subsequence in the given list of numbers.
    nums: A list of integers.
    A list of tuples, where each tuple contains the index and value of a number in the longest increasing subsequence.