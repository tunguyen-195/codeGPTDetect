from typing import Dict, List
class Graph:
    """Represents an undirected graph."""
    
    def __init__(self, num_vertices: int):
        """
        Initializes the graph with a specified number of vertices.
        
        """
        self.num_vertices = num_vertices
        self.adj_list = {i: [] for i in range(num_vertices)}
    def add_edge(self, v: int, w: int):
        """
        Adds an edge between two vertices in the graph.
        
        
        ValueError: If either vertex is out of range.
        """
        if v < 0 or v >= self.num_vertices or w < 0 or w >= self.num_vertices:
            raise ValueError("Vertex out of range")
        self.adj_list[v].append(w)
        self.adj_list[w].append(v)
    def is_cyclic_util(self, v: int, visited: List[bool], parent: int):
        """
        Recursive utility function to detect cycle in the graph.
        
        
        bool: True if a cycle is detected, False otherwise.
        """
        visited[v] = True
        for neighbor in self.adj_list[v]: