def rabin_karp(text: str, pattern: str):
    """
    Implements Rabin-Karp string search algorithm.
    """
    if not pattern:
        raise ValueError("Pattern cannot be empty")
    # Calculate the length of the text and pattern
    text_len = len(text)
    pattern_len = len(pattern)
    # Base cases
    if text_len < pattern_len:
        return []
    # Calculate the hash values for the pattern and the first window of the text
    pattern_hash = 0
    text_hash = 0
    h = 1
    for _ in range(pattern_len - 1):
        h = (h * 256) % 101  # Prime number for modulo operation
    for i in range(pattern_len):
        pattern_hash = (256 * pattern_hash + ord(pattern[i])) % 101
        text_hash = (256 * text_hash + ord(text[i])) % 101
    # Initialize the result list
    result = []
    # Slide the pattern over the text and check for matches
    for i in range(text_len - pattern_len + 1):
        # Check if the current window of the text matches the pattern
        if pattern_hash == text_hash:
            match = True
            for j in range(pattern_len):
                if text[i + j] != pattern[j]:
                    match = False
                    break
