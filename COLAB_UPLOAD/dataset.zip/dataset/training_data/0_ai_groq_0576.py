from typing import Dict, List, Any
class Graph:
    """
    A simple implementation of a graph using an adjacency list representation.
    """
    def __init__(self):
        """
        Initializes an empty graph.
        """
        self.adjacency_list: Dict[Any, List[Any]] = {}
    def add_vertex(self, vertex: Any):
        """
        Adds a vertex to the graph.
        """
        if vertex not in self.adjacency_list:
            self.adjacency_list[vertex] = []
    def add_edge(self, vertex1: Any, vertex2: Any):
        """
        Adds an edge between two vertices in the graph.
        """
        if vertex1 not in self.adjacency_list or vertex2 not in self.adjacency_list:
            raise ValueError("Both vertices must be in the graph")
        self.adjacency_list[vertex1].append(vertex2)
        self.adjacency_list[vertex2].append(vertex1)
    def dfs(self, start_vertex: Any):
        """
        Performs a depth-first search traversal of the graph starting from the given vertex.
        """
        if start_vertex not in self.adjacency_list:
            raise ValueError("Start vertex must be in the graph")
        visited: Set[Any] = set()