def merge_sort(arr: list[int]):
    """
    Sorts the input array in ascending order using the MergeSort algorithm.
    This implementation uses in-place optimization, meaning it sorts the array directly without creating a temporary array.
    The time complexity of this algorithm is O(n log n) on average, where n is the number of elements in the array.
    """
    # Check if the input array is empty or contains non-integer values
    if not arr or not all(isinstance(x, int) for x in arr):
        raise ValueError("Input array must be a non-empty list of integers")
    # Call the merge_sort function recursively
    _merge_sort(arr, 0, len(arr) - 1)
def _merge_sort(arr: list[int], low: int, high: int):
    """
    Recursive helper function for merge_sort.
    """
    # Base case: If the subarray has only one element, it is already sorted
    if low >= high:
        return
    # Find the middle index of the subarray
    mid = (low + high) // 2
    # Recursively sort the left and right halves of the subarray
    _merge_sort(arr, low, mid)
    _merge_sort(arr, mid + 1, high)
    # Merge the sorted left and right halves
    _merge(arr, low, mid, high)
def _merge(arr: list[int], low: int, mid: int, high: int):
    """
    Merges two sorted subarrays into a single sorted subarray.
