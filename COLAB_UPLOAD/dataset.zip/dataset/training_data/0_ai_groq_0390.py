def climb_stairs(n: int):
    """
    This function calculates the number of distinct ways to climb 'n' stairs.
    int: The number of distinct ways to climb 'n' stairs.
    Time Complexity: O(n)
    Space Complexity: O(n)
    """
    if n <= 2:
        return n
    # Initialize a list to store the number of ways to climb 'i' stairs
    ways = [0] * (n + 1)
    ways[1] = 1
    ways[2] = 2
    # For each stair from 3 to 'n', calculate the number of ways to climb it
    for i in range(3, n + 1):
        # The number of ways to climb 'i' stairs is the sum of the number of ways to climb 'i-1' and 'i-2' stairs
        ways[i] = ways[i - 1] + ways[i - 2]
    # Return the number of ways to climb 'n' stairs
    return ways[n]