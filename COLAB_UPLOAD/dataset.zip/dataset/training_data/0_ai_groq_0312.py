def find_missing_number(nums: list[int]):
    """
    Finds the missing number in an array from 1 to n.
    int: The missing number.
    ValueError: If the input list is empty or not a list of integers.
    """
    # Check if the input is a list of integers
    if not isinstance(nums, list) or not all(isinstance(num, int) for num in nums):
        raise ValueError("Input must be a list of integers")
    # Check if the list is empty
    if len(nums) == 0:
        raise ValueError("Input list cannot be empty")
    # Calculate the sum of numbers from 1 to n using Gauss' formula
    n = len(nums) + 1  # The length of the list plus one (the missing number)
    expected_sum = n * (n + 1) // 2  # Calculate the sum of numbers from 1 to n
    # Calculate the sum of the actual numbers in the list
    actual_sum = sum(nums)
    # The missing number is the difference between the expected sum and the actual sum
    missing_number = expected_sum - actual_sum
    return missing_number