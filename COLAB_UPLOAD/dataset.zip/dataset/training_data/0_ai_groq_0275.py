def ternary_search(f: callable, a: float, b: float, tol: float = 1e-6, max_iter: int = 100):
    """
    Ternary search for unimodal functions.
    """
    if a >= b:
        raise ValueError("Interval is empty")
    # Check if the function is unimodal
    def is_unimodal(x: float):
        """
        Check if the function is unimodal.
        """
        return (f(x - 1) <= f(x) and f(x) >= f(x + 1)) or (f(x - 1) >= f(x) and f(x) <= f(x + 1))
    if not is_unimodal(a) or not is_unimodal(b):
        raise ValueError("Function is not unimodal")
    # Initialize the search interval
    c = (a + b) / 2
    d = (a + c) / 2
    e = (c + b) / 2
    for _ in range(max_iter):
        # Check if the function is unimodal in the left interval
        if is_unimodal(d):
            # Check if the function is unimodal in the left sub-interval
            if is_unimodal(a):
                b = d
            else:
                a = d
        else:
            # Check if the function is unimodal in the right sub-interval
            if is_unimodal(e):
                a = d
            else:
                b = e
