from typing import Dict
def coin_change_min_coins(coins: list[int], amount: int):
    """
    Returns the minimum number of coins needed to reach the given amount.
    int: The minimum number of coins needed. If it's impossible to reach the amount, returns -1.
    Time complexity: O(amount * len(coins))
    Space complexity: O(amount)
    """
    # Create a dictionary to store the minimum number of coins for each amount
    dp: Dict[int, int] = {0: 0}
    for coin in coins:
        # For each coin, update the minimum number of coins for each amount
        for curr_amount in range(1, amount + 1):
            if curr_amount >= coin and curr_amount - coin in dp:
                # If using the current coin results in a smaller number of coins, update dp
                dp[curr_amount] = min(dp.get(curr_amount, float('inf')), dp[curr_amount - coin] + 1)
    return dp.get(amount, -1)
# Example usage:
coins = [1, 2, 5]
amount = 11
print(coin_change_min_coins(coins, amount))  # Output: 3 (11 = 5 + 5 + 1)