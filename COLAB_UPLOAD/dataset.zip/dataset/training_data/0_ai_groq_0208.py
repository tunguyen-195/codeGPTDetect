def max_subarray_sum(nums: list[int]):
    """
    Returns the maximum sum of a contiguous subarray within the given list of numbers.
    int: The maximum sum of a contiguous subarray.
    ValueError: If the input list is empty.
    TypeError: If the input is not a list of integers.
    """
    if not isinstance(nums, list):
        raise TypeError("Input must be a list")
    if not all(isinstance(num, int) for num in nums):
        raise TypeError("Input list must contain only integers")
    if not nums:
        raise ValueError("Input list cannot be empty")
    max_current = max_global = nums[0]
    for num in nums[1:]:
        max_current = max(num, max_current + num)
        max_global = max(max_global, max_current)
    return max_global