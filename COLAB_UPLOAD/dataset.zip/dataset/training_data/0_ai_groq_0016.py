class MaxHeap:
    """
    A class to implement Max Heap with heapify operation.
    """
    def __init__(self):
        """
        Initialize an empty Max Heap.
        """
        self.heap = []
    def insert(self, value: int):
        """
        Insert a value into the Max Heap.
        """
        self.heap.append(value)
        self._heapify_up(len(self.heap) - 1)
    def _heapify_up(self, index: int):
        """
        Heapify up the heap from the given index.
        """
        parent_index = (index - 1) // 2
        if index <= 0:
            return
        elif self.heap[parent_index] < self.heap[index]:
            self.heap[parent_index], self.heap[index] = self.heap[index], self.heap[parent_index]
            self._heapify_up(parent_index)
    def _heapify_down(self, index: int):
        """
        Heapify down the heap from the given index.
        """
        left_child_index = 2 * index + 1
        right_child_index = 2 * index + 2
        largest = index