class Item:
    """Represents an item with its weight and value."""
    def __init__(self, weight: float, value: float):
        """
        Initializes an Item object.
        - weight (float): The weight of the item.
        - value (float): The value of the item.
        """
        self.weight = weight
        self.value = value
class FractionalKnapsack:
    """Solves the Fractional Knapsack problem using the greedy approach."""
    def __init__(self, capacity: float):
        """
        Initializes a FractionalKnapsack object.
        - capacity (float): The maximum capacity of the knapsack.
        """
        self.capacity = capacity
    def calculate_optimal_value(self, items: list[Item]):
        """
        Calculates the optimal value that can be obtained with the given capacity.
        - items (list[Item]): A list of items.
        - float: The optimal value.
        - ValueError: If the capacity is negative.
        """
        if self.capacity < 0:
            raise ValueError("Capacity cannot be negative")
        # Sort items by their value-to-weight ratio in descending order
        # This is the key step in the greedy approach
        items.sort(key=lambda item: item.value / item.weight, reverse=True)
        total_value = 0.0