def longest_common_prefix(strs: list[str]):
    """
    Finds the longest common prefix among a list of strings.
    """
    if not isinstance(strs, list):
        raise TypeError("Input must be a list of strings.")
    if not all(isinstance(s, str) for s in strs):
        raise TypeError("Input must be a list of strings.")
    if not strs:
        raise ValueError("Input list cannot be empty.")
    # Sort the list of strings. This is because the common prefix will be the same
    # for all permutations of the list, and sorting makes it easier to find the
    # common prefix.
    strs.sort()
    # Take the first and last string from the sorted list. The common prefix must
    # be a prefix of both of these strings.
    first_str = strs[0]
    last_str = strs[-1]
    # Initialize the common prefix as an empty string.
    common_prefix = ""
    # Iterate over the characters in the first string.
    for i in range(len(first_str)):
        # If the character at the current position in the first string is the same
        # as the character at the same position in the last string, add it to the
        # common prefix.
        if i < len(last_str) and first_str[i] == last_str[i]:
            common_prefix += first_str[i]
        # If the characters are different, break the loop because the common
        # prefix cannot be longer than the current position.
        else:
            break
    return common_prefix