class CircularQueue:
    """
    A fixed-size Circular Queue implementation in Python.
    """
    def __init__(self, size: int):
        """
        Initializes a new instance of the CircularQueue class.
        """
        if not isinstance(size, int) or size <= 0:
            raise ValueError("Size must be a positive integer")
        self.size = size
        self.buffer = [None] * size
        self.head = 0
        self.tail = 0
        self.count = 0
    def enqueue(self, item: any):
        """
        Adds an item to the end of the queue.
        """
        if self.count == self.size:
            raise ValueError("Queue is full")
        self.buffer[self.tail] = item
        self.tail = (self.tail + 1) % self.size
        self.count += 1
    def dequeue(self):
        """
        Removes an item from the front of the queue.
        """
        if self.count == 0:
            raise ValueError("Queue is empty")
