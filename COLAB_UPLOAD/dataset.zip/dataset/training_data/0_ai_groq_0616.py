def four_sum(nums: list[int], target: int):
    """
    Returns all unique quadruplets in the given list of integers that sum up to the target value.
    - nums: A list of integers.
    - target: The target sum.
    - A list of lists, where each sublist is a quadruplet of integers that sum up to the target value.
    """
    nums.sort()  # Sort the list to apply two-pointer technique
    result = []  # Initialize an empty list to store the result
    for i in range(len(nums) - 3):  # Iterate over the list with four pointers
        # Skip the same result
        if i > 0 and nums[i] == nums[i - 1]:
            continue
        for j in range(i + 1, len(nums) - 2):
            # Skip the same result
            if j > i + 1 and nums[j] == nums[j - 1]:
                continue
            left, right = j + 1, len(nums) - 1  # Initialize two pointers
            while left < right:
                current_sum = nums[i] + nums[j] + nums[left] + nums[right]
                if current_sum < target:
                    left += 1  # Move the left pointer to increase the sum
                elif current_sum > target:
                    right -= 1  # Move the right pointer to decrease the sum
                else:
                    result.append([nums[i], nums[j], nums[left], nums[right]])
                    # Skip the same result
                    while left < right and nums[left] == nums[left + 1]:
                        left += 1
                    while left < right and nums[right] == nums[right - 1]:
                        right -= 1
                    left += 1
                    right -= 1
    return result