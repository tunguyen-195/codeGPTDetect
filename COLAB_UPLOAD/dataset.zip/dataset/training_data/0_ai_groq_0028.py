def bubble_sort(arr: list):
    """
    Sorts a list of elements in ascending order using the Bubble Sort algorithm with early termination.
    Time Complexity:
        - Best Case: O(n) when the input list is already sorted.
        - Average Case: O(n^2) when the input list is in random order.
        - Worst Case: O(n^2) when the input list is in reverse order.
    """
    # Check if the input is a list
    if not isinstance(arr, list):
        raise ValueError("Input must be a list")
    # Create a copy of the input list to avoid modifying it in-place
    arr = arr.copy()
    # Get the length of the input list
    n = len(arr)
    # Iterate over the list until no more swaps are needed
    for i in range(n):
        # Initialize a flag to track if any swaps were made in the current iteration
        swapped = False
        # Iterate over the list from the first element to the (n - i - 1)th element
        for j in range(n - i - 1):
            # Check if the current element is greater than the next element
            try:
                if arr[j] > arr[j + 1]:
                    # Swap the current element with the next element
                    arr[j], arr[j + 1] = arr[j + 1], arr[j]
                    # Set the flag to True to indicate that a swap was made
                    swapped = True
            except TypeError:
                raise TypeError("List contains non-comparable elements")
        # If no swaps were made in the current iteration, the list is already sorted
        if not swapped: