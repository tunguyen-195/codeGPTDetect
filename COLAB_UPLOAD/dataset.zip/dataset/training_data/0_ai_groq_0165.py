def binary_insertion_sort(arr: list[int]):
    """
    Sorts an array using binary insertion sort algorithm.
    The binary insertion sort algorithm is a variation of the insertion sort algorithm
    that uses binary search to find the position where the current element should be inserted.
    This reduces the number of comparisons required, making it more efficient than the standard insertion sort.
    Time complexity:
        - Best case: O(n log n) when the input array is already sorted.
        - Average case: O(n log n) for random input arrays.
        - Worst case: O(n log n) when the input array is reverse sorted.
    """
    # Check if the input is a list
    if not isinstance(arr, list):
        raise ValueError("Input must be a list")
    # Check if the list contains non-integer values
    if not all(isinstance(x, int) for x in arr):
        raise ValueError("Input list must contain only integers")
    # Handle edge case where the input list is empty
    if len(arr) == 0:
        return arr
    # Iterate over the array starting from the second element
    for i in range(1, len(arr)):
        # Store the current element to be inserted
        current_element = arr[i]
        # Find the position where the current element should be inserted using binary search
        insert_position = binary_search(arr, current_element, 0, i)
        # Shift elements to the right to make space for the current element
        for j in range(i, insert_position, -1):
            arr[j] = arr[j - 1]
        # Insert the current element at the correct position
        arr[insert_position] = current_element