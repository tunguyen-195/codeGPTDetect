def bubble_sort(arr: list):
    """
    Sorts an array in ascending order using Bubble Sort with early termination.
    Bubble Sort is a simple sorting algorithm that repeatedly steps through the list,
    compares adjacent elements and swaps them if they are in the wrong order. The pass
    through the list is repeated until the list is sorted.
    The time complexity of this implementation is O(n^2) in the worst case, but it can
    be reduced to O(n) if the input array is already sorted, as the algorithm will
    terminate early.
    """
    if not isinstance(arr, list):
        raise TypeError("Input must be a list")
    # Get the length of the array
    n = len(arr)
    # Repeat the process until the array is sorted
    for i in range(n):
        # Initialize a flag to check if any swaps were made
        swapped = False
        # Iterate through the array from the first element to the (n-i-1)th element
        for j in range(n - i - 1):
            # If the current element is greater than the next element, swap them
            if arr[j] > arr[j + 1]:
                arr[j], arr[j + 1] = arr[j + 1], arr[j]
                # Set the flag to True to indicate that a swap was made
                swapped = True
        # If no swaps were made in the current iteration, the array is already sorted
        if not swapped:
            break
    return arr