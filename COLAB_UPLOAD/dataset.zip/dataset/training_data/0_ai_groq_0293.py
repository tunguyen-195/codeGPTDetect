from typing import List
def is_palindrome(substring: str):
    """
    Checks if a given substring is a palindrome.
    bool: True if the substring is a palindrome, False otherwise.
    """
    return substring == substring[::-1]
def palindrome_partitioning(s: str):
    """
    Partitions a given string into all possible palindromic substrings.
    List[List[str]]: A list of lists, where each sublist contains a partitioning of the input string into palindromic substrings.
    """
    n = len(s)
    dp = [[False] * n for _ in range(n)]
    partitions = [[] for _ in range(n)]
    # Initialize the diagonal of the dp table to True, since single characters are always palindromes
    for i in range(n):
        dp[i][i] = True
        partitions[i] = [s[i]]
    # Fill in the dp table in a bottom-up manner
    for length in range(2, n + 1):
        for i in range(n - length + 1):
            j = i + length - 1
            if length == 2:
                dp[i][j] = is_palindrome(s[i:j + 1])
                partitions[i] = [s[i:j + 1]]
            else:
                for k in range(i, j):
                    if dp[i][k] and dp[k + 1][j]:
                        dp[i][j] = True