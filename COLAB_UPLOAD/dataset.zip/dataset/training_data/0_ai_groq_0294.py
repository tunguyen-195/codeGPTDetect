class Solution:
    """
    Solves the Word Break problem using dynamic programming.
    bool: True if the sentence can be broken down into words from the dictionary, False otherwise.
    """
    def wordBreak(self, word_dict: list[str], sentence: str):
        """
        Checks if the sentence can be broken down into words from the dictionary.
        bool: True if the sentence can be broken down into words from the dictionary, False otherwise.
        """
        dp = [False] * (len(sentence) + 1)  # Initialize a dynamic programming array
        dp[0] = True  # The empty string can always be broken down
        for i in range(1, len(sentence) + 1):
            # Check each word in the dictionary
            for j in range(i):
                # If the substring from index j to i-1 is in the dictionary and the substring before it can be broken down
                if dp[j] and sentence[j:i] in word_dict:
                    dp[i] = True  # Then the substring from index 0 to i can be broken down
                    break  # We don't need to check the rest of the substrings
        return dp[-1]  # Return whether the entire sentence can be broken down
# Example usage
if __name__ == "__main__":
    solution = Solution()
    word_dict = ["apple", "pen"]
    sentence = "applepenapple"
    print(solution.wordBreak(word_dict, sentence))  # Output: True
    word_dict = ["cats", "dog", "sand", "and", "cat"]