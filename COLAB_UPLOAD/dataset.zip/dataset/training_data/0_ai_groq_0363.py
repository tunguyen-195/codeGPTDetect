def bubble_sort(arr: list[int]):
    """
    Sorts an array of integers in ascending order using Bubble Sort algorithm.
    
    Bubble sort is a simple sorting algorithm that repeatedly steps through the list, 
    compares adjacent elements and swaps them if they are in the wrong order. The pass 
    through the list is repeated until the list is sorted. The algorithm, which is 
    simple but inefficient, is based on the idea that bubble sort works by repeatedly 
    swapping the adjacent elements if they are in wrong order.
    Time complexity:
    - Best case: O(n) when the input array is already sorted
    - Average case: O(n^2) where n is the number of items being sorted
    - Worst case: O(n^2) when the input array is sorted in reverse order
    :param arr: A list of integers to be sorted
    :return: A sorted list of integers
    """
    n = len(arr)
    
    # If the array has 1 or 0 elements, it's already sorted
    if n <= 1:
        return arr
    
    # Repeat the process until no more swaps are needed
    for i in range(n - 1):
        # Initialize a flag to track if any swaps were made in the current pass
        swapped = False
        
        # Iterate over the array from the first element to the (n - i - 1)th element
        for j in range(n - i - 1):
            # If the current element is greater than the next element, swap them
            if arr[j] > arr[j + 1]:
                # Swap the elements
                arr[j], arr[j + 1] = arr[j + 1], arr[j]
                # Set the flag to True to indicate that a swap was made
                swapped = True
        
        # If no swaps were made in the current pass, the array is already sorted
        if not swapped: