def find_duplicate(nums: list[int]):
    """
    Find a duplicate number in an array.
    This function uses Floyd's Tortoise and Hare (Cycle Detection) algorithm
    to detect a cycle in the linked list represented by the array.
    """
    if len(nums) < 2:
        raise ValueError("Input list must contain at least two elements")
    # Phase 1: Detecting the cycle using tortoise and hare algorithm
    tortoise = nums[0]
    hare = nums[0]
    while True:
        tortoise = nums[tortoise]
        hare = nums[nums[hare]]
        if tortoise == hare:
            break
    # Phase 2: Finding the start of the cycle
    ptr1 = nums[0]
    ptr2 = tortoise
    while ptr1 != ptr2:
        ptr1 = nums[ptr1]
        ptr2 = nums[ptr2]
    return ptr1