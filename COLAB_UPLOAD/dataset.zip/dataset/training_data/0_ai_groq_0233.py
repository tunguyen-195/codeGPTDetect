class Activity:
    """Represents an activity with a start time and an end time."""
    def __init__(self, start: int, end: int, name: str):
        """
        Initializes an Activity instance.
        """
        self.start = start
        self.end = end
        self.name = name
    def __repr__(self):
        """Returns a string representation of the activity."""
        return f"Activity('{self.name}', {self.start}, {self.end})"
def activity_selection(activities: list[Activity]):
    """
    Selects the maximum number of non-overlapping activities using a greedy approach.
    """
    if not activities:
        raise ValueError("Input list cannot be empty")
    # Sort activities by their end times
    activities.sort(key=lambda activity: activity.end)
    # Initialize the list of selected activities with the first activity
    selected_activities = [activities[0]]
    # Iterate over the remaining activities
    for activity in activities[1:]:
        # Check if the current activity does not overlap with the last selected activity
        if activity.start >= selected_activities[-1].end:
            # Add the current activity to the list of selected activities
            selected_activities.append(activity)
    return selected_activities
# Example usage
if __name__ == "__main__":