def exponential_search(arr: list[int], target: int):
    """
    Exponential Search algorithm to find the index of the target element in an unbounded array.
    """
    if not isinstance(arr, list) or not all(isinstance(x, int) for x in arr):
        raise TypeError("Input array must be a list of integers.")
    if not isinstance(target, int):
        raise TypeError("Target must be an integer.")
    # Find the range where the target element can be
    n = len(arr)
    if n == 0:
        return -1  # Target not found in an empty array
    if arr[0] == target:
        return 0  # Target found at the first index
    i = 1
    while i < n and arr[i] <= target:
        # Calculate the next range to search in
        i = i * 2
    # Perform Binary Search in the range
    return binary_search(arr, i // 2, min(i, n), target)
def binary_search(arr: list[int], low: int, high: int, target: int):
    """
    Binary Search algorithm to find the index of the target element in a sorted array.
    """
    if not isinstance(arr, list) or not all(isinstance(x, int) for x in arr):
        raise TypeError("Input array must be a list of integers.")
    if not isinstance(target, int):
        raise TypeError("Target must be an integer.")
    while low <= high: