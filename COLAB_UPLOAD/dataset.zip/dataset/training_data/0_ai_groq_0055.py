def climb_stairs(n: int):
    """
    This function calculates the number of distinct ways to climb n stairs.
    
    The problem is solved using dynamic programming, where each step is 
    dependent on the previous steps.
    """
    if n < 1:
        raise ValueError("Input should be a positive integer.")
    # Base cases: there is only one way to climb 1 stair and two ways to climb 2 stairs
    if n == 1:
        return 1
    elif n == 2:
        return 2
    # Initialize a list to store the number of ways to climb i stairs
    ways = [0] * (n + 1)
    ways[1] = 1
    ways[2] = 2
    # For each stair from 3 to n, calculate the number of ways to climb
    for i in range(3, n + 1):
        # The number of ways to climb i stairs is the sum of the number of ways to climb (i-1) stairs and (i-2) stairs
        ways[i] = ways[i - 1] + ways[i - 2]
    return ways[n]
def climb_stairs_optimized(n: int):
    """
    This function calculates the number of distinct ways to climb n stairs.
    
    The problem is solved using dynamic programming with optimized space complexity.
    """
    if n < 1:
        raise ValueError("Input should be a positive integer.")
    # Base cases: there is only one way to climb 1 stair and two ways to climb 2 stairs