def product_except_self(nums: list[int]):
    """
    This function calculates the product of all numbers in the input array except for the number itself.
    list[int]: A list of integers where each element is the product of all numbers in the input array except for the number itself.
    ValueError: If the input list is empty.
    """
    # Check if the input list is empty
    if not nums:
        raise ValueError("Input list cannot be empty")
    # Initialize a list to store the output
    output = [1] * len(nums)
    # Calculate the running product from the left
    left_product = 1
    for i in range(len(nums)):
        # Multiply the current output element with the running product from the left
        output[i] *= left_product
        # Update the running product from the left
        left_product *= nums[i]
    # Calculate the running product from the right
    right_product = 1
    for i in range(len(nums) - 1, -1, -1):
        # Multiply the current output element with the running product from the right
        output[i] *= right_product
        # Update the running product from the right
        right_product *= nums[i]
    return output