def merge_sort(arr: list[int]):
    """
    Sorts the input array in-place using the MergeSort algorithm.
    Time complexity:
    - Best case: O(n log n)
    - Average case: O(n log n)
    - Worst case: O(n log n)
    Space complexity: O(log n) due to recursive call stack.
    :param arr: Input array to be sorted in-place.
    :return: None (array is sorted in-place)
    """
    _merge_sort_helper(arr, 0, len(arr) - 1)
def _merge_sort_helper(arr: list[int], start: int, end: int):
    """
    Recursive helper function for MergeSort.
    :param arr: Input array to be sorted in-place.
    :param start: Start index of the current subarray.
    :param end: End index of the current subarray.
    :return: None (array is sorted in-place)
    """
    if start < end:
        mid = (start + end) // 2
        _merge_sort_helper(arr, start, mid)
        _merge_sort_helper(arr, mid + 1, end)
        _merge(arr, start, mid, end)
def _merge(arr: list[int], start: int, mid: int, end: int):
    """
    Merges two sorted subarrays in-place.
    :param arr: Input array to be sorted in-place.
    :param start: Start index of the first subarray.
    :param mid: End index of the first subarray.
    :param end: End index of the second subarray.
    :return: None (array is sorted in-place)