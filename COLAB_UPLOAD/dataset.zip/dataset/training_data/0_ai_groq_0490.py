def climb_stairs(n: int):
    """
    This function calculates the number of distinct ways a person can climb n stairs.
    int: The number of distinct ways to climb the stairs.
    Time Complexity: O(n)
    Space Complexity: O(n)
    """
    # Check if the input is a non-negative integer
    if not isinstance(n, int) or n < 0:
        raise ValueError("Input must be a non-negative integer.")
    # Base cases
    if n == 0:
        return 1  # There is one way to climb 0 stairs (do nothing)
    elif n == 1:
        return 1  # There is one way to climb 1 stair (one step)
    # Initialize a list to store the number of ways to climb each stair
    dp = [0] * (n + 1)
    dp[0] = 1  # Base case: one way to climb 0 stairs
    dp[1] = 1  # Base case: one way to climb 1 stair
    # Fill up the dp list using the recurrence relation: dp[i] = dp[i-1] + dp[i-2]
    for i in range(2, n + 1):
        # For each stair, we can either come from the previous stair or the stair before that
        dp[i] = dp[i - 1] + dp[i - 2]
    # The answer is the number of ways to climb the nth stair
    return dp[n]