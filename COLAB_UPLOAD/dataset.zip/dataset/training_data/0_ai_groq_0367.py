def radix_sort(numbers: list[int]):
    """
    Sorts a list of integers using Radix Sort.
    Time complexity: O(nk), where n is the number of elements and k is the number of digits in the maximum number.
    Space complexity: O(n + k), for the auxiliary arrays used in the counting sort.
    """
    # Check if the input list contains non-integer values
    if not all(isinstance(num, int) for num in numbers):
        raise ValueError("The input list must contain only integers.")
    # Find the maximum number to determine the number of digits
    max_num = max(numbers)
    # Initialize the exponent to 1 (for the least significant digit)
    exp = 1
    # Perform counting sort for every digit
    while max_num // exp > 0:
        # Initialize the count array with zeros
        count = [0] * 10
        # Count the occurrences of each digit
        for num in numbers:
            digit = (num // exp) % 10
            count[digit] += 1
        # Calculate the cumulative count
        for i in range(1, 10):
            count[i] += count[i - 1]
        # Build the output array
        output = [0] * len(numbers)
        for i in range(len(numbers) - 1, -1, -1):
            digit = (numbers[i] // exp) % 10
            output[count[digit] - 1] = numbers[i]
            count[digit] -= 1
