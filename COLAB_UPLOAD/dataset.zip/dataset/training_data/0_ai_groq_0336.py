class Node:
    """
    A class representing a node in the AVL tree.
    """
    def __init__(self, value: any):
        """
        Initializes a new node with the given value.
        """
        self.value = value
        self.left = None
        self.right = None
        self.height = 1
class AVLTree:
    """
    A class representing an AVL tree, a self-balancing binary search tree.
    """
    def __init__(self):
        """
        Initializes an empty AVL tree.
        """
        self.root = None
    def insert(self, value: any):
        """
        Inserts a new value into the tree, maintaining balance.
        """