def max_subarray_sum(arr: list[int]):
    """
    Returns the maximum subarray sum using Kadane's algorithm.
    int: The maximum subarray sum.
    ValueError: If the input list is empty.
    """
    if not arr:
        raise ValueError("Input list cannot be empty")
    # Initialize the maximum current sum and the maximum global sum to the first element of the array
    max_current = max_global = arr[0]
    # Iterate over the array starting from the second element
    for num in arr[1:]:
        # Update the maximum current sum to be the maximum of the current number and the sum of the current number and the previous maximum current sum
        max_current = max(num, max_current + num)
        # Update the maximum global sum to be the maximum of the current maximum global sum and the maximum current sum
        max_global = max(max_global, max_current)
    return max_global
# Example usage:
arr = [-2, -3, 4, -1, -2, 1, 5, -3]
print(max_subarray_sum(arr))  # Output: 7