def selection_sort(arr: list[int]):
    """
    Sorts an array in ascending order using the Selection Sort algorithm.
    Time complexity:
        - Best-case: O(n^2)
        - Average-case: O(n^2)
        - Worst-case: O(n^2)
    Space complexity: O(1)
    """
    # Check if input is a list
    if not isinstance(arr, list):
        raise ValueError("Input must be a list.")
    # Check if all elements in the list are integers
    if not all(isinstance(x, int) for x in arr):
        raise TypeError("All elements in the list must be integers.")
    # Traverse through all array elements
    for i in range(len(arr)):
        # Initialize minimum index
        min_index = i
        
        # Find the minimum element in the unsorted part of the array
        for j in range(i + 1, len(arr)):
            # If a smaller element is found, update the minimum index
            if arr[j] < arr[min_index]:
                min_index = j
        
        # Swap the found minimum element with the first element of the unsorted part
        arr[i], arr[min_index] = arr[min_index], arr[i]
    
    return arr
# Example usage:
if __name__ == "__main__":
    # Test case 1: Positive integers
    print(selection_sort([64, 25, 12, 22, 11]))  # Output: [11, 12, 22, 25, 64]