def ternary_search(unimodal_function: callable, low: float, high: float, tolerance: float = 1e-5, max_iterations: int = 100):
    """
    Performs Ternary Search to find the maximum or minimum of a unimodal function.
    - unimodal_function (callable): The unimodal function to search.
    - low (float): The lower bound of the search interval.
    - high (float): The upper bound of the search interval.
    - tolerance (float, optional): The tolerance for convergence. Defaults to 1e-5.
    - max_iterations (int, optional): The maximum number of iterations. Defaults to 100.
    - float: The point where the function is maximum or minimum.
    - ValueError: If the search interval is invalid.
    - RuntimeError: If the maximum number of iterations is reached without convergence.
    """
    # Check if the search interval is valid
    if low >= high:
        raise ValueError("Invalid search interval")
    # Initialize the iteration counter
    iteration = 0
    while iteration < max_iterations:
        # Calculate the two midpoints
        mid1 = low + (high - low) / 3
        mid2 = high - (high - low) / 3
        # Evaluate the function at the midpoints
        f_mid1 = unimodal_function(mid1)
        f_mid2 = unimodal_function(mid2)
        # Check if the function is increasing or decreasing
        if f_mid1 < f_mid2:
            # If the function is increasing, move the left boundary
            low = mid1
        else:
            # If the function is decreasing, move the right boundary
            high = mid2
