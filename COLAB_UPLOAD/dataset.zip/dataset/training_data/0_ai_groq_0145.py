class Stack:
    """
    A Stack class implemented using a list.
    This class provides methods to push, pop, and peek elements from the stack.
    It also includes methods to check if the stack is empty and to get the size of the stack.
    """
    def __init__(self):
        """
        Initializes an empty stack.
        """
        self.stack: list = []
    def push(self, value: any):
        """
        Adds an element to the top of the stack.
        """
        self.stack.append(value)
    def pop(self):
        """
        Removes and returns the top element from the stack.
        """
        if self.is_empty():
            raise IndexError("Cannot pop from an empty stack")
        return self.stack.pop()
    def peek(self):
        """
        Returns the top element from the stack without removing it.
        """
        if self.is_empty():
            raise IndexError("Cannot peek from an empty stack")
        return self.stack[-1]
    def is_empty(self):