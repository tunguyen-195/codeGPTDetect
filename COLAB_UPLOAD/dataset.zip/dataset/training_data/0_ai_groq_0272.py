def interpolation_search(arr: list[int], x: int):
    """
    Interpolation Search for uniformly distributed data.
    int: The index of the target value if found, -1 otherwise.
    TypeError: If the input list is not a list of integers.
    ValueError: If the target value is not an integer.
    """
    # Check if the input list is a list of integers
    if not isinstance(arr, list) or not all(isinstance(i, int) for i in arr):
        raise TypeError("Input list must be a list of integers.")
    # Check if the target value is an integer
    if not isinstance(x, int):
        raise ValueError("Target value must be an integer.")
    # Calculate the low and high indices for the search
    low = 0
    high = len(arr) - 1
    # Continue the search until the low index is less than or equal to the high index
    while low <= high and x >= arr[low] and x <= arr[high]:
        # Calculate the index to check using interpolation
        index = low + ((x - arr[low]) * (high - low)) // (arr[high] - arr[low])
        # If the target value is found, return the index
        if arr[index] == x:
            return index
        # If the target value is less than the value at the calculated index, update the high index
        if arr[index] > x:
            high = index - 1
        # If the target value is greater than the value at the calculated index, update the low index
        else: