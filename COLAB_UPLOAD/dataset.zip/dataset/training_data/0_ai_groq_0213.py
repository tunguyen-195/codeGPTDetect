def find_duplicate(nums: list[int]):
    """
    Finds a duplicate number in the given array.
    This function uses Floyd's Tortoise and Hare (Cycle Detection) algorithm to find a duplicate number in the array.
    The algorithm works by treating the array as a linked list where each number is a node and the value of the node is the index of the next node.
    The function then detects a cycle in the linked list, which represents a duplicate number.
    """
    # Phase 1: Detecting the cycle using tortoise and hare algorithm
    tortoise = nums[0]
    hare = nums[0]
    while True:
        # Move the tortoise one step at a time
        tortoise = nums[tortoise]
        # Move the hare two steps at a time
        hare = nums[nums[hare]]
        # If the tortoise and hare meet, there is a cycle
        if tortoise == hare:
            break
    # Phase 2: Finding the start of the cycle
    tortoise = nums[0]
    while tortoise != hare:
        # Move both the tortoise and hare one step at a time
        tortoise = nums[tortoise]
        hare = nums[hare]
    return hare
# Example usage
if __name__ == "__main__":
    nums = [1, 3, 4, 2, 2]
    print(find_duplicate(nums))  # Output: 2
    nums = [3, 1, 3, 4, 2]
    print(find_duplicate(nums))  # Output: 3
    nums = [1, 2, 3, 4, 5]
    try: