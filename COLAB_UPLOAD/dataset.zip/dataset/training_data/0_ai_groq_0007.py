class Node:
    """
    A class representing a node in the doubly linked list.
    """
    def __init__(self, data: any):
        """
        Initializes a new node with the given data.
        """
        self.data = data
        self.next = None
        self.prev = None
class DoublyLinkedList:
    """
    A class representing a doubly linked list.
    """
    def __init__(self):
        """
        Initializes an empty doubly linked list.
        """
        self.head = None
        self.tail = None
        self.size = 0
    def __len__(self):
        """
        Returns the number of nodes in the list.
        """
        return self.size
    def __str__(self):
        """
        Returns a string representation of the list.
