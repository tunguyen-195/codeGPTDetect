def generate_subsets(s: list):
    """
    This function generates all subsets (power set) of a given set.
    
    
    list: A list of lists, where each sublist is a subset of the input set.
    """
    # Base case: if the set is empty, return a list containing an empty set
    if not s:
        return [[]]
    
    # Recursive case: get the subsets of the set without the first element
    subsets_without_first = generate_subsets(s[1:])
    
    # For each subset without the first element, create a new subset with the first element
    subsets_with_first = [[s[0]] + subset for subset in subsets_without_first]
    
    # Combine the subsets with and without the first element
    return subsets_without_first + subsets_with_first
def main():
    try:
        # Example usage
        input_set = [1, 2, 3]
        subsets = generate_subsets(input_set)
        print("Subsets of", input_set, "are:")
        for i, subset in enumerate(subsets):
            print(f"Subset {i+1}: {subset}")
    except Exception as e:
        print("An error occurred:", str(e))
if __name__ == "__main__":
    main()