import heapq
class Graph:
    """
    A class representing a graph with nodes and edges.
    """
    def __init__(self):
        """
        Initialize an empty graph.
        """
        self.nodes = set()
        self.edges = {}
    def add_node(self, node):
        """
        Add a node to the graph.
        """
        self.nodes.add(node)
        if node not in self.edges:
            self.edges[node] = {}
    def add_edge(self, node1, node2, weight):
        """
        Add an edge between two nodes in the graph.
        """
        if node1 in self.nodes and node2 in self.nodes:
            self.edges[node1][node2] = weight
            self.edges[node2][node1] = weight  # For undirected graph
        else:
            raise ValueError("Both nodes must be in the graph")
    def dijkstra(self, start_node):
        """
        Find the shortest path from the start node to all other nodes in the graph.
        """
        if start_node not in self.nodes: