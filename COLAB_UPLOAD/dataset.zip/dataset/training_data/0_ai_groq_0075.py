from typing import List, Tuple
def find_pairs_with_sum(numbers: List[int], target: int):
    """
    Find all pairs of numbers in the list that sum to the target.
    - numbers: A list of integers.
    - target: The target sum.
    - A list of tuples, where each tuple contains a pair of numbers that sum to the target.
    - ValueError: If the input list is empty or the target is not a number.
    """
    # Check if the input list is empty
    if not numbers:
        raise ValueError("Input list is empty")
    # Check if the target is a number
    if not isinstance(target, (int, float)):
        raise ValueError("Target must be a number")
    # Create an empty set to store the numbers we have seen so far
    seen = set()
    # Create an empty set to store the pairs that sum to the target
    pairs = set()
    # Iterate over the list of numbers
    for num in numbers:
        # Calculate the complement of the current number with respect to the target
        complement = target - num
        # Check if the complement is in the set of seen numbers
        if complement in seen:
            # If the complement is in the set of seen numbers, add the pair to the set of pairs
            # We use a tuple to store the pair, and we sort the numbers in the tuple to avoid duplicates
            pairs.add(tuple(sorted((num, complement))))
        # Add the current number to the set of seen numbers