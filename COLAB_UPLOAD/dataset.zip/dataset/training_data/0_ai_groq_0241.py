class Node:
    """Represents a node in the linked list."""
    
    def __init__(self, value: any):
        """
        Initializes a new node with the given value.
        
        value: The value to store in the node.
        """
        self.value = value
        self.next = None
class SinglyLinkedList:
    """Represents a singly linked list."""
    
    def __init__(self):
        """Initializes an empty linked list."""
        self.head = None
        self.tail = None
        self.size = 0
    def add(self, value: any):
        """
        Adds a new node with the given value to the end of the linked list.
        
        value: The value to add to the linked list.
        
        TypeError: If the value is not a valid type for the linked list.
        """
        if not isinstance(value, (int, str, float, list, dict, tuple)):
            raise TypeError("Invalid value type")
        
        node = Node(value)
        
        if not self.head:
            self.head = node
            self.tail = node
        else:
            self.tail.next = node
            self.tail = node