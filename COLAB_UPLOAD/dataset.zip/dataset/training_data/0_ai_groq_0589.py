class Fibonacci:
    """
    A class to calculate Fibonacci numbers using memoization.
    Time complexity: O(n) due to the single pass through the Fibonacci sequence.
    Space complexity: O(n) for storing the Fibonacci numbers in the memoization dictionary.
    """
    def __init__(self, max_n: int = 100):
        """
        Initializes the Fibonacci class with a maximum value of n.
        """
        self.max_n = max_n
        self.memo = {0: 0, 1: 1}
    def calculate(self, n: int):
        """
        Calculates the nth Fibonacci number using memoization.
        int: The nth Fibonacci number.
        ValueError: If n is less than 0 or greater than max_n.
        """
        if n < 0 or n > self.max_n:
            raise ValueError("n must be between 0 and max_n")
        if n not in self.memo:
            # Calculate the nth Fibonacci number using the previous two numbers
            self.memo[n] = self.calculate(n - 1) + self.calculate(n - 2)
        return self.memo[n]
    def calculate_sequence(self, n: int):
        """
        Calculates the first n Fibonacci numbers using memoization.
