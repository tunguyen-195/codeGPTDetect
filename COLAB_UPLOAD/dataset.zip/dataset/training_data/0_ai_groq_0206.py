def is_valid_parentheses(s: str):
    """
    Checks if a string of parentheses is valid.
    A string of parentheses is valid if every opening parenthesis has a corresponding
    closing parenthesis, and the closing parentheses are in the correct order.
    """
    if not isinstance(s, str):
        raise TypeError("Input must be a string")
    # Create a stack to store the opening parentheses
    stack: list[str] = []
    # Create a dictionary to map closing parentheses to their corresponding opening ones
    parentheses_map: dict[str, str] = {
        ")": "(",
        "]": "[",
        "}": "{"
    }
    # Iterate over each character in the string
    for char in s:
        # If the character is an opening parenthesis, push it onto the stack
        if char in parentheses_map.values():
            stack.append(char)
        # If the character is a closing parenthesis, check if the stack is empty or the top of the stack
        # does not match the current closing parenthesis
        elif char in parentheses_map.keys():
            if not stack or stack.pop() != parentheses_map[char]:
                return False
    # If the stack is empty after iterating over the entire string, the string is valid
    # Otherwise, there are unmatched opening parentheses, so the string is invalid
    return not stack