import heapq
class Graph:
    """
    A weighted graph represented as an adjacency list.
    """
    def __init__(self):
        """
        Initialize an empty graph.
        """
        self.adjacency_list = {}
    def add_node(self, node):
        """
        Add a node to the graph.
        """
        if node not in self.adjacency_list:
            self.adjacency_list[node] = {}
    def add_edge(self, node1, node2, weight):
        """
        Add an edge between two nodes with a given weight.
        """
        if node1 in self.adjacency_list and node2 in self.adjacency_list:
            self.adjacency_list[node1][node2] = weight
            self.adjacency_list[node2][node1] = weight  # Assuming the graph is undirected
    def dijkstra(self, start_node):
        """
        Find the shortest path from the start node to all other nodes in the graph.
        """
        if start_node not in self.adjacency_list:
            raise ValueError("Start node not in graph")
        # Initialize distances and previous nodes
        distances = {node: float('inf') for node in self.adjacency_list}