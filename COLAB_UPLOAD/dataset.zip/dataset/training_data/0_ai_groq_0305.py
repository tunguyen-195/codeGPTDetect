def find_all_substrings(input_string: str):
    """
    Finds all substrings of a given input string.
    list[str]: A list of all substrings found in the input string.
    TypeError: If the input is not a string.
    """
    # Check if input is a string
    if not isinstance(input_string, str):
        raise TypeError("Input must be a string.")
    # Initialize an empty set to store unique substrings
    substrings = set()
    # Iterate over the string with two nested loops to generate all substrings
    for i in range(len(input_string)):
        for j in range(i + 1, len(input_string) + 1):
            # Extract the substring from the input string
            substring = input_string[i:j]
            # Add the substring to the set
            substrings.add(substring)
    # Convert the set to a list and return it
    return list(substrings)
def main():
    # Example usage:
    input_str = "abcde"
    print("Substrings of '{}' are:".format(input_str))
    print(find_all_substrings(input_str))
if __name__ == "__main__":
    main()