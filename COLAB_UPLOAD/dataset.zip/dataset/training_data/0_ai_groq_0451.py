class MaxHeap:
    """
    A MaxHeap data structure implementation.
    
    ----------
    heap : list
        The underlying list representing the max heap.
    
    Methods:
    -------
    insert(value: int) : None
        Inserts a value into the max heap while maintaining the heap property.
    heapify() : None
        Transforms a list into a max heap in-place.
    extract_max() -> int
        Removes and returns the maximum element from the max heap.
    get_max() -> int
        Returns the maximum element from the max heap without removing it.
    is_empty() -> bool
        Checks if the max heap is empty.
    size() -> int
        Returns the number of elements in the max heap.
    """
    def __init__(self):
        """
        Initializes an empty max heap.
        """
        self.heap = []
    def insert(self, value: int):
        """
        Inserts a value into the max heap while maintaining the heap property.
        
        ----
        value : int
            The value to be inserted into the max heap.
        
        ------
        TypeError