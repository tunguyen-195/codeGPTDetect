def max_subarray_sum(nums: list[int]):
    """
    Finds the maximum sum of a subarray within the given list of integers.
    """
    if not nums:
        raise ValueError("Input list cannot be empty")
    max_sum = float('-inf')  # Initialize max_sum as negative infinity
    current_sum = 0  # Initialize current_sum as 0
    for num in nums:
        # Update current_sum to be the maximum of the current number and the sum of current_sum and the current number
        current_sum = max(num, current_sum + num)
        
        # Update max_sum to be the maximum of max_sum and current_sum
        max_sum = max(max_sum, current_sum)
    return max_sum
# Example usage:
numbers = [-2, 1, -3, 4, -1, 2, 1, -5, 4]
print(max_subarray_sum(numbers))  # Output: 6
# Time complexity: O(n), where n is the number of elements in the input list.
# Space complexity: O(1), as we only use a constant amount of space to store the maximum sum and the current sum.