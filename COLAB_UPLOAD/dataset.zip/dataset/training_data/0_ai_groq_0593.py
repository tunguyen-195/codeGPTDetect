from typing import List
def partition(s: str):
    """
    Partition a string into all possible unique palindromic substrings.
    List[List[str]]: A list of lists where each sublist is a partition of the input string.
    """
    def is_palindrome(substring: str):
        """
        Check if a substring is a palindrome.
        bool: True if the substring is a palindrome, False otherwise.
        """
        return substring == substring[::-1]
    def dfs(start: int, path: List[str]):
        """
        Perform a depth-first search to find all possible partitions.
        """
        if start == len(s):
            result.append(path[:])  # Append a copy of the current path
            return
        for end in range(start, len(s)):
            substring = s[start:end + 1]
            if is_palindrome(substring):
                path.append(substring)  # Add the current palindrome to the path
                dfs(end + 1, path)  # Recursively search for the remaining substring
                path.pop()  # Backtrack by removing the last added palindrome
    result = []
    dfs(0, [])