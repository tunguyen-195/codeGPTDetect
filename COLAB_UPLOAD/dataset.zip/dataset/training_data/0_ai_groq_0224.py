def floyd_warshall(graph: list[list[int]]):
    """
    Compute the shortest path between all pairs of vertices in a weighted graph.
    graph: A 2D list representing the adjacency matrix of the graph.
    A 2D list where graph[i][j] represents the shortest distance from vertex i to vertex j.
    ValueError: If the input graph is not a square matrix or contains negative weights.
    """
    # Check if the input graph is a square matrix
    if not graph or not all(len(row) == len(graph) for row in graph):
        raise ValueError("The input graph must be a square matrix")
    # Get the number of vertices in the graph
    n = len(graph)
    # Initialize the distance matrix with the input graph
    distance_matrix = [[float('inf')] * n for _ in range(n)]
    for i in range(n):
        for j in range(n):
            distance_matrix[i][j] = graph[i][j]
    # Check for negative weights
    for i in range(n):
        for j in range(n):
            if graph[i][j] < 0:
                raise ValueError("The input graph contains negative weights")
    # Compute the shortest path between all pairs of vertices
    for k in range(n):
        for i in range(n):
            for j in range(n):
                # Update the distance matrix if a shorter path is found
                distance_matrix[i][j] = min(distance_matrix[i][j], distance_matrix[i][k] + distance_matrix[k][j])
    return distance_matrix
# Example usage: