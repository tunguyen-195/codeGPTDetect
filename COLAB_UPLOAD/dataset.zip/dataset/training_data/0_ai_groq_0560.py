import random
def quicksort(arr: list[int]):
    """
    Sorts an array in ascending order using the QuickSort algorithm with random pivot selection.
    Time complexity:
    - Best case: O(n log n)
    - Average case: O(n log n)
    - Worst case: O(n^2)
    Space complexity: O(log n) due to recursive call stack
    """
    if len(arr) <= 1:  # Base case: if array has 1 or 0 elements, it is already sorted
        return arr
    pivot_index = random.randint(0, len(arr) - 1)  # Randomly select a pivot index
    pivot = arr[pivot_index]  # Select the pivot element
    less_than_pivot = [x for x in arr if x < pivot]  # Elements less than the pivot
    equal_to_pivot = [x for x in arr if x == pivot]  # Elements equal to the pivot
    greater_than_pivot = [x for x in arr if x > pivot]  # Elements greater than the pivot
    return quicksort(less_than_pivot) + equal_to_pivot + quicksort(greater_than_pivot)  # Recursively sort the subarrays
def test_quicksort():
    import random
    import time
    # Generate a large random array
    arr = [random.randint(0, 1000) for _ in range(1000)]
    start_time = time.time()
    sorted_arr = quicksort(arr)
    end_time = time.time()
    print(f"Sorting time: {end_time - start_time} seconds")
    print(f"Sorted array: {sorted_arr[:10]}...")
    print(f"Is array sorted? {all(sorted_arr[i] <= sorted_arr[i+1] for i in range(len(sorted_arr)-1))}")
if __name__ == "__main__":
    test_quicksort()