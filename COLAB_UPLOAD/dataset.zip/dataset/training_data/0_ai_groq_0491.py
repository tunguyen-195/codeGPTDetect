def house_robber(nums: list[int]):
    """
    This function solves the House Robber problem using dynamic programming.
    
    The House Robber problem is a classic problem in dynamic programming where you are given a list of non-negative integers representing the amount of money you can get from each house in a street.
    
    You want to rob the houses in the street, but you cannot rob two adjacent houses.
    
    The function returns the maximum amount of money you can get from robbing the houses.
    
    Time complexity: O(n), where n is the number of houses.
    Space complexity: O(n), where n is the number of houses.
    """
    
    # Handle edge cases
    if not nums:
        return 0
    
    # If there is only one house, return the amount of money in that house
    if len(nums) == 1:
        return nums[0]
    
    # Initialize a list to store the maximum amount of money that can be gotten from the first i houses
    dp = [0] * len(nums)
    
    # The maximum amount of money that can be gotten from the first house is the amount of money in that house
    dp[0] = nums[0]
    
    # The maximum amount of money that can be gotten from the first two houses is the maximum of the amount of money in the first house and the amount of money in the second house
    dp[1] = max(nums[0], nums[1])
    
    # For each house from the third house to the last house
    for i in range(2, len(nums)):
        # The maximum amount of money that can be gotten from the first i houses is the maximum of the maximum amount of money that can be gotten from the first i-1 houses and the maximum amount of money that can be gotten from the first i-2 houses plus the amount of money in the current house
        dp[i] = max(dp[i-1], dp[i-2] + nums[i])
    
    # Return the maximum amount of money that can be gotten from all houses
    return dp[-1]
# Example usage: