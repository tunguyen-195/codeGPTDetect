class MinHeap:
    """
    A class to implement Min Heap data structure.
    """
    def __init__(self):
        """
        Initializes an empty Min Heap.
        """
        self.heap: list[int] = []
    def insert(self, value: int):
        """
        Inserts a new value into the Min Heap.
        TypeError: If the value is not an integer.
        """
        if not isinstance(value, int):
            raise TypeError("Value must be an integer.")
        # Add the value to the end of the heap list
        self.heap.append(value)
        # Call the _heapify_up method to maintain the heap property
        self._heapify_up(len(self.heap) - 1)
    def extract_min(self):
        """
        Removes and returns the minimum value from the Min Heap.
        int | None: The minimum value if the heap is not empty, otherwise None.
        """
        if not self.heap:
            return None
        # If the heap has only one element, remove and return it
        if len(self.heap) == 1:
            return self.heap.pop()
        # Store the minimum value (root of the heap)