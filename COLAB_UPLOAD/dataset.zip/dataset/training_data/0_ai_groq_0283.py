def longest_increasing_subsequence(nums: list[int]):
    """
    Returns the length of the longest increasing subsequence in the given list of numbers.
    Time Complexity:
        O(n^2), where n is the length of the input list.
    Space Complexity:
        O(n), where n is the length of the input list.
    """
    # Handle edge cases
    if not nums:
        return 0
    # Initialize a list to store the length of the LIS ending at each position
    dp: list[int] = [1] * len(nums)
    # Initialize the maximum length of LIS found so far
    max_length: int = 1
    # Iterate over the list to fill the dp table
    for i in range(1, len(nums)):
        # For each element, compare it with all previous elements
        for j in range(i):
            # If the current element is greater than the previous element, update the LIS length
            if nums[i] > nums[j]:
                dp[i] = max(dp[i], dp[j] + 1)
        # Update the maximum length of LIS found so far
        max_length = max(max_length, dp[i])
    # Return the maximum length of LIS found
    return max_length
def longest_increasing_subsequence_with_indices(nums: list[int]):
    """
    Returns the indices of the longest increasing subsequence in the given list of numbers.
    Time Complexity:
        O(n^2), where n is the length of the input list.