class HashMap:
    """
    A class representing a hash map with open addressing.
    """
    def __init__(self, size: int = 10):
        """
        Initializes the hash map with a specified size.
        ValueError: If the size is not a positive integer.
        """
        if not isinstance(size, int) or size <= 0:
            raise ValueError("Size must be a positive integer.")
        self.size = size
        self.table = [None] * size
    def _hash(self, key: str):
        """
        Calculates the hash value of a key.
        int: The hash value of the key.
        """
        return hash(key) % self.size
    def put(self, key: str, value: str):
        """
        Inserts a key-value pair into the hash map.
        ValueError: If the key already exists in the hash map.
        """