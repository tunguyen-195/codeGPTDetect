def two_sum(nums: list[int], target: int):
    """
    Returns the indices of the two numbers in the input list that add up to the target value.
    """
    # Create an empty dictionary to store the numbers we've seen so far and their indices
    num_dict: dict[int, int] = {}
    # Iterate over the list of numbers with their indices
    for i, num in enumerate(nums):
        # Calculate the complement of the current number with respect to the target
        complement = target - num
        # Check if the complement is already in the dictionary
        if complement in num_dict:
            # If it is, return the indices of the current number and its complement
            return (num_dict[complement], i)
        # If not, add the current number and its index to the dictionary
        num_dict[num] = i
    # If we've iterated over the entire list and haven't found a pair of numbers that add up to the target, raise an error
    raise ValueError("No pair of numbers found that add up to the target value")
# Example usage:
numbers = [2, 7, 11, 15]
target_sum = 9
print(two_sum(numbers, target_sum))  # Output: (0, 1)