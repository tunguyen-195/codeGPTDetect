def longest_palindrome_substring(s: str):
    """
    Finds the longest palindrome substring in a given string.
    str: The longest palindrome substring.
    ValueError: If the input string is empty.
    """
    # Edge case: If the string is empty, raise a ValueError
    if not s:
        raise ValueError("Input string cannot be empty")
    # Initialize variables to store the longest palindrome and its length
    longest_palindrome = ""
    max_length = 0
    # Iterate over the string
    for i in range(len(s)):
        # Consider odd-length palindromes
        for j in range(i + 1, len(s) + 1):
            # Extract the current substring
            substring = s[i:j]
            # Check if the substring is a palindrome and its length is greater than max_length
            if substring == substring[::-1] and len(substring) > max_length:
                # Update the longest palindrome and its length
                longest_palindrome = substring
                max_length = len(substring)
    # Return the longest palindrome
    return longest_palindrome