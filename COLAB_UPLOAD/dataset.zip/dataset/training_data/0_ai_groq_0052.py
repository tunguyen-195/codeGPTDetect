def matrix_chain_multiplication(dimensions: list[int]):
    """
    Solves the Matrix Chain Multiplication problem using dynamic programming.
                             the second element is the number of columns in the first matrix (which is the same as the number of rows in the second matrix), 
                             and so on.
    tuple[list[list[int]], list[list[int]]]: A tuple containing two 2D lists. The first list represents the minimum number of scalar multiplications 
                                             required to multiply the matrices, and the second list represents the optimal parenthesization.
    Time complexity: O(n^3), where n is the number of matrices.
    Space complexity: O(n^2), where n is the number of matrices.
    """
    # Get the number of matrices
    n = len(dimensions) - 1
    # Initialize a 2D list to store the minimum number of scalar multiplications
    min_multiplications = [[0] * n for _ in range(n)]
    # Initialize a 2D list to store the optimal parenthesization
    optimal_parenthesization = [[0] * n for _ in range(n)]
    # Fill the diagonal of the min_multiplications list with 0, since no multiplications are needed for a single matrix
    for i in range(n):
        min_multiplications[i][i] = 0
    # Fill the min_multiplications list in a bottom-up manner
    for chain_length in range(2, n + 1):
        for i in range(n - chain_length + 1):
            j = i + chain_length - 1
            min_multiplications[i][j] = float('inf')
            for k in range(i, j):
                # Calculate the cost of multiplying the matrices from i to k and from k + 1 to j
                cost = min_multiplications[i][k] + min_multiplications[k + 1][j] + dimensions[i] * dimensions[k + 1] * dimensions[j + 1]
                # Update the minimum number of scalar multiplications and the optimal parenthesization if a better solution is found
                if cost < min_multiplications[i][j]:
                    min_multiplications[i][j] = cost
                    optimal_parenthesization[i][j] = k