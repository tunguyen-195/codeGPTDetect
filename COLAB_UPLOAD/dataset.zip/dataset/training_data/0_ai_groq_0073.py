def max_subarray_sum(arr: list[int]):
    """
    This function calculates the maximum sum of a subarray within a given array.
    
    """
    if not arr:
        raise ValueError("Input array is empty")
    # Initialize the maximum current sum and the maximum global sum to the first element of the array
    max_current = max_global = arr[0]
    
    # Iterate through the array starting from the second element
    for num in arr[1:]:
        # Update the maximum current sum to be the maximum of the current number and the sum of the current number and the previous maximum current sum
        max_current = max(num, max_current + num)
        
        # Update the maximum global sum to be the maximum of the current maximum global sum and the maximum current sum
        max_global = max(max_global, max_current)
    
    return max_global
def main():
    # Example usage
    arr = [-2, 1, -3, 4, -1, 2, 1, -5, 4]
    print("Maximum subarray sum:", max_subarray_sum(arr))
if __name__ == "__main__":
    main()