def rotate_array(nums: list[int], k: int):
    """
    Rotate the input array to the right by k positions.
    This function uses the optimal time complexity approach of reversing the array,
    reversing the first k elements, and then reversing the rest of the array.
    """
    n = len(nums)
    k = k % n  # Handle cases where k is greater than n
    # Reverse the entire array
    nums.reverse()
    # Reverse the first k elements
    nums[:k] = nums[:k][::-1]
    # Reverse the rest of the array
    nums[k:] = nums[k:][::-1]
# Example usage:
if __name__ == "__main__":
    nums = [1, 2, 3, 4, 5, 6, 7]
    k = 3
    print("Original array:", nums)
    rotate_array(nums, k)
    print("Rotated array:", nums)