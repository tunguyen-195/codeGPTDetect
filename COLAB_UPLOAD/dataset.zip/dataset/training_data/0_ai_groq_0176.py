from typing import Dict, List, Optional
class Graph:
    """
    A simple graph class to represent a graph using an adjacency list.
    """
    def __init__(self):
        """
        Initializes an empty graph.
        """
        self.adjacency_list: Dict[str, List[str]] = {}
    def add_node(self, node: str):
        """
        Adds a new node to the graph if it does not already exist.
        """
        if node not in self.adjacency_list:
            self.adjacency_list[node] = []
    def add_edge(self, node1: str, node2: str):
        """
        Adds a new edge between two nodes in the graph.
        """
        if node1 not in self.adjacency_list or node2 not in self.adjacency_list:
            raise ValueError("Both nodes must exist in the graph before adding an edge.")
        self.adjacency_list[node1].append(node2)
        self.adjacency_list[node2].append(node1)
    def dfs(self, start_node: str):
        """
        Performs a depth-first search traversal of the graph starting from a given node.
        """
        if start_node not in self.adjacency_list:
            raise ValueError("Start node must exist in the graph.")
