from typing import Dict, List, Set
class Graph:
    """
    A directed graph data structure with methods to detect cycles.
    """
    def __init__(self):
        """
        Initialize an empty graph.
        """
        self.adjacency_list: Dict[int, List[int]] = {}
    def add_vertex(self, vertex: int):
        """
        Add a new vertex to the graph.
        """
        if vertex not in self.adjacency_list:
            self.adjacency_list[vertex] = []
    def add_edge(self, source: int, destination: int):
        """
        Add a directed edge from source to destination.
        """
        if source in self.adjacency_list and destination in self.adjacency_list:
            self.adjacency_list[source].append(destination)
        else:
            raise ValueError("Both source and destination must be vertices in the graph")
    def has_cycle(self):
        """
        Check if the graph contains a cycle.
        bool: True if the graph contains a cycle, False otherwise.
        """