from typing import Dict, List
from abc import ABC, abstractmethod
class Product:
    """
    Represents a product in the shopping cart.
    """
    def __init__(self, name: str, price: float, quantity: int = 1):
        """
        Initializes a Product object.
        """
        self.name = name
        self.price = price
        self.quantity = quantity
    def calculate_total(self):
        """
        Calculates the total cost of the product based on its price and quantity.
        """
        return self.price * self.quantity
class PaymentMethod(ABC):
    """
    Abstract base class for payment methods.
    """
    @abstractmethod
    def pay(self, amount: float):
        """
        Pays the specified amount using the payment method.
        """
        pass
class CreditCard(PaymentMethod):
    """