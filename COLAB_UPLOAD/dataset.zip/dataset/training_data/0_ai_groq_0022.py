class Node:
    """
    A node in the linked list of the hash table.
    """
    def __init__(self, key: any, value: any):
        """
        Initializes a new node with the given key and value.
        """
        self.key = key
        self.value = value
        self.next = None
class HashTable:
    """
    A hash table with separate chaining for collision resolution.
    """
    def __init__(self, size: int):
        """
        Initializes a new hash table with the given size.
        """
        self.size = size
        self.table = [None] * size
    def _hash_function(self, key: any):
        """
        Calculates the hash value of the given key.
        """
        return hash(key) % self.size
    def insert(self, key: any, value: any):
        """
        Inserts a new key-value pair into the hash table.
