class Node:
    """
    A simple Node class to represent a node in the linked list.
    
    """
    def __init__(self, value: any):
        """
        Initialize a new Node with a given value.
        
        """
        self.value = value
        self.next = None
class SinglyLinkedList:
    """
    A class to implement a singly linked list.
    
    """
    def __init__(self):
        """
        Initialize an empty linked list.
        """
        self.head = None
    def add(self, value: any):
        """
        Add a new node with the given value to the end of the linked list.
        
        
        TypeError: If the value is not of a type that can be stored in a Node.
        """
        if not isinstance(value, type(self.head.value)) if self.head else True:
            raise TypeError("Value must be of a type that can be stored in a Node")
        
        if not self.head: