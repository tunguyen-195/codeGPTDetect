from typing import Dict, List, Set
class Graph:
    """
    A class representing a graph data structure.
    """
    def __init__(self):
        """
        Initializes an empty graph.
        """
        self.adjacency_list: Dict[int, List[int]] = {}
    def add_vertex(self, vertex: int):
        """
        Adds a vertex to the graph.
        """
        if vertex not in self.adjacency_list:
            self.adjacency_list[vertex] = []
    def add_edge(self, vertex1: int, vertex2: int):
        """
        Adds an edge between two vertices in the graph.
        """
        if vertex1 in self.adjacency_list and vertex2 in self.adjacency_list:
            self.adjacency_list[vertex1].append(vertex2)
            self.adjacency_list[vertex2].append(vertex1)
    def dfs(self, start_vertex: int):
        """
        Performs a Depth-First Search (DFS) traversal of the graph.
        """
        if start_vertex not in self.adjacency_list:
            raise ValueError("Start vertex not in graph")
        # Create a set to keep track of visited vertices