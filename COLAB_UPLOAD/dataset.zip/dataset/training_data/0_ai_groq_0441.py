class Node:
    """Represents a single node in the Singly Linked List."""
    
    def __init__(self, data: any):
        """Initializes a new Node with the given data."""
        
        self.data = data  # The data stored in this node
        self.next = None  # The next node in the linked list
class SinglyLinkedList:
    """Represents a Singly Linked List."""
    
    def __init__(self):
        """Initializes an empty Singly Linked List."""
        
        self.head = None  # The first node in the linked list
    def add(self, data: any):
        """Adds a new node with the given data to the end of the linked list."""
        
        new_node = Node(data)
        
        if not self.head:
            # If the list is empty, set the new node as the head
            self.head = new_node
        else:
            current = self.head
            while current.next:
                # Traverse the list to find the last node
                current = current.next
            current.next = new_node
    def remove(self, data: any):
        """Removes the first occurrence of the node with the given data in the linked list."""
        
        if self.head is None:
            # If the list is empty, do nothing
            return
        
        if self.head.data == data: