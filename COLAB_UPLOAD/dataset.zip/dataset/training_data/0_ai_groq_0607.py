from typing import Dict
def longest_substring_without_repeating_chars(s: str):
    """
    Finds the longest substring without repeating characters in a given string.
    str: The longest substring without repeating characters.
    TypeError: If the input is not a string.
    """
    if not isinstance(s, str):
        raise TypeError("Input must be a string.")
    if not s:
        return ""
    char_index_map: Dict[str, int] = {}
    max_length = 0
    max_substring = ""
    window_start = 0
    for window_end in range(len(s)):
        # Check if the current character is already in the map
        if s[window_end] in char_index_map:
            # If it is, update the window start to be the maximum of the current window start and the index of the current character + 1
            window_start = max(window_start, char_index_map[s[window_end]] + 1)
        # Update the index of the current character in the map
        char_index_map[s[window_end]] = window_end
        # Update the maximum length and substring if the current window size is greater than the maximum length
        if window_end - window_start + 1 > max_length:
            max_length = window_end - window_start + 1
            max_substring = s[window_start:window_end + 1]
    return max_substring