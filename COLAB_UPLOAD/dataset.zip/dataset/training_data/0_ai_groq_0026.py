def merge_sort(arr: list):
    """
    Sorts the input list in-place using the MergeSort algorithm.
    Time complexity: O(n log n)
    Space complexity: O(n)
    :param arr: The input list to be sorted
    :return: None
    """
    _merge_sort_helper(arr, 0, len(arr) - 1)
def _merge_sort_helper(arr: list, low: int, high: int):
    """
    Recursively divides the input list into smaller sublists and merges them back in sorted order.
    :param arr: The input list to be sorted
    :param low: The starting index of the current sublist
    :param high: The ending index of the current sublist
    :return: None
    """
    if low < high:
        # Calculate the middle index to divide the sublist into two halves
        mid = (low + high) // 2
        # Recursively sort the left and right halves
        _merge_sort_helper(arr, low, mid)
        _merge_sort_helper(arr, mid + 1, high)
        # Merge the sorted left and right halves back into the original list
        _merge(arr, low, mid, high)
def _merge(arr: list, low: int, mid: int, high: int):
    """
    Merges two sorted sublists into a single sorted sublist.
    :param arr: The input list to be merged
    :param low: The starting index of the left sublist
    :param mid: The ending index of the left sublist
    :param high: The ending index of the right sublist