def interpolation_search(arr: list[int], target: int):
    """
    Interpolation search algorithm for uniformly distributed data.
    int: The index of the target value if found, -1 otherwise.
    ValueError: If the input list is empty.
    """
    # Check if the input list is empty
    if not arr:
        raise ValueError("Input list is empty")
    # Initialize the low and high pointers
    low = 0
    high = len(arr) - 1
    # Continue searching while the target value is within the range
    while low <= high and target >= arr[low] and target <= arr[high]:
        # Calculate the index using interpolation formula
        # The formula is derived from the fact that the values in the array are uniformly distributed
        index = low + ((target - arr[low]) * (high - low)) // (arr[high] - arr[low])
        # If the target value is found, return the index
        if arr[index] == target:
            return index
        # If the target value is less than the value at the calculated index, update the high pointer
        if arr[index] > target:
            high = index - 1
        # If the target value is greater than the value at the calculated index, update the low pointer
        else:
            low = index + 1
    # If the target value is not found, return -1
    return -1
