def fibonacci(n: int, memo: dict = {}):
    """
    Calculate the nth Fibonacci number using memoization.
    int: The nth Fibonacci number.
    Time Complexity: O(n)
    Space Complexity: O(n)
    """
    # Base case: If n is 0 or 1, return n directly
    if n <= 1:
        return n
    # Check if the Fibonacci number for n is already in the memo dictionary
    if n not in memo:
        # If not, calculate it recursively and store it in the memo dictionary
        memo[n] = fibonacci(n-1, memo) + fibonacci(n-2, memo)
    # Return the Fibonacci number for n from the memo dictionary
    return memo[n]
def fibonacci_sequence(n: int, memo: dict = {}):
    """
    Generate the first n Fibonacci numbers using memoization.
    list: A list of the first n Fibonacci numbers.
    Time Complexity: O(n)
    Space Complexity: O(n)
    """
    # Initialize the Fibonacci sequence with the first two numbers
    sequence = [0, 1]