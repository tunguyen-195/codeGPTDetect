def longest_increasing_subsequence(nums: list[int]):
    """
    Returns the length of the longest increasing subsequence in the given list of numbers.
    Time complexity: O(n^2)
    Space complexity: O(n)
    """
    if not nums:
        return 0
    n = len(nums)
    dp = [1] * n  # Initialize dp array with all ones
    for i in range(1, n):
        # For each element, compare it with all previous elements
        for j in range(i):
            if nums[i] > nums[j]:  # If current element is greater than previous element
                dp[i] = max(dp[i], dp[j] + 1)  # Update dp[i] to be the maximum of its current value and dp[j] + 1
        # Comment: The outer loop iterates over the list, while the inner loop compares the current element with all previous elements.
    return max(dp)  # Return the maximum value in the dp array
def longest_increasing_subsequence_optimized(nums: list[int]):
    """
    Returns the length of the longest increasing subsequence in the given list of numbers.
    Time complexity: O(n log n)
    Space complexity: O(n)
    """
    if not nums:
        return 0
    n = len(nums)
    dp = [[num] for num in nums]  # Initialize dp array with single-element lists
    for i in range(1, n):
        for j in range(i):
            if nums[i] > nums[j]:  # If current element is greater than previous element
                if len(dp[j]) + 1 > len(dp[i]):
                    dp[i] = dp[j] + [nums[i]]  # Update dp[i] to be the list obtained by appending the current element to dp[j]