def longest_common_prefix(strs: list[str]):
    """
    This function finds the longest common prefix among a list of strings.
    """
    if not isinstance(strs, list) or not all(isinstance(s, str) for s in strs):
        raise TypeError("Input must be a list of strings")
    # Handle edge case where the input list is empty
    if not strs:
        return ""
    # Sort the list of strings, this is because the common prefix will be the same
    # for all strings regardless of their order
    strs.sort()
    # Compare the first and last strings in the sorted list, the common prefix
    # will be a part of these two strings
    first_str, last_str = strs[0], strs[-1]
    # Initialize the common prefix as an empty string
    common_prefix = ""
    # Iterate over the characters in the first string
    for i in range(min(len(first_str), len(last_str))):
        # If the characters at the current position in both strings are the same,
        # add it to the common prefix
        if first_str[i] == last_str[i]:
            common_prefix += first_str[i]
        # If the characters are different, break the loop because the common
        # prefix cannot be longer than the current position
        else:
            break
    return common_prefix
# Example usage:
print(longest_common_prefix(["flower","flow","flight"]))  # Output: "fl"
print(longest_common_prefix(["dog","racecar","car"]))  # Output: ""
print(longest_common_prefix([""]))  # Output: ""