def product_except_self(nums: list[int]):
    """
    This function calculates the product of all numbers in the input list except for each number itself.
    
    """
    
    # Check if the input list is empty
    if not nums:
        raise ValueError("Input list cannot be empty")
    
    # Initialize the output list with 1's
    output = [1] * len(nums)
    
    # Calculate the running product from the left
    left_product = 1
    for i in range(len(nums)):
        # For each number, multiply the current output with the running product from the left
        output[i] *= left_product
        # Update the running product from the left
        left_product *= nums[i]
    
    # Calculate the running product from the right
    right_product = 1
    for i in range(len(nums) - 1, -1, -1):
        # For each number, multiply the current output with the running product from the right
        output[i] *= right_product
        # Update the running product from the right
        right_product *= nums[i]
    
    return output
# Example usage:
if __name__ == "__main__":
    nums = [1, 2, 3, 4]
    result = product_except_self(nums)
    print(result)  # Output: [24, 12, 8, 6]