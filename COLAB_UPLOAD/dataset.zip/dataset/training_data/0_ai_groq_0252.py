class BinaryHeap:
    """
    A binary heap data structure that supports both min and max operations.
    
    """
    def __init__(self, max_heap: bool = True):
        """
        Initializes a new instance of the BinaryHeap class.
        
        """
        self.heap = []
        self.max_heap = max_heap
    def _heapify_up(self, index: int):
        """
        Ensures the heap property is maintained by moving the element at the given index up the heap.
        
        """
        while index > 0:
            parent_index = (index - 1) // 2
            if self._compare(self.heap[parent_index], self.heap[index]):
                self._swap(parent_index, index)
                index = parent_index
            else:
                break
    def _heapify_down(self, index: int):
        """
        Ensures the heap property is maintained by moving the element at the given index down the heap.
        
        """
        while True:
            left_child_index = 2 * index + 1
            right_child_index = 2 * index + 2