def find_duplicate(nums: list[int]):
    """
    Find the duplicate number in an array.
    This function uses Floyd's Tortoise and Hare (Cycle Detection) algorithm
    to detect the duplicate number in the array. The algorithm assumes that
    there is a duplicate number in the array.
    """
    # Phase 1: Detecting the cycle using Floyd's Tortoise and Hare algorithm
    tortoise = nums[0]
    hare = nums[0]
    while True:
        tortoise = nums[tortoise]
        hare = nums[nums[hare]]
        if tortoise == hare:
            break
    # Phase 2: Finding the start of the cycle
    ptr1 = nums[0]
    ptr2 = tortoise
    while ptr1 != ptr2:
        ptr1 = nums[ptr1]
        ptr2 = nums[ptr2]
    return ptr1
# Example usage:
nums = [1, 3, 4, 2, 2]
print(find_duplicate(nums))  # Output: 2
nums = [1, 2, 3, 4, 5]
try:
    print(find_duplicate(nums))
except ValueError as e:
    print(e)  # Output: Array does not contain a duplicate number