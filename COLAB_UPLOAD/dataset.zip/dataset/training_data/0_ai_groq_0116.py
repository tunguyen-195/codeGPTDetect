def solve_n_queens(n: int):
    """
    Solves the N-Queens problem using a recursive backtracking approach.
    list[list[str]]: A list of all possible configurations, where each configuration is a list of strings representing the positions of the queens on the board.
    """
    def is_safe(board: list[int], row: int, col: int):
        """
        Checks if it is safe to place a queen at the given position on the board.
        bool: True if it is safe to place a queen at the given position, False otherwise.
        """
        # Check this row on left side
        for i in range(row):
            if board[i] == col or \
                board[i] - i == col - row or \
                board[i] + i == col + row:
                return False
        return True
    def solve_n_queens_helper(n: int, row: int, board: list[int], result: list[list[int]]):
        """
        A helper function to solve the N-Queens problem using recursion.
        """
        # Base case: If all queens are placed, add the configuration to the result
        if row == n:
            result.append(board[:])
            return