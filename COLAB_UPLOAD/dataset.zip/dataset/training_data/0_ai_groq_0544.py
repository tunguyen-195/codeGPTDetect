import random
class Node:
    """Represents a node in the Skip List."""
    
    def __init__(self, value: int, level: int):
        """
        Initializes a new node with the given value and level.
        """
        self.value = value
        self.next = [None] * level
class SkipList:
    """A Skip List data structure for efficient search operations."""
    
    def __init__(self, max_level: int = 16, p: float = 0.5):
        """
        Initializes a new Skip List with the given maximum level and probability.
        """
        self.max_level = max_level
        self.p = p
        self.header = Node(float('-inf'), max_level)
    def _random_level(self):
        """
        Generates a random level for a new node based on the probability.
        int: The random level.
        """
        level = 1
        while random.random() < self.p and level < self.max_level:
            level += 1
        return level
