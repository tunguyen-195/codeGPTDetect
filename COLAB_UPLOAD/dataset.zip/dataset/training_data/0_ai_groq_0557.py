class Node:
    """Node class to store key-value pairs in a linked list."""
    
    def __init__(self, key: int, value: str):
        """
        Initialize a Node with a key and a value.
        
        """
        self.key = key
        self.value = value
        self.next = None
class HashTable:
    """Hash Table class with separate chaining for collision resolution."""
    
    def __init__(self, size: int = 10):
        """
        Initialize a Hash Table with a given size.
        
        """
        self.size = size
        self.table = [None] * size
    def _hash_function(self, key: int):
        """
        Hash function to map a key to an index in the hash table.
        
        
        int: The index in the hash table.
        """
        return key % self.size
    def insert(self, key: int, value: str):
        """
        Insert a key-value pair into the hash table.
        