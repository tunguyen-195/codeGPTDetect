from collections import deque
class Queue:
    """
    A class to implement a queue using collections.deque.
    ----------
    _queue : collections.deque
        The underlying deque to store the queue elements.
    Methods:
    -------
    enqueue(element: any) -> None
        Add an element to the end of the queue.
    dequeue() -> any
        Remove an element from the front of the queue.
    is_empty() -> bool
        Check if the queue is empty.
    size() -> int
        Get the number of elements in the queue.
    """
    def __init__(self):
        """
        Initialize an empty queue.
        """
        self._queue = deque()
    def enqueue(self, element: any):
        """
        Add an element to the end of the queue.
        ----
        element: any
            The element to add to the queue.
        ------
        TypeError: If the element is not of type any.
        """
        try: