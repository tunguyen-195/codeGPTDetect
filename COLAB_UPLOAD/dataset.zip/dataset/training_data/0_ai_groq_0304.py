def compress_string(input_str: str):
    """
    Compresses a given string by replacing repeated characters with the character and the count of repetitions.
    """
    if not isinstance(input_str, str):
        raise TypeError("Input must be a string.")
    if len(input_str) == 0:
        return input_str
    compressed_str = ""
    count = 1
    for i in range(1, len(input_str)):
        if input_str[i] == input_str[i - 1]:
            count += 1
        else:
            compressed_str += input_str[i - 1] + str(count)
            count = 1
    # Handle the last character
    compressed_str += input_str[-1] + str(count)
    # Return the original string if it's shorter
    return input_str if len(compressed_str) >= len(input_str) else compressed_str