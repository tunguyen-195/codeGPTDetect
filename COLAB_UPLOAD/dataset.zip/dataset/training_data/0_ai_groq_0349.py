from typing import Any, TypeVar
T = TypeVar('T')
class Deque:
    """
    A double-ended queue implementation.
    This class provides methods for adding elements at both ends, removing elements from both ends,
    checking if the deque is empty, and getting the size of the deque.
    """
    def __init__(self):
        """
        Initializes an empty deque.
        """
        self._data: list[Any] = []
    def append(self, value: T):
        """
        Adds an element to the right end of the deque.
        """
        self._data.append(value)
    def appendleft(self, value: T):
        """
        Adds an element to the left end of the deque.
        """
        self._data.insert(0, value)
    def pop(self):
        """
        Removes and returns the element from the right end of the deque.
        """
        if not self.is_empty():
            return self._data.pop()
        else: