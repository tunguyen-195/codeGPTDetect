from datetime import datetime, timedelta
from typing import List, Dict
class Book:
    """
    Represents a book in the library.
    """
    def __init__(self, title: str, author: str, publication_year: int):
        """
        Initializes a Book object.
        """
        self.title = title
        self.author = author
        self.publication_year = publication_year
        self.is_available = True
    def borrow(self):
        """
        Marks the book as borrowed.
        ValueError: If the book is already borrowed.
        """
        if not self.is_available:
            raise ValueError("Book is already borrowed")
        self.is_available = False
    def return_book(self):
        """
        Marks the book as available.
