import random
def quicksort(arr: list):
    """
    Sorts an array in ascending order using the QuickSort algorithm with random pivot selection.
    Time complexity:
    - Best case: O(n log n)
    - Average case: O(n log n)
    - Worst case: O(n^2)
    Space complexity: O(n)
    :param arr: The input array to be sorted
    :return: The sorted array
    """
    if len(arr) <= 1:  # Base case: If the array has one or zero elements, it's already sorted
        return arr
    pivot_index = random.randint(0, len(arr) - 1)  # Select a random pivot index
    pivot = arr[pivot_index]  # Get the pivot element
    less_than_pivot = [x for x in arr if x < pivot]  # Elements less than the pivot
    equal_to_pivot = [x for x in arr if x == pivot]  # Elements equal to the pivot
    greater_than_pivot = [x for x in arr if x > pivot]  # Elements greater than the pivot
    return quicksort(less_than_pivot) + equal_to_pivot + quicksort(greater_than_pivot)  # Recursively sort and combine
def test_quicksort():
    # Test cases
    print("Test case 1: Sorted array")
    print(quicksort([1, 2, 3, 4, 5]))  # Expected output: [1, 2, 3, 4, 5]
    print("\nTest case 2: Reverse sorted array")
    print(quicksort([5, 4, 3, 2, 1]))  # Expected output: [1, 2, 3, 4, 5]
    print("\nTest case 3: Array with duplicates")
    print(quicksort([3, 3, 1, 2, 2, 2, 4]))  # Expected output: [1, 2, 2, 2, 2, 3, 3, 4]
    print("\nTest case 4: Empty array")
    print(quicksort([]))  # Expected output: []
    print("\nTest case 5: Single element array")