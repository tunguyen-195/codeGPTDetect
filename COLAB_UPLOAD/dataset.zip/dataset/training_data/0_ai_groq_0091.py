class Graph:
    """Represents a graph with vertices and edges."""
    def __init__(self, num_vertices: int):
        """
        Initializes a graph with a specified number of vertices.
        """
        self.num_vertices = num_vertices
        self.adj_list = [[] for _ in range(num_vertices)]
    def add_edge(self, vertex1: int, vertex2: int, weight: int):
        """
        Adds an edge to the graph.
        """
        self.adj_list[vertex1].append((vertex2, weight))
        self.adj_list[vertex2].append((vertex1, weight))
    def prim_mst(self):
        """
        Computes the minimum spanning tree using Prim's algorithm.
        list: A list of edges in the minimum spanning tree, where each edge is represented as a tuple of (vertex1, vertex2, weight).
        """
        visited = [False] * self.num_vertices
        weights = [float('inf')] * self.num_vertices
        parent = [-1] * self.num_vertices
        weights[0] = 0  # Start with vertex 0
        for _ in range(self.num_vertices):
            min_weight = float('inf')
            min_index = -1
            # Find the vertex with the minimum weight that has not been visited
            for vertex in range(self.num_vertices):