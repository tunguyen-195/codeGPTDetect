class WeightedGraph:
    """
    A class representing a weighted graph.
    
    ----------
    num_vertices : int
        The number of vertices in the graph.
    adjacency_list : dict
        A dictionary representing the adjacency list of the graph.
        
    Methods:
    -------
    add_vertex(vertex: int)
        Adds a new vertex to the graph.
    add_edge(vertex1: int, vertex2: int, weight: float)
        Adds a new edge between two vertices with a specified weight.
    get_neighbors(vertex: int) -> list
        Returns a list of neighboring vertices for a given vertex.
    get_edge_weight(vertex1: int, vertex2: int) -> float
        Returns the weight of the edge between two vertices.
    """
    def __init__(self):
        """
        Initializes an empty weighted graph.
        """
        self.num_vertices = 0
        self.adjacency_list = {}
    def add_vertex(self, vertex: int):
        """
        Adds a new vertex to the graph.
        
        
        ValueError: If the vertex ID is already in use.
        """
        if vertex in self.adjacency_list:
            raise ValueError("Vertex ID already in use")
        self.adjacency_list[vertex] = {}