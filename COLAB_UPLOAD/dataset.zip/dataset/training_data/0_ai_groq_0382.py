def longest_common_subsequence(str1: str, str2: str):
    """
    This function calculates the longest common subsequence (LCS) of two input strings using dynamic programming.
    str: The longest common subsequence of str1 and str2.
    Time Complexity: O(m*n), where m and n are the lengths of str1 and str2 respectively.
    Space Complexity: O(m*n), for the dynamic programming table.
    """
    # Initialize a 2D table to store the lengths of common subsequences
    dp: list[list[int]] = [[0] * (len(str2) + 1) for _ in range(len(str1) + 1)]
    # Iterate over both strings
    for i in range(1, len(str1) + 1):
        for j in range(1, len(str2) + 1):
            # If the current characters in both strings are the same, increase the length of the LCS
            if str1[i - 1] == str2[j - 1]:
                dp[i][j] = dp[i - 1][j - 1] + 1
            # Otherwise, the LCS is the maximum of the LCS without the current character in str1 or str2
            else:
                dp[i][j] = max(dp[i - 1][j], dp[i][j - 1])
    # Initialize an empty string to store the LCS
    lcs: str = ""
    # Initialize pointers to the last characters in both strings
    i, j = len(str1), len(str2)
    # Backtrack through the dynamic programming table to construct the LCS
    while i > 0 and j > 0:
        # If the current characters in both strings are the same, add the character to the LCS and move diagonally up-left
        if str1[i - 1] == str2[j - 1]:
            lcs = str1[i - 1] + lcs
            i -= 1
            j -= 1
        # Otherwise, move up or left depending on which has a larger LCS