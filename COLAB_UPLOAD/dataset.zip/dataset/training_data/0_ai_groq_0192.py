def max_subarray_sum(nums: list[int]):
    """
    This function finds the maximum sum of a subarray within a given list of numbers.
    int: The maximum sum of a subarray.
    ValueError: If the input list is empty.
    """
    # Check if the input list is empty
    if not nums:
        raise ValueError("Input list cannot be empty")
    # Initialize the maximum current sum and the maximum global sum to the first element of the list
    max_current = max_global = nums[0]
    # Iterate through the list starting from the second element
    for num in nums[1:]:
        # Update the maximum current sum to be the maximum of the current number and the sum of the current number and the previous maximum current sum
        max_current = max(num, max_current + num)
        
        # Update the maximum global sum to be the maximum of the current maximum global sum and the maximum current sum
        max_global = max(max_global, max_current)
    # Return the maximum global sum
    return max_global
# Example usage:
numbers = [-2, -3, 4, -1, -2, 1, 5, -3]
print(max_subarray_sum(numbers))  # Output: 7