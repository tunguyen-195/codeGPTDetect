def are_anagrams(str1: str, str2: str):
    """
    Checks if two input strings are anagrams of each other.
    """
    # Check if inputs are strings
    if not isinstance(str1, str) or not isinstance(str2, str):
        raise TypeError("Both inputs must be strings.")
    # Check if input strings have the same length
    if len(str1) != len(str2):
        raise ValueError("Input strings must have the same length.")
    # Convert both strings to lowercase and sort them
    # This is done to ignore case differences and to make the comparison easier
    str1_sorted = "".join(sorted(str1.lower()))
    str2_sorted = "".join(sorted(str2.lower()))
    # Compare the sorted strings
    # If they are equal, the original strings are anagrams
    return str1_sorted == str2_sorted
# Example usage
if __name__ == "__main__":
    try:
        print(are_anagrams("listen", "silent"))  # True
        print(are_anagrams("hello", "world"))  # False
        print(are_anagrams("Listen", "silent"))  # True (ignores case differences)
        print(are_anagrams("abc", "abcd"))  # Raises ValueError
        print(are_anagrams(123, "abc"))  # Raises TypeError
    except (ValueError, TypeError) as e:
        print(f"Error: {e}")