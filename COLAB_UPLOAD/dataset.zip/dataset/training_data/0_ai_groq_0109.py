from typing import List
from enum import Enum
from collections import deque
class Direction(Enum):
    """Enum representing the direction of the elevator."""
    UP = 1
    DOWN = 2
    IDLE = 3
class Request:
    """Class representing a request to the elevator system."""
    def __init__(self, source_floor: int, destination_floor: int):
        """
        Initialize a request.
        """
        self.source_floor = source_floor
        self.destination_floor = destination_floor
class Elevator:
    """Class representing an elevator in the elevator system."""
    def __init__(self, id: int, num_floors: int):
        """
        Initialize an elevator.
        """
        self.id = id
        self.current_floor = 1
        self.direction = Direction.IDLE
        self.requests = deque()
        self.num_floors = num_floors
    def add_request(self, request: Request):
        """
        Add a request to the elevator.