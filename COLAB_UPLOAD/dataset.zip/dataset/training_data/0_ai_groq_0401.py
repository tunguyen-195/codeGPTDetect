def are_anagrams(str1: str, str2: str):
    """
    Checks if two input strings are anagrams of each other.
    """
    # Check if both inputs are strings
    if not isinstance(str1, str) or not isinstance(str2, str):
        raise TypeError("Both inputs must be strings.")
    # Remove any whitespace from the strings
    str1 = str1.replace(" ", "").lower()
    str2 = str2.replace(" ", "").lower()
    # If the lengths of the strings are not equal, they cannot be anagrams
    if len(str1) != len(str2):
        return False
    # Sort the characters in each string and compare the results
    # If the sorted strings are equal, the original strings are anagrams
    return sorted(str1) == sorted(str2)
# Example usage:
print(are_anagrams("Listen", "Silent"))  # True
print(are_anagrams("Hello", "World"))  # False
print(are_anagrams("Tom Marvolo Riddle", "I am Lord Voldemort"))  # True