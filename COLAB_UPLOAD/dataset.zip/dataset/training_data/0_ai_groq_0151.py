class MaxHeap:
    """
    A class to implement a Max Heap data structure.
    """
    def __init__(self):
        """
        Initializes an empty Max Heap.
        """
        self.heap = []
    def insert(self, value: int):
        """
        Inserts a new element into the Max Heap.
        """
        self.heap.append(value)
        self._heapify_up(len(self.heap) - 1)
    def _heapify_up(self, index: int):
        """
        Heapifies the heap upwards from the given index.
        """
        parent_index = (index - 1) // 2
        if index <= 0:
            return
        elif self.heap[parent_index] < self.heap[index]:
            self.heap[parent_index], self.heap[index] = self.heap[index], self.heap[parent_index]
            self._heapify_up(parent_index)
    def _heapify_down(self, index: int):
        """
        Heapifies the heap downwards from the given index.
