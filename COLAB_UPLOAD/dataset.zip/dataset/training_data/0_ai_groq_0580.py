def knapsack(capacity: int, weights: list, values: list):
    """
    Solves the 0-1 Knapsack problem using dynamic programming.
    """
    if len(weights) != len(values):
        raise ValueError("Number of weights and values must match")
    # Create a 2D table to store the maximum value for each subproblem
    dp = [[0 for _ in range(capacity + 1)] for _ in range(len(weights) + 1)]
    # Fill the table in a bottom-up manner
    for i in range(1, len(weights) + 1):
        for w in range(1, capacity + 1):
            # If the current weight is greater than the current capacity, skip it
            if weights[i - 1] > w:
                dp[i][w] = dp[i - 1][w]
            else:
                # Choose the maximum value between including and excluding the current item
                dp[i][w] = max(dp[i - 1][w], values[i - 1] + dp[i - 1][w - weights[i - 1]])
    # The maximum value is stored in the bottom-right corner of the table
    return dp[-1][-1]
def main():
    capacity = 50
    weights = [10, 20, 30]
    values = [60, 100, 120]
    print(knapsack(capacity, weights, values))
if __name__ == "__main__":
    main()