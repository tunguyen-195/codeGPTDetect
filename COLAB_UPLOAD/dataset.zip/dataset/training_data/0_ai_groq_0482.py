def longest_common_subsequence(s1: str, s2: str):
    """
    Compute the longest common subsequence of two strings using dynamic programming.
    str: The longest common subsequence of s1 and s2.
    Time Complexity:
    O(m*n), where m and n are the lengths of s1 and s2 respectively.
    Space Complexity:
    O(m*n), for the 2D table used to store the lengths of common subsequences.
    """
    # Get the lengths of the two input strings
    m = len(s1)
    n = len(s2)
    # Create a 2D table to store the lengths of common subsequences
    dp = [[0] * (n + 1) for _ in range(m + 1)]
    # Fill the table using dynamic programming
    for i in range(1, m + 1):
        for j in range(1, n + 1):
            # If the current characters match, the length of the common subsequence
            # is one more than the length of the common subsequence without these characters
            if s1[i - 1] == s2[j - 1]:
                dp[i][j] = dp[i - 1][j - 1] + 1
            # If the current characters do not match, the length of the common
            # subsequence is the maximum of the lengths of the common subsequences
            # without the current character in either string
            else:
                dp[i][j] = max(dp[i - 1][j], dp[i][j - 1])
    # Reconstruct the longest common subsequence from the table
    lcs = []
    i, j = m, n
    while i > 0 and j > 0: