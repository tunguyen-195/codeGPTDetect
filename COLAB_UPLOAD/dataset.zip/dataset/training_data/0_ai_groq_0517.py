def product_except_self(nums: list[int]):
    """
    Compute the product of all numbers in the input list except for each number itself.
    """
    length = len(nums)
    output = [1] * length  # Initialize output with ones
    # Compute prefix products
    prefix_product = 1
    for i in range(length):
        output[i] *= prefix_product
        prefix_product *= nums[i]
    # Compute suffix products
    suffix_product = 1
    for i in range(length - 1, -1, -1):
        output[i] *= suffix_product
        suffix_product *= nums[i]
    return output