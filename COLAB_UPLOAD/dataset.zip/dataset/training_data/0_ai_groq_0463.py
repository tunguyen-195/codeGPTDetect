def bubble_sort(arr: list[int]):
    """
    Sorts an array in ascending order using the Bubble Sort algorithm with early termination.
    list[int]: The sorted list.
    Time Complexity:
    - Best case: O(n) when the input array is already sorted
    - Average case: O(n^2) when the input array is randomly ordered
    - Worst case: O(n^2) when the input array is sorted in reverse order
    Space Complexity: O(1) as it only uses a constant amount of additional space
    Bubble sort is a simple sorting algorithm that repeatedly steps through the list, compares adjacent elements and swaps them if they are in the wrong order. The pass through the list is repeated until the list is sorted.
    :raises TypeError: If the input is not a list or if the list contains non-integer values.
    """
    # Check if input is a list
    if not isinstance(arr, list):
        raise TypeError("Input must be a list")
    # Check if list contains integers
    if not all(isinstance(x, int) for x in arr):
        raise TypeError("List must contain only integers")
    # Get the length of the array
    n = len(arr)
    # Repeat the process until the array is sorted
    for i in range(n):
        # Initialize a flag to track if any swaps were made
        swapped = False
        # Iterate over the array from the first element to the (n-i-1)th element
        for j in range(n - i - 1):
            # If the current element is greater than the next element, swap them
            if arr[j] > arr[j + 1]: