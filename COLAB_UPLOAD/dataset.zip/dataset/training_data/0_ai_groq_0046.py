def unbounded_knapsack(capacity: int, weights: list[int], values: list[int]):
    """
    Solve the Unbounded Knapsack problem using dynamic programming.
    int: The maximum value that can be put in the knapsack.
    ValueError: If the capacity, weights, or values are invalid.
    """
    # Check if the input is valid
    if capacity < 0:
        raise ValueError("Capacity cannot be negative")
    if len(weights) != len(values):
        raise ValueError("Weights and values must have the same length")
    if any(weight < 0 for weight in weights) or any(value < 0 for value in values):
        raise ValueError("Weights and values cannot be negative")
    # Create a table to store the maximum value for each subproblem
    dp = [0] * (capacity + 1)
    # Fill the table using dynamic programming
    for i in range(1, capacity + 1):
        # For each item, consider including it in the knapsack if it does not exceed the capacity
        for j in range(len(weights)):
            if weights[j] <= i:
                # Update the maximum value for the current capacity
                dp[i] = max(dp[i], dp[i - weights[j]] + values[j])
    # The maximum value for the given capacity is stored in the last element of the table
    return dp[capacity]
# Example usage:
if __name__ == "__main__":
    capacity = 10
    weights = [5, 10, 2]
    values = [60, 100, 120]