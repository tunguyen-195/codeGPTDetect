from typing import List
def activity_selection(activities: List[tuple]):
    """
    Activity Selection problem solution using greedy approach.
    This function takes a list of activities where each activity is a tuple of (start_time, end_time, name).
    It returns a list of selected activities.
    The greedy approach is based on the fact that we should always choose the activity that ends earliest.
    :param activities: A list of activities where each activity is a tuple of (start_time, end_time, name)
    :return: A list of selected activities
    """
    if not activities:
        raise ValueError("Activities list is empty")
    # Sort the activities based on their end times
    activities.sort(key=lambda x: x[1])
    # Initialize the result list with the first activity
    result = [activities[0]]
    # Iterate over the rest of the activities
    for i in range(1, len(activities)):
        # If the current activity starts after the last selected activity ends, add it to the result
        if activities[i][0] >= result[-1][1]:
            result.append(activities[i])
    return result
# Example usage:
activities = [
    (1, 4, 'A'),
    (3, 5, 'B'),
    (0, 6, 'C'),
    (5, 7, 'D'),
    (3, 8, 'E'),
    (5, 9, 'F'),
    (6, 10, 'G'),