from typing import Dict, List, Tuple
def bellman_ford(graph: Dict[str, List[Tuple[str, int]]], start_node: str):
    """
    Bellman-Ford algorithm implementation to find the shortest path from a start node to all other nodes in a graph.
    graph: A dictionary representing the graph, where each key is a node and its corresponding value is a list of tuples.
           Each tuple contains a neighboring node and the weight of the edge between them.
    start_node: The node from which to start the search.
    A dictionary where the keys are the nodes in the graph and the values are the shortest distances from the start node.
    ValueError: If the graph contains a negative cycle.
    """
    # Initialize distances dictionary with infinite values for all nodes except the start node
    distances: Dict[str, int] = {node: float('inf') for node in graph}
    distances[start_node] = 0
    # Relax edges repeatedly
    for _ in range(len(graph) - 1):
        for node in graph:
            for neighbor, weight in graph[node]:
                # If the distance to the neighbor through the current node is less than the known distance, update it
                if distances[node] + weight < distances[neighbor]:
                    distances[neighbor] = distances[node] + weight
    # Check for negative-weight cycles
    for node in graph:
        for neighbor, weight in graph[node]:
            # If the distance to the neighbor through the current node is less than the known distance, a negative cycle exists
            if distances[node] + weight < distances[neighbor]:
                raise ValueError("Graph contains a negative cycle")
    return distances
def negative_cycle(graph: Dict[str, List[Tuple[str, int]]]):
    """
    Checks if a graph contains a negative cycle using Bellman-Ford algorithm.
