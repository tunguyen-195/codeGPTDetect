class HashMap:
    """
    A class to implement a Hash Map with open addressing.
    ----------
    size : int
        The size of the hash map.
    table : list
        The hash table where key-value pairs are stored.
    """
    def __init__(self, size: int = 10):
        """
        Initializes the hash map with a given size.
        ----
        """
        self.size = size
        self.table = [None] * size
    def _hash(self, key: str):
        """
        Hashes a key to an index in the table.
        ----
        -------
        int: The hashed index.
        """
        return hash(key) % self.size
    def put(self, key: str, value: any):
        """
        Inserts or updates a key-value pair in the hash map.
        ----
