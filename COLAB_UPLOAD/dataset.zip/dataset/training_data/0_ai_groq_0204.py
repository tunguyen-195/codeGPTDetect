def compress_string(input_str: str):
    """
    Compresses a string by replacing repeated characters with the character and its count.
    """
    if not input_str:
        raise ValueError("Input string cannot be empty")
    compressed = []
    count = 1
    # Iterate over the input string
    for i in range(1, len(input_str)):
        # If the current character is the same as the previous one, increment the count
        if input_str[i] == input_str[i - 1]:
            count += 1
        # If the current character is different from the previous one, append the previous character and its count to the compressed list
        else:
            compressed.append(input_str[i - 1] + str(count))
            count = 1
    # Append the last character and its count to the compressed list
    compressed.append(input_str[-1] + str(count))
    # Join the compressed list into a string
    compressed_str = ''.join(compressed)
    # If the compressed string is longer than the original string, return the original string
    if len(compressed_str) >= len(input_str):
        return input_str
    else:
        return compressed_str
# Example usage:
print(compress_string("aabbbcc"))  # Output: a2b3c2
print(compress_string("abcdef"))  # Output: a1b1c1d1e1f1
print(compress_string(""))  # Raises ValueError