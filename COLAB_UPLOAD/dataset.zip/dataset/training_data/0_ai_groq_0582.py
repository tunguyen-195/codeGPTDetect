def longest_common_subsequence(str1: str, str2: str):
    """
    This function calculates the longest common subsequence (LCS) of two input strings using dynamic programming.
    Time complexity: O(m * n), where m and n are the lengths of str1 and str2, respectively.
    Space complexity: O(m * n), for the 2D table used to store the LCS lengths.
    """
    # Initialize a 2D table to store the lengths of LCS for subproblems
    dp: list[list[int]] = [[0] * (len(str2) + 1) for _ in range(len(str1) + 1)]
    # Fill the table in a bottom-up manner
    for i in range(1, len(str1) + 1):
        for j in range(1, len(str2) + 1):
            # If the current characters in str1 and str2 are the same, increment the LCS length
            if str1[i - 1] == str2[j - 1]:
                dp[i][j] = dp[i - 1][j - 1] + 1
            # Otherwise, take the maximum LCS length from the top or left cell
            else:
                dp[i][j] = max(dp[i - 1][j], dp[i][j - 1])
    # Reconstruct the LCS from the table
    lcs: list[str] = []
    i, j = len(str1), len(str2)
    while i > 0 and j > 0:
        # If the current characters in str1 and str2 are the same, add it to the LCS and move diagonally
        if str1[i - 1] == str2[j - 1]:
            lcs.append(str1[i - 1])
            i -= 1
            j -= 1
        # Otherwise, move in the direction of the maximum LCS length
        elif dp[i - 1][j] > dp[i][j - 1]:
            i -= 1
        else:
            j -= 1
    # Return the LCS in the correct order
    return "".join(reversed(lcs))