class SegmentTree:
    """
    A class representing a segment tree data structure.
    """
    def __init__(self, arr: list):
        """
        Initializes the segment tree.
        """
        self.n = len(arr)
        self.arr = arr
        self.tree = [0] * (4 * self.n)
        self._build_tree(1, 0, self.n - 1)
    def _build_tree(self, node: int, start: int, end: int):
        """
        Recursively builds the segment tree.
        """
        if start == end:
            self.tree[node] = self.arr[start]
        else:
            mid = (start + end) // 2
            self._build_tree(2 * node, start, mid)
            self._build_tree(2 * node + 1, mid + 1, end)
            self.tree[node] = self._query(2 * node, 2 * node + 1)
    def _query(self, node: int, start: int, end: int, left: int, right: int):
        """
        Recursively queries the segment tree for the sum of a range.
        """
        if start > right or end < left:
            return 0
        if start >= left and end <= right:
            return self.tree[node]
        mid = (start + end) // 2
        return self._query(2 * node, start, mid, left, right) + self._query(2 * node + 1, mid + 1, end, left, right)