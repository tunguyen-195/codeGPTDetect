class Stack:
    """
    A class representing a Stack data structure implemented using a list.
    """
    def __init__(self):
        """
        Initializes an empty Stack.
        """
        self.items: list = []
    def push(self, item: any):
        """
        Adds an item to the top of the stack.
        """
        self.items.append(item)
    def pop(self):
        """
        Removes and returns the top item from the stack.
        """
        if not self.is_empty():
            return self.items.pop()
        else:
            raise IndexError("Cannot pop from an empty stack")
    def peek(self):
        """
        Returns the top item from the stack without removing it.
        """
        if not self.is_empty():
            return self.items[-1]
        else:
            raise IndexError("Cannot peek into an empty stack")
    def is_empty(self):