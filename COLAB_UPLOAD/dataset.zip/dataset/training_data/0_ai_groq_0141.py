class Node:
    """Node class representing each element in the linked list."""
    def __init__(self, data: int):
        """Initialize a node with given data."""
        self.data = data
        self.next = None
class SinglyLinkedList:
    """Singly Linked List class with add, remove, find, and reverse operations."""
    def __init__(self):
        """Initialize an empty linked list."""
        self.head = None
    def add(self, data: int):
        """Add a new node with given data at the end of the linked list."""
        new_node = Node(data)
        if self.head is None:
            self.head = new_node
        else:
            current = self.head
            while current.next:
                current = current.next
            current.next = new_node
    def remove(self, data: int):
        """Remove the first occurrence of a node with given data."""
        if self.head is None:
            return False
        if self.head.data == data:
            self.head = self.head.next
            return True
        current = self.head
        while current.next:
            if current.next.data == data:
                current.next = current.next.next
                return True
            current = current.next
        return False
    def find(self, data: int):