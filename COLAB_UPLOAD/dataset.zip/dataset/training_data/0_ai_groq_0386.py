def count_ways(coins: list[int], amount: int):
    """
    Calculate the number of ways to make a certain amount using given coins.
    int: The number of ways to make the target amount.
    ValueError: If the input coins are not a list of non-negative integers.
    ValueError: If the target amount is negative.
    """
    if not isinstance(coins, list) or not all(isinstance(coin, int) and coin >= 0 for coin in coins):
        raise ValueError("Coins must be a list of non-negative integers.")
    if amount < 0:
        raise ValueError("Target amount cannot be negative.")
    # Create a list to store the number of ways to make each amount from 0 to the target amount
    ways = [0] * (amount + 1)
    ways[0] = 1  # There is one way to make an amount of 0: use no coins
    # For each coin denomination
    for coin in coins:
        # For each amount from the coin denomination to the target amount
        for i in range(coin, amount + 1):
            # The number of ways to make the current amount is the sum of the number of ways to make the current amount without using the current coin and the number of ways to make the amount minus the current coin
            ways[i] += ways[i - coin]
    return ways[amount]
# Example usage
coins = [1, 2, 5]
amount = 5
print(f"Number of ways to make {amount} using {coins}: {count_ways(coins, amount)}")  # Output: 4