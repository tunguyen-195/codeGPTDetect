from typing import List, Tuple
def two_sum(nums: List[int], target: int):
    """
    Finds all pairs of elements in the input list that sum to the target value.
    Time Complexity:
        O(n) where n is the length of the input list.
    """
    num_set = set()
    pairs = set()
    for num in nums:
        complement = target - num
        if complement in num_set:
            # Sort the pair to ensure consistency in the output
            pair = tuple(sorted((num, complement)))
            pairs.add(pair)
        num_set.add(num)
    return list(pairs)
def two_sum_with_index(nums: List[int], target: int):
    """
    Finds all pairs of elements in the input list that sum to the target value, along with their indices.
    Time Complexity:
        O(n) where n is the length of the input list.
    """
    num_dict = {}
    pairs = []
    for i, num in enumerate(nums):
        complement = target - num
        if complement in num_dict:
            # Append the pair along with their indices and the sum
            pairs.append((num_dict[complement], i, num, i))
        num_dict[num] = i
    return pairs