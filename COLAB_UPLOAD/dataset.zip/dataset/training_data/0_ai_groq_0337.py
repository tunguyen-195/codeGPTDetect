class Node:
    """
    Represents a node in the Red-Black Tree.
    
    """
    def __init__(self, value: any, color: str = 'black', left: 'Node' = None, right: 'Node' = None, parent: 'Node' = None):
        self.value = value
        self.color = color
        self.left = left
        self.right = right
        self.parent = parent
class RedBlackTree:
    """
    Represents a Red-Black Tree.
    
    """
    def __init__(self):
        self.root = None
    def _is_red(self, node: 'Node'):
        """
        Checks if a node is red.
        
        
        bool: True if the node is red, False otherwise.
        """
        if node is None:
            return False
        return node.color == 'red'
