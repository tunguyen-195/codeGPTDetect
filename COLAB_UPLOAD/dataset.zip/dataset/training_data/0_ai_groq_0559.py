from collections import OrderedDict
class LRUCache:
    """
    A Least Recently Used (LRU) Cache implementation using OrderedDict.
    ----------
    capacity : int
        The maximum number of items the cache can hold.
    cache : OrderedDict
        The cache itself, where keys are item keys and values are item values.
    Methods:
    -------
    get(key: int) -> int or None
        Retrieves the value associated with the given key from the cache.
    put(key: int, value: int)
        Inserts or updates the value associated with the given key in the cache.
    """
    def __init__(self, capacity: int):
        """
        Initializes the LRU Cache with the given capacity.
        ----
        capacity : int
            The maximum number of items the cache can hold.
        """
        self.capacity = capacity
        self.cache = OrderedDict()
    def get(self, key: int):
        """
        Retrieves the value associated with the given key from the cache.
        ----
        key : int
            The key to look up in the cache.
        -------