from collections import deque
class Queue:
    """
    A class to implement a queue data structure using collections.deque.
    ----------
    queue : collections.deque
        The underlying deque to store the queue elements.
    Methods:
    -------
    enqueue(element: any)
        Adds an element to the end of the queue.
    dequeue()
        Removes an element from the front of the queue.
    is_empty()
        Checks if the queue is empty.
    size()
        Returns the number of elements in the queue.
    """
    def __init__(self):
        """
        Initializes an empty queue.
        """
        self.queue = deque()
    def enqueue(self, element: any):
        """
        Adds an element to the end of the queue.
        ----
        element: any
            The element to be added to the queue.
        ------
        TypeError: If the element is not of a hashable type.
        """
        try: