from collections import deque
from typing import Any, Optional
class Queue:
    """
    A class to implement Queue using collections.deque.
    """
    def __init__(self):
        """
        Initializes an empty queue.
        """
        self.queue = deque()
    def enqueue(self, item: Any):
        """
        Adds an item to the end of the queue.
        """
        self.queue.append(item)
    def dequeue(self):
        """
        Removes an item from the front of the queue.
        Optional[Any]: The item removed from the queue, or None if the queue is empty.
        """
        try:
            return self.queue.popleft()
        except IndexError:
            return None
    def is_empty(self):
        """
        Checks if the queue is empty.
        bool: True if the queue is empty, False otherwise.