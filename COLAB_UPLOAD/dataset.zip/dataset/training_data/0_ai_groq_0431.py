from typing import Dict, List
class Graph:
    """Represents a graph using an adjacency list."""
    
    def __init__(self, num_vertices: int):
        """Initializes the graph with the given number of vertices."""
        self.num_vertices = num_vertices
        self.adj_list: Dict[int, List[int]] = {i: [] for i in range(num_vertices)}
    def add_edge(self, u: int, v: int):
        """Adds an edge between vertices u and v."""
        if u >= 0 and u < self.num_vertices and v >= 0 and v < self.num_vertices:
            self.adj_list[u].append(v)
            self.adj_list[v].append(u)  # For undirected graph
        else:
            raise ValueError("Vertex indices are out of range.")
    def dfs(self, v: int, visited: List[bool], parent: List[int], low: List[int], disc: List[int], time: int, ap: List[bool]):
        """Performs a depth-first search from vertex v."""
        visited[v] = True
        disc[v] = time
        low[v] = time
        time += 1
        children = 0
        for u in self.adj_list[v]:
            if not visited[u]:
                parent[u] = v
                children += 1
                self.dfs(u, visited, parent, low, disc, time, ap)
                low[v] = min(low[v], low[u])
                if (parent[v] == -1 and children > 1) or (parent[v] != -1 and low[u] >= disc[v]):
                    ap[v] = True
            elif u != parent[v]:
                low[v] = min(low[v], disc[u])
