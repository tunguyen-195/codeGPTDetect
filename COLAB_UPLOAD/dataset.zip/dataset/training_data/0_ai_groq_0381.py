def unbounded_knapsack(capacity: int, weights: list, values: list):
    """
    Solves the Unbounded Knapsack problem using dynamic programming.
    - capacity (int): The maximum capacity of the knapsack.
    - weights (list): A list of weights for each item.
    - values (list): A list of values for each item.
    - int: The maximum value that can be put in a knapsack of capacity capacity.
    """
    # Initialize a list to store the maximum value for each capacity from 0 to capacity
    dp = [0] * (capacity + 1)
    # Iterate over each capacity from 1 to capacity
    for cap in range(1, capacity + 1):
        # Initialize the maximum value for the current capacity to 0
        max_val = 0
        # Iterate over each item
        for i in range(len(values)):
            # If the weight of the current item is less than or equal to the current capacity
            if weights[i] <= cap:
                # Update the maximum value for the current capacity
                max_val = max(max_val, values[i] + dp[cap - weights[i]])
        # Update the maximum value for the current capacity in the dp list
        dp[cap] = max_val
    # Return the maximum value for the capacity capacity
    return dp[capacity]
# Example usage:
if __name__ == "__main__":
    capacity = 10
    weights = [3, 4, 5, 2]
    values = [10, 20, 30, 40]
    max_value = unbounded_knapsack(capacity, weights, values)
    print(f"The maximum value that can be put in a knapsack of capacity {capacity} is: {max_value}")