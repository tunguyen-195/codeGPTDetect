from typing import List
class Interval:
    """Represents an interval with start and end points."""
    def __init__(self, start: int, end: int):
        """
        Initializes an Interval object.
        """
        self.start = start
        self.end = end
    def __repr__(self):
        """Returns a string representation of the interval."""
        return f"Interval({self.start}, {self.end})"
def merge_intervals(intervals: List[Interval]):
    """
    Merges overlapping intervals in the given list.
    """
    if not intervals:
        raise ValueError("Input list cannot be empty")
    # Sort the intervals by their start points
    intervals.sort(key=lambda x: x.start)
    merged_intervals = [intervals[0]]
    for current_interval in intervals[1:]:
        # Get the last merged interval
        last_merged_interval = merged_intervals[-1]
        # Check if the current interval overlaps with the last merged interval
        if current_interval.start <= last_merged_interval.end:
            # Merge the current interval with the last merged interval
            merged_intervals[-1] = Interval(last_merged_interval.start, max(last_merged_interval.end, current_interval.end))
        else:
            # Add the current interval to the list of merged intervals
            merged_intervals.append(current_interval)
