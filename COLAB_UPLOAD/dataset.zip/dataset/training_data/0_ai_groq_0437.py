class Node:
    """Represents a node in the Red-Black Tree."""
    
    def __init__(self, value: int, color: str = 'red', left: 'Node' = None, right: 'Node' = None, parent: 'Node' = None):
        """
        Initializes a new Node.
        """
        self.value = value
        self.color = color
        self.left = left
        self.right = right
        self.parent = parent
class RedBlackTree:
    """Represents a Red-Black Tree data structure."""
    
    def __init__(self):
        """Initializes a new Red-Black Tree."""
        self.NIL = Node(None, color='black')
        self.root = self.NIL
    def pre_order(self, node: Node):
        """
        Performs a pre-order traversal of the tree.
        """
        if node != self.NIL:
            print(f"({node.value}, {node.color})")
            self.pre_order(node.left)
            self.pre_order(node.right)
    def in_order(self, node: Node):
        """
        Performs an in-order traversal of the tree.
        """
        if node != self.NIL:
            self.in_order(node.left)
            print(f"({node.value}, {node.color})")