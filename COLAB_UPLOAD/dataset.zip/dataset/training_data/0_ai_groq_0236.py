class Node:
    """
    A node in the AVL tree.
    """
    def __init__(self, key: int, value: any):
        """
        Initialize a new node.
        """
        self.key = key
        self.value = value
        self.left = None
        self.right = None
        self.height = 1
class AVLTree:
    """
    An AVL tree with automatic balancing and rotation methods.
    """
    def __init__(self):
        """
        Initialize a new AVL tree.
        """
        self.root = None
    def insert(self, key: int, value: any):
        """
        Insert a new key-value pair into the tree.
        """
        self.root = self._insert(self.root, key, value)
    def _insert(self, node: Node, key: int, value: any):
        """
        Recursively insert a new key-value pair into the tree.
