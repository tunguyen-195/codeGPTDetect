import heapq
class Graph:
    """Represents a weighted graph with adjacency list representation."""
    def __init__(self):
        """Initializes an empty graph."""
        self.vertices = {}
    def add_vertex(self, vertex_id: int):
        """Adds a new vertex to the graph.
        """
        if vertex_id not in self.vertices:
            self.vertices[vertex_id] = {}
    def add_edge(self, vertex1: int, vertex2: int, weight: float):
        """Adds a new edge to the graph.
        """
        if vertex1 not in self.vertices or vertex2 not in self.vertices:
            raise ValueError("Both vertices must exist in the graph")
        self.vertices[vertex1][vertex2] = weight
        self.vertices[vertex2][vertex1] = weight  # Assuming undirected graph
    def dijkstra(self, start_vertex: int):
        """Finds the shortest path from the start vertex to all other vertices.
        """
        if start_vertex not in self.vertices:
            raise ValueError("Start vertex must exist in the graph")
        # Initialize distances and previous vertices in the shortest path
        distances = {vertex: float('inf') for vertex in self.vertices}
        previous_vertices = {vertex: None for vertex in self.vertices}
        # Set initial distance to start vertex as 0
        distances[start_vertex] = 0
        # Create a priority queue to store vertices to be processed