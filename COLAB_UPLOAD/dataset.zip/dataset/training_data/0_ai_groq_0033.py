from typing import List
def bucket_sort(data: List[float]):
    """
    Sorts a list of uniformly distributed floating point numbers using Bucket Sort.
    Time complexity:
    - Best-case: O(n + k) where n is the number of elements and k is the number of buckets.
    - Average-case: O(n + k) for uniformly distributed data.
    - Worst-case: O(n^2) when all elements end up in the same bucket.
    :param data: A list of uniformly distributed floating point numbers.
    :return: A sorted list of floating point numbers.
    """
    # Check if input list is empty
    if not data:
        return []
    # Calculate min and max values in the list
    min_value = min(data)
    max_value = max(data)
    # Calculate the range of the input
    range_value = (max_value - min_value) / len(data)
    # Handle edge case where all elements are the same
    if range_value == 0:
        return data
    # Create empty buckets
    buckets = [[] for _ in range(len(data))]
    # Insert elements into their respective buckets
    for num in data:
        # Calculate the index of the bucket where the element should be inserted
        index = int((num - min_value) / range_value)
        # Handle edge case where index is equal to the number of buckets
        if index == len(data):
            index -= 1
        buckets[index].append(num)