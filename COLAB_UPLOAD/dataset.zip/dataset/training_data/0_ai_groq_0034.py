def shell_sort(arr: list[int], gap_sequence: list[int]):
    """
    Sorts the input array using Shell Sort with a custom gap sequence.
    list[int]: The sorted array.
    Time Complexity:
    The time complexity of Shell Sort depends on the gap sequence used. 
    With a well-chosen gap sequence, Shell Sort can have a time complexity of O(n log n) in the best case. 
    However, in the worst case, it can be O(n^2).
    ValueError: If the input array is empty or the gap sequence is invalid.
    TypeError: If the input array or gap sequence is not a list.
    >>> shell_sort([5, 2, 8, 3, 1, 6, 4], [3, 1])
    [1, 2, 3, 4, 5, 6, 8]
    """
    # Check if input array is a list
    if not isinstance(arr, list):
        raise TypeError("Input array must be a list.")
    # Check if gap sequence is a list
    if not isinstance(gap_sequence, list):
        raise TypeError("Gap sequence must be a list.")
    # Check if input array is empty
    if len(arr) == 0:
        raise ValueError("Input array cannot be empty.")
    # Check if gap sequence is empty or contains non-integer values
    if len(gap_sequence) == 0 or not all(isinstance(gap, int) for gap in gap_sequence):
        raise ValueError("Gap sequence must be a non-empty list of integers.")
    # Check if gap sequence contains gaps greater than the length of the array
    if any(gap > len(arr) for gap in gap_sequence):
        raise ValueError("Gap sequence cannot contain gaps greater than the length of the array.")