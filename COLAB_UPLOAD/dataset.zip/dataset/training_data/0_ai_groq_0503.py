def longest_common_prefix(strs: list[str]):
    """
    Finds the longest common prefix among a list of strings.
    str: The longest common prefix.
    TypeError: If the input is not a list of strings.
    ValueError: If the input list is empty.
    """
    # Check if input is a list of strings
    if not isinstance(strs, list) or not all(isinstance(s, str) for s in strs):
        raise TypeError("Input must be a list of strings")
    # Check if input list is empty
    if not strs:
        raise ValueError("Input list cannot be empty")
    # Sort the list of strings to simplify the comparison process
    # The longest common prefix will be the same for all permutations of the input list
    strs.sort()
    # Compare the first and last strings in the sorted list
    # The longest common prefix cannot be longer than the shorter of these two strings
    first_str, last_str = strs[0], strs[-1]
    # Initialize the common prefix as an empty string
    common_prefix = ""
    # Iterate over the characters in the first string
    for i, char in enumerate(first_str):
        # If the character at the current position in the first string matches the character at the same position in the last string
        if i < len(last_str) and char == last_str[i]:
            # Add the character to the common prefix
            common_prefix += char
        else:
            # If the characters do not match, break out of the loop
            break