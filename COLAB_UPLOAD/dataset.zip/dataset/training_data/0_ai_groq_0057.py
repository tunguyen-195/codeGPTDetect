def max_subarray_sum(arr: list[int]):
    """
    This function calculates the maximum subarray sum using Kadane's algorithm.
    int: The maximum subarray sum.
    ValueError: If the input array is empty.
    """
    if not arr:
        raise ValueError("Input array is empty")
    # Initialize the maximum current sum and the maximum global sum to the first element of the array
    max_current = max_global = arr[0]
    # Iterate through the array starting from the second element
    for i in range(1, len(arr)):
        # Update the maximum current sum to be the maximum of the current element and the sum of the current element and the previous maximum current sum
        max_current = max(arr[i], max_current + arr[i])
        
        # Update the maximum global sum to be the maximum of the current maximum global sum and the maximum current sum
        max_global = max(max_global, max_current)
    return max_global
def main():
    # Example usage
    arr = [-2, 1, -3, 4, -1, 2, 1, -5, 4]
    print("Maximum subarray sum:", max_subarray_sum(arr))
if __name__ == "__main__":
    main()
# Time complexity analysis:
# The time complexity of this solution is O(n), where n is the number of elements in the array.
# This is because we are iterating through the array once.
# Space complexity analysis:
# The space complexity of this solution is O(1), which means the space required does not change with the size of the input array.