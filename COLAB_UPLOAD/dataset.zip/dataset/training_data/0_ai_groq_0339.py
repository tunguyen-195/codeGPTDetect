class TrieNode:
    """
    A node in the Trie data structure.
    
    """
    def __init__(self):
        self.children = {}
        self.is_end_of_word = False
class Trie:
    """
    A Trie data structure for autocomplete functionality.
    
    
    Methods:
    insert(word: str): Insert a word into the Trie.
    search(word: str): Search for a word in the Trie.
    starts_with(prefix: str): Find all words in the Trie that start with the given prefix.
    """
    def __init__(self):
        self.root = TrieNode()
    def insert(self, word: str):
        """
        Insert a word into the Trie.
        
        
        TypeError: If the input word is not a string.
        """
        if not isinstance(word, str):
            raise TypeError("Input word must be a string.")
        
        node = self.root
        for char in word: