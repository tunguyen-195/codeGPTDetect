from typing import List
def four_sum(nums: List[int], target: int):
    """
    This function solves the four sum problem in optimal time complexity.
    
    
    List[List[int]]: A list of lists, where each sublist contains four numbers that sum up to the target.
    """
    
    # First, sort the list of numbers
    nums.sort()
    
    # Initialize an empty list to store the result
    result = []
    
    # Iterate over the list with four nested loops
    for i in range(len(nums)):
        # Skip the same result
        if i > 0 and nums[i] == nums[i - 1]:
            continue
        
        for j in range(i + 1, len(nums)):
            # Skip the same result
            if j > i + 1 and nums[j] == nums[j - 1]:
                continue
            
            # Initialize two pointers
            left, right = j + 1, len(nums) - 1
            
            while left < right:
                # Calculate the current sum
                current_sum = nums[i] + nums[j] + nums[left] + nums[right]
                
                # If the current sum is equal to the target, add it to the result
                if current_sum == target:
                    result.append([nums[i], nums[j], nums[left], nums[right]])
                    