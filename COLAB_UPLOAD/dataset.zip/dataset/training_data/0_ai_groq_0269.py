def shell_sort(arr: list):
    """
    Sorts an array using the Shell Sort algorithm with a custom gap sequence.
    The time complexity of this implementation is O(n log n) in the best case and
    O(n^2) in the worst case, depending on the choice of the gap sequence.
    """
    if not isinstance(arr, list):
        raise TypeError("Input must be a list.")
    if len(arr) == 0:
        raise ValueError("Input list cannot be empty.")
    # Custom gap sequence: start with a large gap, then decrease the gap by half
    gaps = [int(len(arr) / 2), int(len(arr) / 4), int(len(arr) / 8)]
    # Insertion sort for each gap
    for gap in gaps:
        # Iterate through the array with the current gap
        for i in range(gap, len(arr)):
            # Store the current element
            temp = arr[i]
            j = i
            # Shift elements to the right until a smaller element is found
            while j >= gap and arr[j - gap] > temp:
                arr[j] = arr[j - gap]
                j -= gap
            # Insert the current element at the correct position
            arr[j] = temp
    return arr
# Example usage:
arr = [64, 34, 25, 12, 22, 11, 90]
print("Original array:", arr)
print("Sorted array:", shell_sort(arr))