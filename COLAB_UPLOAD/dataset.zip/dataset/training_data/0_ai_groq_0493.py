from typing import List
def partition(s: str):
    """
    Partition a string into all possible palindromic substrings.
    List[List[str]]: A list of lists, where each sublist contains a partition of the input string.
    Time complexity: O(n^3)
    Space complexity: O(n^2)
    """
    def is_palindrome(substring: str):
        """
        Check if a substring is a palindrome.
        bool: True if the substring is a palindrome, False otherwise.
        """
        return substring == substring[::-1]
    def dfs(index: int, path: List[str]):
        """
        Perform a depth-first search to find all possible partitions.
        """
        if index == len(s):
            result.append(path[:])
            return
        for i in range(index, len(s)):
            substring = s[index:i+1]
            if is_palindrome(substring):
                path.append(substring)
                dfs(i+1, path)
                path.pop()
