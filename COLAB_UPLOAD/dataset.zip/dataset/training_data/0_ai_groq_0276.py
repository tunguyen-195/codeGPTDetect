class Graph:
    """
    A class representing a graph data structure.
    """
    def __init__(self):
        """
        Initializes an empty graph with an adjacency list.
        """
        self.adjacency_list = {}
        self.num_vertices = 0
    def add_vertex(self, vertex: str):
        """
        Adds a vertex to the graph.
        """
        if vertex in self.adjacency_list:
            raise ValueError("Vertex already exists in the graph")
        self.adjacency_list[vertex] = []
        self.num_vertices += 1
    def add_edge(self, vertex1: str, vertex2: str):
        """
        Adds an edge between two vertices in the graph.
        """
        if vertex1 not in self.adjacency_list or vertex2 not in self.adjacency_list:
            raise ValueError("Both vertices must exist in the graph")
        self.adjacency_list[vertex1].append(vertex2)
        self.adjacency_list[vertex2].append(vertex1)
    def dfs(self, start_vertex: str):
        """
        Performs a depth-first search traversal of the graph starting from a given vertex.
        """
        if start_vertex not in self.adjacency_list:
            raise ValueError("Start vertex does not exist in the graph")