import heapq
from typing import Any, Tuple
class PriorityQueue:
    """
    A class to implement a Priority Queue using heapq.
    The priority queue is a data structure that allows elements to be inserted and removed based on their priority.
    The element with the highest priority is removed first.
    """
    def __init__(self):
        """
        Initializes an empty priority queue.
        """
        self.queue: list[Tuple[Any, Any]] = []
    def insert(self, priority: Any, element: Any):
        """
        Inserts an element into the priority queue with the given priority.
        """
        # Use heapq.heappush to maintain the heap property
        heapq.heappush(self.queue, (priority, element))
    def remove(self):
        """
        Removes and returns the element with the highest priority from the queue.
        Any: The element with the highest priority.
        IndexError: If the queue is empty.
        """
        # Check if the queue is empty
        if not self.queue:
            raise IndexError("Cannot remove from an empty queue")