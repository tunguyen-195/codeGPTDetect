def max_subarray_sum(nums: list[int]):
    """
    This function calculates the maximum sum of a subarray in a given list of integers.
    nums: A list of integers.
    An integer representing the maximum sum of a subarray.
    TypeError: If the input is not a list.
    ValueError: If the input list is empty.
    """
    # Check if input is a list
    if not isinstance(nums, list):
        raise TypeError("Input must be a list.")
    # Check if input list is not empty
    if len(nums) == 0:
        raise ValueError("Input list must not be empty.")
    # Initialize the maximum current sum and the maximum global sum to the first element of the list
    max_current = max_global = nums[0]
    # Iterate over the list starting from the second element
    for num in nums[1:]:
        # Update the maximum current sum to be the maximum of the current number and the sum of the current number and the previous maximum current sum
        max_current = max(num, max_current + num)
        
        # Update the maximum global sum to be the maximum of the current maximum global sum and the maximum current sum
        max_global = max(max_global, max_current)
    # Return the maximum global sum
    return max_global
# Example usage:
numbers = [-2, 1, -3, 4, -1, 2, 1, -5, 4]
print(max_subarray_sum(numbers))  # Output: 6