def exponential_search(arr: list[int], target: int):
    """
    Exponential search is a variant of binary search algorithm that finds the range in which the target element is present.
    int: The index of the target element if found, -1 otherwise.
    TypeError: If the input array is not a list or if the target is not an integer.
    """
    # Check if the input array is a list and the target is an integer
    if not isinstance(arr, list) or not isinstance(target, int):
        raise TypeError("Input array must be a list and target must be an integer.")
    # Check if the array is empty
    if len(arr) == 0:
        return -1
    # Find the range of the target element using exponential search
    i = 1
    while i < len(arr) and arr[i] <= target:
        # If the target element is greater than the current element, double the current index
        i *= 2
    # Perform binary search in the range [i/2, i] to find the target element
    return binary_search(arr, i // 2, min(i, len(arr) - 1), target)
def binary_search(arr: list[int], low: int, high: int, target: int):
    """
    Binary search algorithm to find the target element in a sorted array.
    int: The index of the target element if found, -1 otherwise.
