def coin_change_ways(coins: list[int], amount: int):
    """
    Calculate the number of ways to make change for a given amount using the provided coins.
    int: The number of ways to make change for the given amount.
    ValueError: If the amount or any coin denomination is negative.
    """
    # Check for invalid input
    if amount < 0 or any(coin < 0 for coin in coins):
        raise ValueError("Amount and coin denominations must be non-negative.")
    # Create a table to store the number of ways to make change for each amount from 0 to the target amount
    ways = [0] * (amount + 1)
    # Base case: there is one way to make change for 0 (use no coins)
    ways[0] = 1
    # For each coin denomination
    for coin in coins:
        # For each amount from the coin denomination to the target amount
        for i in range(coin, amount + 1):
            # The number of ways to make change for the current amount is the sum of the number of ways to make change
            # for the current amount without using the current coin and the number of ways to make change for the
            # amount minus the current coin (using the current coin)
            ways[i] += ways[i - coin]
    # Return the number of ways to make change for the target amount
    return ways[amount]
# Example usage:
if __name__ == "__main__":
    coins = [1, 2, 5]
    amount = 5
    print(f"Number of ways to make change for {amount} using coins {coins}: {coin_change_ways(coins, amount)}")
