def compute_prefix_function(pattern: str):
    """
    Compute the prefix function for the given pattern.
    
    The prefix function is used in the KMP algorithm to determine the shift value.
    It stores the length of the longest proper prefix that is also a suffix.
    
    
    list[int]: The prefix function values for the given pattern.
    """
    n = len(pattern)
    prefix = [0] * n
    j = 0
    
    for i in range(1, n):
        # If the current character in the pattern does not match the current character in the prefix,
        # we need to shift the prefix to the left until we find a match or we reach the start of the prefix.
        while j > 0 and pattern[i] != pattern[j]:
            j = prefix[j - 1]
        
        # If the current character in the pattern matches the current character in the prefix,
        # we can increment the length of the prefix.
        if pattern[i] == pattern[j]:
            j += 1
        
        # Store the length of the prefix at the current position.
        prefix[i] = j
    
    return prefix
def kmp_pattern_matching(text: str, pattern: str):
    """
    Find all occurrences of the pattern in the given text using the KMP algorithm.
    
    
    list[int]: The starting indices of all occurrences of the pattern in the text.
    """