class Node:
    """
    A class to represent a node in the circular linked list.
    ----------
    data : any
        The data stored in the node.
    next : Node
        The next node in the circular linked list.
    """
    def __init__(self, data: any):
        """
        Initializes a new node with the given data.
        ----
        data : any
            The data to be stored in the node.
        """
        self.data = data
        self.next = None
class CircularLinkedList:
    """
    A class to represent a circular linked list.
    ----------
    head : Node
        The head of the circular linked list.
    """
    def __init__(self):
        """
        Initializes an empty circular linked list.
        """
        self.head = None
    def append(self, data: any):
        """
        Appends a new node with the given data to the end of the circular linked list.