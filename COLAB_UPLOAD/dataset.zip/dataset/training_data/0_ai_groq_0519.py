def max_area(height: list[int]):
    """
    Calculate the maximum area of water that can be trapped between lines.
    int: The maximum area of water that can be trapped.
    Time complexity: O(n)
    Space complexity: O(1)
    """
    if not height:
        return 0
    left, right = 0, len(height) - 1
    max_area = 0
    while left < right:
        # Calculate the width of the current container
        width = right - left
        # Calculate the height of the current container
        current_height = min(height[left], height[right])
        # Calculate the area of the current container
        current_area = width * current_height
        # Update the maximum area if the current area is larger
        max_area = max(max_area, current_area)
        # Move the pointer of the shorter line towards the other pointer
        if height[left] < height[right]:
            left += 1
        else:
            right -= 1
    return max_area
# Example usage:
height = [1, 8, 6, 2, 5, 4, 8, 3, 7]