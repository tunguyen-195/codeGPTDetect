class Graph:
    """
    A class to represent a Graph using adjacency matrix.
    """
    def __init__(self, num_vertices: int):
        """
        Initializes a new instance of the Graph class.
        """
        if num_vertices < 1:
            raise ValueError("Number of vertices must be at least 1")
        self.num_vertices = num_vertices
        self.adjacency_matrix = [[0 for _ in range(num_vertices)] for _ in range(num_vertices)]
    def add_edge(self, vertex1: int, vertex2: int):
        """
        Adds an edge between two vertices in the graph.
        """
        if vertex1 < 0 or vertex1 >= self.num_vertices or vertex2 < 0 or vertex2 >= self.num_vertices:
            raise ValueError("Vertex out of range")
        if self.adjacency_matrix[vertex1][vertex2] == 1:
            raise ValueError("Edge already exists")
        self.adjacency_matrix[vertex1][vertex2] = 1
        self.adjacency_matrix[vertex2][vertex1] = 1  # For undirected graph
    def remove_edge(self, vertex1: int, vertex2: int):
        """
        Removes an edge between two vertices in the graph.
        """
        if vertex1 < 0 or vertex1 >= self.num_vertices or vertex2 < 0 or vertex2 >= self.num_vertices:
            raise ValueError("Vertex out of range")
        if self.adjacency_matrix[vertex1][vertex2] == 0: