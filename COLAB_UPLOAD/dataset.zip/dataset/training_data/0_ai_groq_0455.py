from typing import Dict, List, Set
class Node:
    """Represents a node in the graph."""
    
    def __init__(self, value: str):
        """
        Initializes a Node with a given value.
        
        """
        self.value = value
        self.adjacent_nodes: List['Node'] = []
class DirectedGraph:
    """Represents a directed graph."""
    
    def __init__(self):
        """Initializes an empty directed graph."""
        self.nodes: Dict[str, Node] = {}
        self.cycle_detected: bool = False
    def add_node(self, value: str):
        """
        Adds a new node to the graph.
        
        """
        if value not in self.nodes:
            self.nodes[value] = Node(value)
        else:
            raise ValueError(f"Node with value '{value}' already exists in the graph.")
    def add_edge(self, source: str, destination: str):
        """
        Adds a directed edge between two nodes in the graph.
        
        