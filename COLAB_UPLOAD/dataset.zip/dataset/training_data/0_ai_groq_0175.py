def ternary_search(unimodal_function: callable, left_bound: float, right_bound: float, tolerance: float = 1e-6):
    """
    Finds the maximum or minimum of a unimodal function using ternary search.
    """
    if left_bound > right_bound:
        raise ValueError("Left boundary cannot be greater than right boundary")
    while right_bound - left_bound > tolerance:
        # Calculate the two mid points
        mid1 = left_bound + (right_bound - left_bound) / 3
        mid2 = right_bound - (right_bound - left_bound) / 3
        # Check if the function value at mid1 is less than at mid2
        # If so, the maximum or minimum must be in the right third of the interval
        if unimodal_function(mid1) < unimodal_function(mid2):
            # Update the left boundary to be mid1
            left_bound = mid1
        else:
            # Update the right boundary to be mid2
            right_bound = mid2
    # At this point, the left and right boundaries are close enough to be considered equal
    # Return the average of the two boundaries as the point of maximum or minimum
    return (left_bound + right_bound) / 2
# Example usage:
def example_unimodal_function(x: float):
    """
    An example unimodal function.
    """
    return -x**2 + 3*x + 2
if __name__ == "__main__":
    max_point = ternary_search(example_unimodal_function, 0, 10)
    print(f"The maximum of the example unimodal function is at x = {max_point}")
    print(f"The maximum value is {example_unimodal_function(max_point)}")