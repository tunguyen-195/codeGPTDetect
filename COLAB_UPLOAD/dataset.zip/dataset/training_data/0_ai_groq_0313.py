def find_duplicate(nums: list[int]):
    """
    Finds the duplicate number in an array using Floyd's Tortoise and Hare algorithm.
    - nums (list[int]): A list of integers containing a duplicate number.
    - int: The duplicate number in the list.
    - ValueError: If the input list is empty or contains less than two elements.
    """
    if len(nums) < 2:
        raise ValueError("List must contain at least two elements")
    # Phase 1: Detecting the cycle using Floyd's Tortoise and Hare algorithm
    tortoise = nums[0]
    hare = nums[0]
    while True:
        tortoise = nums[tortoise]
        hare = nums[nums[hare]]
        if tortoise == hare:
            break
    # Phase 2: Finding the start of the cycle
    ptr1 = nums[0]
    ptr2 = tortoise
    while ptr1 != ptr2:
        ptr1 = nums[ptr1]
        ptr2 = nums[ptr2]
    return ptr1
# Example usage:
numbers = [1, 3, 4, 2, 2]
duplicate = find_duplicate(numbers)
print(f"The duplicate number is: {duplicate}")