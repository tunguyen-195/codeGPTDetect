import heapq
class PriorityQueue:
    """
    A class to implement a Priority Queue using heapq.
    """
    def __init__(self):
        """
        Initializes an empty Priority Queue.
        """
        self._queue = []
        self._index = {}
    def is_empty(self):
        """
        Checks if the Priority Queue is empty.
        """
        return not bool(self._queue)
    def push(self, item: any, priority: int):
        """
        Adds an item to the Priority Queue with a given priority.
        """
        if not isinstance(priority, int) or priority <= 0:
            raise ValueError("Priority must be a positive integer")
        heapq.heappush(self._queue, (-priority, item))
        self._index[item] = len(self._queue) - 1
    def pop(self):
        """
        Removes and returns the item with the highest priority.
        """
        if self.is_empty():
            raise IndexError("Priority Queue is empty")
        item = heapq.heappop(self._queue)[1]