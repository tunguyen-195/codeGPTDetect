def max_area(height: list[int]):
    """
    This function calculates the maximum area of water that can be trapped between two lines of height.
    int: The maximum area of water that can be trapped.
    Time complexity: O(n)
    Space complexity: O(1)
    """
    if not height:  # Check if the input list is empty
        return 0
    left, right = 0, len(height) - 1  # Initialize two pointers, one at the start and one at the end
    max_area = 0  # Initialize the maximum area
    while left < right:  # Continue until the two pointers meet
        # Calculate the width of the area
        width = right - left
        # Calculate the height of the area, which is the minimum of the two lines
        area_height = min(height[left], height[right])
        # Calculate the area of the current section
        area = width * area_height
        # Update the maximum area if the current area is larger
        max_area = max(max_area, area)
        # Move the pointer of the shorter line towards the other pointer
        if height[left] < height[right]:
            left += 1
        else:
            right -= 1
    return max_area