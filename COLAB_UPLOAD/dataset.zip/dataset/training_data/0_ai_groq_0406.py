def is_valid_parentheses(s: str):
    """
    Checks if a string of parentheses is valid.
    A string of parentheses is valid if every open parenthesis can be matched with a corresponding close parenthesis.
    The function uses a stack to keep track of the open parentheses.
    """
    # Create a dictionary to map closing parentheses to their corresponding opening ones
    parentheses_map = {")": "(", "}": "{", "]": "["}
    # Create a stack to keep track of the opening parentheses
    opening_parentheses = []
    # Iterate over each character in the string
    for char in s:
        # If the character is an opening parenthesis, push it onto the stack
        if char in parentheses_map.values():
            opening_parentheses.append(char)
        # If the character is a closing parenthesis, check if the stack is empty or its top does not match the current closing parenthesis
        elif char in parentheses_map.keys():
            if not opening_parentheses or opening_parentheses.pop() != parentheses_map[char]:
                return False
    # If the stack is empty after iterating over the entire string, the string is valid
    return not opening_parentheses