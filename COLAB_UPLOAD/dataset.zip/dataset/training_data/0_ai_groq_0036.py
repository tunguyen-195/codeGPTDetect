def linear_search_sentinel(arr: list, target: int):
    """
    Performs a linear search with sentinel on a given list to find the index of a target element.
    int: The index of the target element if found, -1 otherwise.
    ValueError: If the input list is empty.
    TypeError: If the input list is not a list or the target is not an integer.
    """
    # Check if input list is valid
    if not isinstance(arr, list):
        raise TypeError("Input must be a list.")
    if not arr:
        raise ValueError("Input list cannot be empty.")
    if not isinstance(target, int):
        raise TypeError("Target must be an integer.")
    # Create a copy of the list and append the target as the sentinel
    # This is done to avoid modifying the original list
    arr_copy = arr.copy()
    arr_copy.append(target)  # sentinel
    # Initialize the index
    i = 0
    # Perform the linear search
    while arr_copy[i] != target:
        # If we reach the end of the list without finding the target, it's not in the list
        i += 1
    # If we found the target, return its index in the original list
    # If the target is not in the list, return -1
    return i if i < len(arr) else -1
# Example usage
if __name__ == "__main__":
    numbers = [5, 2, 8, 12, 3]