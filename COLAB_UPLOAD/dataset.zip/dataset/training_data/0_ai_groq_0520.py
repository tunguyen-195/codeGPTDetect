from collections import deque
def sliding_window_max(arr: list[int], k: int):
    """
    Returns the maximum element in each window of size k in the given array.
    list[int]: A list of maximum elements in each window.
    ValueError: If k is larger than the array size.
    """
    if k > len(arr):
        raise ValueError("k cannot be larger than the array size")
    # Initialize a deque to store indices of elements in the current window
    # We use a deque because we need to efficiently remove elements from the left
    # when the window moves to the right
    window = deque()
    # Initialize the result list
    result = []
    # Process each element in the array
    for i, num in enumerate(arr):
        # Remove elements from the left of the window that are out of the current window
        while window and window[0] <= i - k:
            window.popleft()
        # Remove elements from the right of the window that are smaller than the current element
        while window and arr[window[-1]] < num:
            window.pop()
        # Add the current element to the window
        window.append(i)
        # If the window is full, add the maximum element to the result list
        if i >= k - 1:
            result.append(arr[window[0]])