def linear_search_sentinel(arr: list, target: int):
    """
    Searches for an element in a list using the linear search algorithm with a sentinel.
    """
    if not isinstance(arr, list):
        raise TypeError("Input must be a list")
    if not isinstance(target, int):
        raise TypeError("Target must be an integer")
    # Add the sentinel to the end of the list
    arr.append(target)
    # Iterate over the list to find the target
    for i, element in enumerate(arr):
        # If the target is found, return its index
        if element == target:
            return i
    # If the target is not found, return -1
    return -1
def main():
    # Example usage:
    arr = [1, 2, 3, 4, 5]
    target = 3
    result = linear_search_sentinel(arr, target)
    print(f"Target {target} found at index {result}")
if __name__ == "__main__":
    main()