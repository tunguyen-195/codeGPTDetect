def min_coins(coins: list[int], amount: int):
    """
    Returns the minimum number of coins required to reach the given amount.
    int: The minimum number of coins required. If it's impossible to reach the amount, returns -1.
    """
    # Create a list to store the minimum number of coins for each amount from 0 to the target amount
    dp = [float('inf')] * (amount + 1)
    dp[0] = 0  # Base case: 0 coins are needed to reach an amount of 0
    for coin in coins:
        # Iterate over each coin denomination
        for i in range(coin, amount + 1):
            # Update the minimum number of coins for the current amount
            dp[i] = min(dp[i], dp[i - coin] + 1)
    # Return the minimum number of coins for the target amount, or -1 if it's impossible to reach
    return dp[amount] if dp[amount] != float('inf') else -1
# Example usage
coins = [1, 2, 5]
amount = 11
print(min_coins(coins, amount))  # Output: 3 (11 = 5 + 5 + 1)