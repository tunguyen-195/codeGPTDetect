from typing import Dict, List, Set
class Graph:
    """
    A class representing a graph using adjacency list.
    """
    def __init__(self):
        """
        Initializes an empty graph.
        """
        self.graph: Dict[int, List[int]] = {}
    def add_edge(self, node1: int, node2: int):
        """
        Adds an edge between two nodes in the graph.
        """
        if node1 not in self.graph:
            self.graph[node1] = []
        if node2 not in self.graph:
            self.graph[node2] = []
        self.graph[node1].append(node2)
        self.graph[node2].append(node1)
    def dfs(self, start_node: int):
        """
        Performs a depth-first search traversal of the graph.
        """
        if start_node not in self.graph:
            raise KeyError("Start node not found in the graph")
        visited: Set[int] = set()
        traversal_order: List[int] = []
        self._dfs_helper(start_node, visited, traversal_order)
        return traversal_order
    def _dfs_helper(self, node: int, visited: Set[int], traversal_order: List[int]):
        """