class Node:
    """Represents a node in the AVL tree."""
    def __init__(self, key: int):
        """
        Initializes a Node with a given key.
        """
        self.key = key
        self.height = 1
        self.left = None
        self.right = None
class AVLTree:
    """Represents an AVL tree with automatic balancing and rotation methods."""
    def __init__(self):
        """
        Initializes an empty AVL tree.
        """
        self.root = None
    def get_height(self, node: Node):
        """
        Gets the height of a node.
        """
        if node is None:
            return 0
        return node.height
    def update_height(self, node: Node):
        """
        Updates the height of a node based on its children.
        """
        node.height = 1 + max(self.get_height(node.left), self.get_height(node.right))
    def get_balance(self, node: Node):
        """
        Gets the balance factor of a node.
