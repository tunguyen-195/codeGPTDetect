from typing import Dict, List, Set
def word_break(s: str, word_dict: List[str]):
    """
    Determine if a given string can be segmented into words from a dictionary.
    bool: True if the string can be segmented, False otherwise.
    """
    n = len(s)
    dp: Dict[int, bool] = {0: True}  # dp[i] means s[:i+1] can be segmented into words in word_dict
    for i in range(1, n + 1):
        for j in range(i):
            # Check if s[j:i] is in word_dict and dp[j] is True
            if s[j:i] in word_dict and dp.get(j, False):
                dp[i] = True
                break
    return dp.get(n, False)
def word_break_optimized(s: str, word_dict: Set[str]):
    """
    Determine if a given string can be segmented into words from a dictionary.
    bool: True if the string can be segmented, False otherwise.
    """
    n = len(s)
    dp: Dict[int, bool] = {0: True}  # dp[i] means s[:i+1] can be segmented into words in word_dict
    for i in range(1, n + 1):
        for j in range(i):
            # Check if s[j:i] is in word_dict and dp[j] is True
            if s[j:i] in word_dict and dp.get(j, False):
                dp[i] = True