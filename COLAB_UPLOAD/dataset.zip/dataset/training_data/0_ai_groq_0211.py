class Interval:
    """Represents a time interval with start and end points."""
    
    def __init__(self, start: int, end: int):
        """
        Initializes an Interval object.
        """
        self.start = start
        self.end = end
    def __repr__(self):
        """Returns a string representation of the interval."""
        return f"Interval({self.start}, {self.end})"
def merge_intervals(intervals: list[Interval]):
    """
    Merges overlapping intervals in the given list.
    """
    if not intervals:
        raise ValueError("Input list is empty")
    # Sort the intervals by their start points
    intervals.sort(key=lambda x: x.start)
    merged = [intervals[0]]
    for current in intervals[1:]:
        # Get the last merged interval
        last_merged = merged[-1]
        
        # Check if the current interval overlaps with the last merged interval
        if current.start <= last_merged.end:
            # Merge the current interval with the last merged interval
            merged[-1] = Interval(last_merged.start, max(last_merged.end, current.end))
        else:
            # Add the current interval to the list of merged intervals
            merged.append(current)
    return merged