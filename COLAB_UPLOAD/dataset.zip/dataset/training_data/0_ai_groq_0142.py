class Node:
    """
    A node in the doubly linked list.
    """
    def __init__(self, data: any):
        """
        Initializes a new node with the given data.
        """
        self.data = data
        self.next = None
        self.prev = None
class DoublyLinkedList:
    """
    A doubly linked list with bidirectional traversal.
    """
    def __init__(self):
        """
        Initializes an empty doubly linked list.
        """
        self.head = None
        self.tail = None
    def append(self, data: any):
        """
        Appends a new node with the given data to the end of the list.
        """
        new_node = Node(data)
        if not self.head:
            self.head = new_node
            self.tail = new_node
        else:
            new_node.prev = self.tail
            self.tail.next = new_node
            self.tail = new_node
