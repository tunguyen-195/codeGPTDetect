from typing import Dict, List, Any
class Graph:
    """
    A class to represent a Graph using adjacency list.
    
    ----------
    adjacency_list : Dict[Any, List[Any]]
        A dictionary representing the adjacency list of the graph.
        
    Methods:
    -------
    add_edge(node: Any, neighbor: Any) : None
        Adds an edge between two nodes in the graph.
    dfs(start_node: Any) -> List[Any]
        Performs a depth-first search traversal of the graph starting from the given node.
    bfs(start_node: Any) -> List[Any]
        Performs a breadth-first search traversal of the graph starting from the given node.
    """
    def __init__(self):
        """
        Initializes an empty graph.
        """
        self.adjacency_list: Dict[Any, List[Any]] = {}
    def add_edge(self, node: Any, neighbor: Any):
        """
        Adds an edge between two nodes in the graph.
        
        ----
        node : Any
            The node to add the edge to.
        neighbor : Any
            The neighbor node to add the edge from.
        
        ------
        ValueError
            If the node or neighbor is not in the graph.
        """