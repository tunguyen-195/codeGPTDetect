def floyd_warshall(graph: list[list[int]]):
    """
    Floyd-Warshall algorithm to find the shortest path between all pairs of vertices.
    graph: A 2D list representing the adjacency matrix of the graph.
           graph[i][j] is the weight of the edge from vertex i to vertex j.
           If there is no edge between vertices i and j, then graph[i][j] is float('inf').
    A 2D list where the value at index [i][j] is the shortest path from vertex i to vertex j.
    """
    # Get the number of vertices in the graph
    num_vertices = len(graph)
    # Create a copy of the graph to store the shortest distances
    dist = [[float('inf')] * num_vertices for _ in range(num_vertices)]
    # Initialize the dist matrix with the weights from the graph
    for i in range(num_vertices):
        for j in range(num_vertices):
            dist[i][j] = graph[i][j]
    # The distance from a vertex to itself is 0
    for i in range(num_vertices):
        dist[i][i] = 0
    # Iterate over all possible intermediate vertices
    for k in range(num_vertices):
        # Iterate over all pairs of vertices
        for i in range(num_vertices):
            for j in range(num_vertices):
                # Check if the path from i to k and then from k to j is shorter than the current shortest path from i to j
                dist[i][j] = min(dist[i][j], dist[i][k] + dist[k][j])
    return dist
def print_shortest_paths(dist: list[list[int]]):
    """
    Print the shortest paths between all pairs of vertices.
    dist: A 2D list where the value at index [i][j] is the shortest path from vertex i to vertex j.