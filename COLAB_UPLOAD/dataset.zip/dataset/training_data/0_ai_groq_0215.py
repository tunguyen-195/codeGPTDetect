def three_sum(nums: list[int]):
    """
    This function solves the three sum problem, where it finds all triplets in the given list that sum up to zero.
    """
    # First, we sort the list to apply the two-pointer technique later
    nums.sort()
    # Initialize an empty list to store the result
    triplets = []
    
    # Iterate over the list
    for i in range(len(nums) - 2):
        # Skip the same result
        if i > 0 and nums[i] == nums[i - 1]:
            continue
        
        # Initialize two pointers, one at the next element and one at the end of the list
        left, right = i + 1, len(nums) - 1
        
        # Apply the two-pointer technique
        while left < right:
            # Calculate the current sum
            current_sum = nums[i] + nums[left] + nums[right]
            
            # If the current sum is zero, we found a triplet
            if current_sum == 0:
                # Add the triplet to the result
                triplets.append([nums[i], nums[left], nums[right]])
                # Move the pointers to find the next triplet
                left += 1
                right -= 1
                
                # Skip the same result
                while left < right and nums[left] == nums[left - 1]:
                    left += 1
                while left < right and nums[right] == nums[right + 1]:
                    right -= 1
            # If the current sum is less than zero, move the left pointer to increase the sum
            elif current_sum < 0:
                left += 1