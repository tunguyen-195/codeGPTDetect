def merge_sort(arr: list[int]):
    """
    Sorts the input list in-place using the MergeSort algorithm with in-place optimization.
    
    Time complexity: O(n log n)
    Space complexity: O(1) (in-place sorting)
    
    :param arr: The input list to be sorted
    :return: None
    """
    _merge_sort_helper(arr, 0, len(arr) - 1)
def _merge_sort_helper(arr: list[int], low: int, high: int):
    """
    Recursively sorts the subarray within the given range [low, high] using the MergeSort algorithm.
    
    :param arr: The input list to be sorted
    :param low: The starting index of the subarray
    :param high: The ending index of the subarray
    :return: None
    """
    if low < high:
        mid = (low + high) // 2
        _merge_sort_helper(arr, low, mid)
        _merge_sort_helper(arr, mid + 1, high)
        _merge(arr, low, mid, high)
def _merge(arr: list[int], low: int, mid: int, high: int):
    """
    Merges two sorted subarrays within the given range [low, mid] and [mid + 1, high] into a single sorted subarray.
    
    :param arr: The input list to be sorted
    :param low: The starting index of the first subarray
    :param mid: The ending index of the first subarray
    :param high: The ending index of the second subarray
    :return: None
    """
    left_idx = low
    right_idx = mid + 1
    temp = [0] * (high - low + 1)