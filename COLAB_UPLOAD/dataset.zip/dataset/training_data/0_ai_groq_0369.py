def shell_sort(arr: list):
    """
    Sorts an array using the Shell Sort algorithm with a custom gap sequence.
    The time complexity of this implementation is O(n log n) in the best and average cases,
    and O(n^2) in the worst case (when the gap sequence is not chosen wisely).
    """
    if not isinstance(arr, list):
        raise TypeError("Input must be a list")
    # Define a custom gap sequence
    gap_sequence = [107, 32, 19, 10, 5, 2, 1]
    # Iterate over each gap in the gap sequence
    for gap in gap_sequence:
        # Iterate over the array starting from the gap
        for i in range(gap, len(arr)):
            # Store the current element as temp
            temp = arr[i]
            j = i
            # Shift elements to the right until the correct position is found
            while j >= gap and arr[j - gap] > temp:
                arr[j] = arr[j - gap]
                j -= gap
            # Insert the temp element at the correct position
            arr[j] = temp
    return arr
# Example usage:
arr = [64, 34, 25, 12, 22, 11, 90]
print("Original array:", arr)
print("Sorted array:", shell_sort(arr))