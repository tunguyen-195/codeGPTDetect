class Solution:
    def wordBreak(self, s: str, wordDict: list[str]):
        """
        Returns a list of all possible sentences that can be formed by breaking the input string into words from the given dictionary.
        list[str]: A list of all possible sentences.
        """
        n = len(s)
        dp = [[False] * (n + 1) for _ in range(n + 1)]
        dp[0][0] = True
        for i in range(n):
            for j in range(i, n):
                if s[i:j + 1] in wordDict:
                    dp[i + 1][j + 1] = dp[i + 1][j + 1] or dp[i][j]
                else:
                    dp[i + 1][j + 1] = dp[i + 1][j + 1] or dp[i][j + 1]
        def backtrack(start: int, path: list[str]):
            """
            A helper function to perform backtracking and construct all possible sentences.
            list[str]: A list of all possible sentences.
            """
            if start == n:
                return ["".join(path)]
            sentences = []
            for end in range(start + 1, n + 1):
                if dp[start][end]:
                    for sentence in backtrack(end, path + [s[start:end]]):
                        sentences.append(sentence)
            return sentences
        return backtrack(0, [])
