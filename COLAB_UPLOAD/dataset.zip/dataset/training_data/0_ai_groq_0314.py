def two_sum(nums: list[int], target: int):
    """
    Returns two indices of the given list that add up to the target value.
    - nums (list[int]): A list of integers.
    - target (int): The target sum.
    - list[int]: A list containing the indices of the two numbers that add up to the target value.
                 If no such pair is found, returns an empty list.
    - ValueError: If the input list is empty or the target value is None.
    """
    if not nums:
        raise ValueError("Input list cannot be empty")
    if target is None:
        raise ValueError("Target value cannot be None")
    num_map = {}  # Hash map to store the numbers we've seen so far and their indices
    for i, num in enumerate(nums):
        # Calculate the complement of the current number
        complement = target - num
        # Check if the complement is in the hash map
        if complement in num_map:
            # If it is, return the indices of the current number and its complement
            return [num_map[complement], i]
        else:
            # If not, add the current number and its index to the hash map
            num_map[num] = i
    # If we've iterated through the entire list and found no pair that adds up to the target value, return an empty list
    return []