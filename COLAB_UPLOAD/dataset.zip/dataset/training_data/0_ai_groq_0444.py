import random
class Node:
    """
    A node in the Skip List.
    
    """
    def __init__(self, value: int, level: int = 1):
        self.value = value
        self.next = [None] * level
class SkipList:
    """
    A Skip List data structure.
    
    """
    def __init__(self, max_level: int = 16, p: float = 0.5):
        self.max_level = max_level
        self.p = p
        self.head = Node(float('-inf'), max_level)
    def _random_level(self):
        """
        Generate a random level for a new node.
        
        int: The random level.
        """
        level = 1
        while random.random() < self.p and level < self.max_level:
            level += 1
        return level
    def insert(self, value: int):
        """
        Insert a new value into the Skip List.