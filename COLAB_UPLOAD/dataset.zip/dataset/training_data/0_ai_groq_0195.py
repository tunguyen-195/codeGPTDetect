def longest_palindrome_substring(s: str):
    """
    This function finds the longest palindrome substring in a given string.
    
    
    str: The longest palindrome substring.
    
    TypeError: If the input is not a string.
    ValueError: If the input string is empty.
    """
    # Check if input is a string
    if not isinstance(s, str):
        raise TypeError("Input must be a string.")
    # Check if input string is empty
    if not s:
        raise ValueError("Input string cannot be empty.")
    # Initialize a table to store whether each substring is a palindrome or not
    n = len(s)
    table = [[False for _ in range(n)] for _ in range(n)]
    # All substrings with one character are palindromes
    for i in range(n):
        table[i][i] = True
    # Initialize the maximum length of palindrome and its starting index
    max_length = 1
    start = 0
    # Check for substrings of length 2
    for i in range(n - 1):
        if s[i] == s[i + 1]:
            table[i][i + 1] = True
            start = i
            max_length = 2
    # Check for lengths greater than 2