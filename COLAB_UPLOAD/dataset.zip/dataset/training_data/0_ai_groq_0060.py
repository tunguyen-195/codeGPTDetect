def longest_palindrome_substring(s: str):
    """
    This function finds the longest palindrome substring in a given string.
    """
    # Check if input is a string
    if not isinstance(s, str):
        raise TypeError("Input must be a string.")
    # Handle edge case where string is empty
    if not s:
        return ""
    def expand_around_center(s: str, left: int, right: int):
        """
        Helper function to expand around the center of a potential palindrome.
        """
        while left >= 0 and right < len(s) and s[left] == s[right]:
            # Expand outwards as long as characters match
            left -= 1
            right += 1
        # Return the palindrome substring
        return s[left + 1:right]
    longest_palindrome = ""
    for i in range(len(s)):
        # Odd length palindrome
        odd_palindrome = expand_around_center(s, i, i)
        if len(odd_palindrome) > len(longest_palindrome):
            longest_palindrome = odd_palindrome
        # Even length palindrome
        even_palindrome = expand_around_center(s, i, i + 1)
        if len(even_palindrome) > len(longest_palindrome):
            longest_palindrome = even_palindrome
    return longest_palindrome