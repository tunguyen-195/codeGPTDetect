class Graph:
    """
    A class to represent a graph using an adjacency matrix.
    """
    def __init__(self, num_vertices: int):
        """
        Initializes a graph with a specified number of vertices.
        """
        self.num_vertices = num_vertices
        # Initialize an adjacency matrix with all elements as 0
        self.adjacency_matrix = [[0 for _ in range(num_vertices)] for _ in range(num_vertices)]
    def add_edge(self, vertex1: int, vertex2: int):
        """
        Adds an edge between two vertices in the graph.
        ValueError: If either vertex is out of range.
        """
        if vertex1 < 0 or vertex1 >= self.num_vertices or vertex2 < 0 or vertex2 >= self.num_vertices:
            raise ValueError("Vertex index is out of range")
        # Add an edge by setting the corresponding element in the adjacency matrix to 1
        self.adjacency_matrix[vertex1][vertex2] = 1
        self.adjacency_matrix[vertex2][vertex1] = 1  # For undirected graph
    def remove_edge(self, vertex1: int, vertex2: int):
        """
        Removes an edge between two vertices in the graph.
