def counting_sort(arr: list[int]):
    """
    Sorts an array of integers using the Counting Sort algorithm.
    Time Complexity:
    - Best: O(n + k) where n is the number of elements in the array and k is the range of input.
    - Average: O(n + k)
    - Worst: O(n + k)
    Space Complexity: O(n + k)
    list[int]: The sorted array.
    ValueError: If the input array is empty.
    TypeError: If the input array contains non-integer values.
    """
    # Check if the input array is empty
    if not arr:
        raise ValueError("Input array is empty")
    # Check if the input array contains non-integer values
    if not all(isinstance(x, int) for x in arr):
        raise TypeError("Input array contains non-integer values")
    # Find the maximum element in the array to determine the range of input
    max_val = max(arr)
    # Create a count array to store the count of individual elements
    count_arr = [0] * (max_val + 1)
    # Count the occurrences of each element in the input array
    for num in arr:
        count_arr[num] += 1
    # Initialize an empty sorted array
    sorted_arr = []
