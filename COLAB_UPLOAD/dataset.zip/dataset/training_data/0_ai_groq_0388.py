def rod_cutting(prices: list[int], n: int):
    """
    This function solves the Rod Cutting problem using dynamic programming.
    
    The Rod Cutting problem is a classic problem in dynamic programming. 
    We are given a rod of length n and a list of prices for each possible length of the rod.
    We need to find the optimal way to cut the rod to maximize the total revenue.
    Time complexity: O(n^2)
    Space complexity: O(n)
    """
    # Initialize a list to store the maximum revenue for each length of the rod
    dp = [0] * (n + 1)
    # Iterate over each possible length of the rod
    for i in range(1, n + 1):
        # Initialize the maximum revenue for the current length to be 0
        max_revenue = 0
        
        # Iterate over each possible cut length
        for j in range(i):
            # Calculate the revenue for the current cut
            revenue = prices[j] + dp[i - j - 1]
            
            # Update the maximum revenue if the current revenue is higher
            max_revenue = max(max_revenue, revenue)
        
        # Store the maximum revenue for the current length
        dp[i] = max_revenue
    # Return the maximum revenue for the given length of the rod
    return dp[n]
# Example usage:
prices = [0, 0, 8, 16, 20, 0, 32, 36]
n = 5
print("Maximum revenue:", rod_cutting(prices, n))