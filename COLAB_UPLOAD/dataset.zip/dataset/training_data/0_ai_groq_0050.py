def coin_change(coins: list[int], amount: int):
    """
    This function calculates the minimum number of coins required to make a given amount.
    
    
    int: The minimum number of coins required. If it's not possible to make the amount, returns -1.
    """
    
    # Create a list to store the minimum number of coins required for each amount from 0 to the given amount
    dp = [float('inf')] * (amount + 1)
    
    # Base case: 0 coins are required to make an amount of 0
    dp[0] = 0
    
    # Iterate over each amount from 1 to the given amount
    for i in range(1, amount + 1):
        # Iterate over each coin denomination
        for coin in coins:
            # If the coin denomination is less than or equal to the current amount
            if coin <= i:
                # Update the minimum number of coins required for the current amount
                dp[i] = min(dp[i], dp[i - coin] + 1)
    
    # If the minimum number of coins required for the given amount is still infinity, return -1
    if dp[amount] == float('inf'):
        return -1
    # Otherwise, return the minimum number of coins required
    else:
        return dp[amount]
def main():
    # Example usage:
    coins = [1, 2, 5]
    amount = 11
    result = coin_change(coins, amount)
    print(f"Minimum coins required to make {amount} using coins {coins}: {result}")
if __name__ == "__main__":