def rabin_karp(text: str, pattern: str):
    """
    Searches for a pattern in a given text using the Rabin-Karp algorithm.
    int: The index of the first occurrence of the pattern in the text. Returns -1 if the pattern is not found.
    ValueError: If the text or pattern is an empty string.
    """
    if not text or not pattern:
        raise ValueError("Text and pattern cannot be empty")
    # Base case: If the pattern is longer than the text, it cannot be found
    if len(pattern) > len(text):
        return -1
    # Initialize the hash values for the pattern and the first window of the text
    pattern_hash = 0
    text_hash = 0
    h = 1
    # Calculate the hash value for the pattern
    for char in pattern:
        pattern_hash = (pattern_hash * 26 + ord(char) - ord('a')) % (10**9 + 7)
        h = (h * 26) % (10**9 + 7)
    # Calculate the hash value for the first window of the text
    for i in range(len(pattern)):
        text_hash = (text_hash * 26 + ord(text[i]) - ord('a')) % (10**9 + 7)
    # Slide the window over the text and compare hash values
    for i in range(len(text) - len(pattern) + 1):
        if text_hash == pattern_hash:
            # If the hash values match, check if the actual characters match
            if text[i:i+len(pattern)] == pattern:
                return i
