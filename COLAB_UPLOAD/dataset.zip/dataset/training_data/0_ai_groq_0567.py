def radix_sort(numbers: list[int]):
    """
    Sorts a list of integers using Radix Sort.
    Time Complexity:
        - Best case: O(nk)
        - Average case: O(nk)
        - Worst case: O(nk)
    where n is the number of elements and k is the number of digits in the maximum number.
    """
    # Check for edge cases
    if not numbers:
        raise ValueError("Input list is empty")
    if not all(isinstance(num, int) for num in numbers):
        raise TypeError("Input list contains non-integer values")
    # Find the maximum number to determine the number of digits
    max_num = max(numbers)
    # Initialize the exponent to 1 (for the least significant digit)
    exp = 1
    # Perform counting sort for every digit
    while max_num // exp > 0:
        # Initialize the count array
        count = [0] * 10
        # Count the occurrences of each digit
        for num in numbers:
            digit = (num // exp) % 10
            count[digit] += 1
        # Calculate cumulative counts
        for i in range(1, 10):
            count[i] += count[i - 1]
        # Build the output array