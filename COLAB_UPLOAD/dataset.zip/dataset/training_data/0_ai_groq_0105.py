from abc import ABC, abstractmethod
from typing import Optional
class Vehicle(ABC):
    """
    Abstract base class for all vehicles.
    
    -----------
    make : str
        The make of the vehicle.
    model : str
        The model of the vehicle.
    year : int
        The year of the vehicle.
    color : str
        The color of the vehicle.
    mileage : int
        The mileage of the vehicle.
    """
    def __init__(self, make: str, model: str, year: int, color: str, mileage: int = 0):
        """
        Initializes a Vehicle object.
        
        -----
        make : str
            The make of the vehicle.
        model : str
            The model of the vehicle.
        year : int
            The year of the vehicle.
        color : str
            The color of the vehicle.
        mileage : int, optional
            The mileage of the vehicle (default is 0).
        """
        self.make = make
        self.model = model
        self.year = year
        self.color = color