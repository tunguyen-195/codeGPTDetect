def shell_sort(arr: list[int]):
    """
    Sorts an array using the Shell Sort algorithm with a custom gap sequence.
    The time complexity of Shell Sort is O(n log n) in the average case, 
    but it can degrade to O(n^2) in the worst case if the gap sequence is not carefully chosen.
    """
    if not isinstance(arr, list) or not all(isinstance(x, int) for x in arr):
        raise TypeError("Input must be a list of integers.")
    # Define a custom gap sequence
    gap_sequence = [701, 301, 132, 57, 23, 10, 4, 1]
    # Start with the largest gap
    for gap in gap_sequence:
        # Iterate over the array with the current gap
        for i in range(gap, len(arr)):
            # Store the current element to be compared
            temp = arr[i]
            # Initialize the index for the comparison
            j = i
            # Shift elements to the right until a smaller element is found
            while j >= gap and arr[j - gap] > temp:
                arr[j] = arr[j - gap]
                j -= gap
            # Place the current element in its correct position
            arr[j] = temp
    return arr
# Example usage
if __name__ == "__main__":
    import random
    import time
    # Generate a random array of 1000 integers
    arr = [random.randint(0, 1000) for _ in range(1000)]
    # Time the sorting operation