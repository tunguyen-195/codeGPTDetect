import heapq
import math
class AStarSearch:
    """
    A* Search algorithm implementation for pathfinding.
    """
    def __init__(self, grid, start, goal, heuristic='manhattan', diagonal=False):
        """
        Initializes the AStarSearch object.
        """
        self.grid = grid
        self.start = start
        self.goal = goal
        self.heuristic = heuristic
        self.diagonal = diagonal
    def heuristic_function(self, node):
        """
        Calculates the heuristic value for the given node.
        """
        if self.heuristic == 'manhattan':
            return abs(node[0] - self.goal[0]) + abs(node[1] - self.goal[1])
        elif self.heuristic == 'euclidean':
            return math.sqrt((node[0] - self.goal[0])**2 + (node[1] - self.goal[1])**2)
        else:
            raise ValueError("Invalid heuristic function")
    def get_neighbors(self, node):
        """
        Gets the neighbors of the given node.
        """
        neighbors = []
        x, y = node
        if self.diagonal: