def max_subarray_sum(nums: list[int]):
    """
    Returns the maximum sum of a subarray in the given list of numbers.
    """
    if not nums:
        raise ValueError("Input list cannot be empty")
    max_current = max_global = nums[0]
    for num in nums[1:]:
        # Update the maximum sum of the subarray ending at the current position
        max_current = max(num, max_current + num)
        
        # Update the maximum sum of any subarray found so far
        max_global = max(max_global, max_current)
    return max_global
# Example usage:
numbers = [-2, -3, 4, -1, -2, 1, 5, -3]
print(max_subarray_sum(numbers))  # Output: 7