from typing import Dict, List, Set
class Graph:
    """
    A class representing a graph.
    ----------
    num_vertices : int
        The number of vertices in the graph.
    adjacency_list : Dict[int, List[int]]
        An adjacency list representation of the graph.
    """
    def __init__(self, num_vertices: int):
        """
        Initializes a graph with the given number of vertices.
        ----
        num_vertices : int
            The number of vertices in the graph.
        """
        self.num_vertices = num_vertices
        self.adjacency_list = {i: [] for i in range(num_vertices)}
    def add_edge(self, u: int, v: int):
        """
        Adds an edge between the given vertices.
        ----
        u : int
            The first vertex.
        v : int
            The second vertex.
        """
        self.adjacency_list[u].append(v)
        self.adjacency_list[v].append(u)
    def articulation_points(self):
        """
        Finds all articulation points in the graph.