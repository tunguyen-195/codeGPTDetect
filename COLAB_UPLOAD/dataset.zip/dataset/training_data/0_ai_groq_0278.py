import heapq
import math
class AStarSearch:
    """
    A* Search algorithm for pathfinding.
    -----------
    grid : list of lists
        A 2D grid representing the environment.
        0: empty cell
        1: obstacle
        2: start point
        3: goal point
    heuristic : str
        The heuristic function to use (manhattan, euclidean, or diagonal).
    """
    def __init__(self, grid, heuristic='manhattan'):
        """
        Initialize the A* Search algorithm.
        ----
        grid : list of lists
            A 2D grid representing the environment.
        heuristic : str
            The heuristic function to use (manhattan, euclidean, or diagonal).
        """
        self.grid = grid
        self.heuristic = heuristic
        self.rows = len(grid)
        self.cols = len(grid[0])
    def heuristic_function(self, node):
        """
        Calculate the heuristic value for a given node.
        ----
        node : tuple
            The node coordinates (x, y).