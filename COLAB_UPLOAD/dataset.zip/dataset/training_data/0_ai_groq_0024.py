from collections import OrderedDict
from typing import Any, Dict, Optional
class LRUCache:
    """
    A class implementing an LRU (Least Recently Used) Cache using OrderedDict.
    The cache has a fixed size, and when it reaches its capacity, it removes the least recently used item.
    """
    def __init__(self, capacity: int):
        """
        Initializes the LRU Cache with a given capacity.
        """
        self.capacity = capacity
        self.cache = OrderedDict()  # type: OrderedDict[int, Any]
    def get(self, key: int):
        """
        Retrieves the value associated with a given key from the cache.
        """
        if key in self.cache:
            # Move the accessed item to the end of the ordered dict to mark it as recently used
            value = self.cache.pop(key)
            self.cache[key] = value
            return value
        return None
    def put(self, key: int, value: Any):
        """
        Adds or updates an item in the cache.
        If the cache has reached its capacity, the least recently used item is removed before adding the new item.
        """
        if key in self.cache:
            # If the key already exists, remove it to update its position in the ordered dict
            self.cache.pop(key)