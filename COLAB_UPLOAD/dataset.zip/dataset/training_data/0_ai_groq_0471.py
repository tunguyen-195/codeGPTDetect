def linear_search_with_sentinel(arr: list, target: int):
    """
    Searches for an element in a list using linear search with a sentinel.
    int: The index of the target element if found, -1 otherwise.
    TypeError: If the input list is not a list or the target is not an integer.
    ValueError: If the input list is empty.
    """
    # Check if the input list is a list and the target is an integer
    if not isinstance(arr, list) or not isinstance(target, int):
        raise TypeError("Input list must be a list and target must be an integer.")
    # Check if the input list is empty
    if len(arr) == 0:
        raise ValueError("Input list cannot be empty.")
    # Add a sentinel value to the end of the list
    # This value is guaranteed to be larger than any element in the list
    arr.append(float('inf'))
    # Iterate over the list
    for i in range(len(arr)):
        # If the current element is equal to the target, return its index
        if arr[i] == target:
            return i
    # If the target is not found, return -1
    return -1
# Example usage:
arr = [1, 2, 3, 4, 5]
target = 3
index = linear_search_with_sentinel(arr, target)
print(f"Target {target} found at index {index}")  # Output: Target 3 found at index 2
