from typing import Dict, List, Set
class Graph:
    """
    A directed graph represented as an adjacency list.
    """
    def __init__(self):
        """
        Initialize an empty graph.
        """
        self.adjacency_list: Dict[int, List[int]] = {}
    def add_edge(self, source: int, destination: int):
        """
        Add a directed edge from source to destination.
        """
        if source not in self.adjacency_list:
            self.adjacency_list[source] = []
        self.adjacency_list[source].append(destination)
    def cycle_detection(self, start_node: int):
        """
        Detect a cycle in the graph using DFS.
        bool: True if a cycle is detected, False otherwise.
        """
        visited: Set[int] = set()
        recursion_stack: Set[int] = set()
        def dfs(node: int):
            """
            Perform DFS from the given node.
