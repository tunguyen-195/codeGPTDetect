from typing import List
def bucket_sort(data: List[float], bucket_size: int = 10):
    """
    Sorts uniformly distributed data using the Bucket Sort algorithm.
    - data (List[float]): The list of numbers to be sorted.
    - bucket_size (int): The size of each bucket. Defaults to 10.
    - List[float]: The sorted list of numbers.
    Time complexity:
    - Best-case: O(n + k) where n is the number of elements and k is the number of buckets.
    - Average-case: O(n + k) where n is the number of elements and k is the number of buckets.
    - Worst-case: O(n^2) if the input data is not uniformly distributed.
    - This implementation assumes that the input data is uniformly distributed.
    - If the input data is not uniformly distributed, the worst-case time complexity is O(n^2).
    """
    # Check if the input data is a list
    if not isinstance(data, list):
        raise TypeError("Input data must be a list.")
    # Check if the list is empty
    if len(data) == 0:
        return data
    # Calculate the minimum and maximum values in the data
    min_value = min(data)
    max_value = max(data)
    # Calculate the number of buckets
    num_buckets = (max_value - min_value) / bucket_size + 1
    # Initialize empty buckets
    buckets = [[] for _ in range(int(num_buckets))]
    # Distribute the data into buckets
    for num in data: