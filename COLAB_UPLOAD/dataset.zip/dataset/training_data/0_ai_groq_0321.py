def find_median_two_sorted_arrays(nums1: list[int], nums2: list[int]):
    """
    Find the median of two sorted arrays.
    - nums1 (list[int]): The first sorted array.
    - nums2 (list[int]): The second sorted array.
    - float: The median of the combined array.
    Time Complexity:
    - O(log(min(len(nums1), len(nums2))))
    """
    if len(nums1) > len(nums2):
        # Swap nums1 and nums2 to ensure nums1 is the smaller array
        nums1, nums2 = nums2, nums1
    x, y = len(nums1), len(nums2)
    start = 0
    end = x
    while start <= end:
        # Calculate the partition point for nums1
        partition_x = (start + end) // 2
        # Calculate the partition point for nums2
        partition_y = ((x + y + 1) // 2) - partition_x
        # Calculate the values at the partition points
        max_left_x = float('-inf') if partition_x == 0 else nums1[partition_x - 1]
        min_right_x = float('inf') if partition_x == x else nums1[partition_x]
        max_left_y = float('-inf') if partition_y == 0 else nums2[partition_y - 1]
        min_right_y = float('inf') if partition_y == y else nums2[partition_y]
        # Check if the partition is correct
        if max_left_x <= min_right_y and max_left_y <= min_right_x:
            # If the total length is even, the median is the average of the two middle numbers
            if (x + y) % 2 == 0:
                return (max(max_left_x, max_left_y) + min(min_right_x, min_right_y)) / 2
            # If the total length is odd, the median is the middle number
            else: