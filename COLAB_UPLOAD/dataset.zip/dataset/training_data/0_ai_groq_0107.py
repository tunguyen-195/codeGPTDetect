from abc import ABC, abstractmethod
from typing import List
class Employee(ABC):
    """
    Abstract base class representing an employee.
    
    """
    def __init__(self, id: int, name: str, age: int, salary: float):
        """
        Initializes an Employee object.
        """
        self.id = id
        self.name = name
        self.age = age
        self.salary = salary
    @abstractmethod
    def calculate_bonus(self):
        """
        Calculates the bonus for the employee.
        float: The calculated bonus.
        """
        pass
    def display_details(self):
        """
        Displays the details of the employee.
        """