class HashTable:
    """
    A Hash Table implementation using separate chaining for collision resolution.
    
    ----------
    size : int
        The size of the hash table.
    table : list
        The underlying list to store hash table entries.
    """
    def __init__(self, size: int = 10):
        """
        Initializes a new Hash Table instance.
        
        ----
        size : int, optional
            The size of the hash table (default is 10).
        """
        self.size = size
        self.table = [[] for _ in range(size)]
    def _hash_function(self, key: str):
        """
        A simple hash function to map a key to an index in the hash table.
        
        ----
        key : str
            The key to be hashed.
        
        -------
        int
            The index corresponding to the hashed key.
        """
        return hash(key) % self.size
    def insert(self, key: str, value: any):
        """
        Inserts a new entry into the hash table.
        