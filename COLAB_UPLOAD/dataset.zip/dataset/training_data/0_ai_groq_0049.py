def edit_distance(str1: str, str2: str):
    """
    Calculate the edit distance (Levenshtein distance) between two strings.
    The edit distance is the minimum number of operations (insertions, deletions, substitutions)
    required to transform one string into another.
    Time complexity: O(m * n), where m and n are the lengths of the two strings.
    Space complexity: O(m * n), where m and n are the lengths of the two strings.
    """
    # Initialize a 2D array to store the edit distances between substrings
    m, n = len(str1), len(str2)
    dp = [[0] * (n + 1) for _ in range(m + 1)]
    # Initialize the base cases
    # The edit distance between an empty string and a non-empty string is the length of the non-empty string
    for i in range(m + 1):
        dp[i][0] = i
    for j in range(n + 1):
        dp[0][j] = j
    # Fill in the rest of the 2D array using dynamic programming
    for i in range(1, m + 1):
        for j in range(1, n + 1):
            # If the current characters in the two strings are the same, there's no operation needed
            if str1[i - 1] == str2[j - 1]:
                dp[i][j] = dp[i - 1][j - 1]
            # Otherwise, consider all possible operations (insertion, deletion, substitution) and choose the one with the minimum cost
            else:
                # Insertion: dp[i][j - 1] + 1
                # Deletion: dp[i - 1][j] + 1
                # Substitution: dp[i - 1][j - 1] + 1
                dp[i][j] = 1 + min(dp[i][j - 1], dp[i - 1][j], dp[i - 1][j - 1])
    # The edit distance between the two strings is stored in the bottom-right corner of the 2D array
    return dp[m][n]
def main():
    try: