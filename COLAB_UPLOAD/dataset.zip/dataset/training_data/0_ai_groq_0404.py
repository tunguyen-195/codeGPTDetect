def compress_string(input_str: str):
    """
    Compress a given string by replacing sequences of repeating characters
    with the character followed by the count of repetitions.
    """
    if not isinstance(input_str, str):
        raise TypeError("Input must be a string.")
    if not input_str:  # Check for empty string
        return input_str
    compressed = []
    count = 1
    for i in range(1, len(input_str)):
        if input_str[i] == input_str[i - 1]:
            count += 1
        else:
            compressed.append(input_str[i - 1] + str(count))
            count = 1
    compressed.append(input_str[-1] + str(count))  # Handle the last sequence
    compressed_str = ''.join(compressed)
    return compressed_str if len(compressed_str) < len(input_str) else input_str
# Example usage
print(compress_string("aabbbcc"))  # Output: a2b3c2
print(compress_string("abcdef"))  # Output: abcdef
print(compress_string(""))  # Output: 
print(compress_string("a"))  # Output: a
print(compress_string("aaa"))  # Output: a3