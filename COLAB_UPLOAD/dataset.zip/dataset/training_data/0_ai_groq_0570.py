class BinarySearch:
    """
    A class implementing binary search on a sorted array.
    ----------
    arr : list
        The sorted array to search in.
    target : int
        The target value to search for.
    """
    def __init__(self, arr: list):
        """
        Initialize the binary search object with a sorted array.
        ----
        arr : list
            The sorted array to search in.
        ------
        ValueError
            If the input array is not sorted.
        """
        self.arr = arr
        self._validate_sorted_array()
    def _validate_sorted_array(self):
        """
        Validate that the input array is sorted.
        ------
        ValueError
            If the input array is not sorted.
        """
        if self.arr != sorted(self.arr):
            raise ValueError("Input array must be sorted")
    def search(self, target: int):
        """
        Search for the target value in the sorted array.