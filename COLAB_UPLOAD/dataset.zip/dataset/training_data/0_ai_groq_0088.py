from typing import Dict, List, Tuple
def bellman_ford(graph: Dict[str, List[Tuple[str, int]]], source: str):
    """
    Bellman-Ford algorithm to find the shortest path from the source node to all other nodes in a weighted graph.
    """
    if source not in graph:
        raise ValueError("Source node not found in the graph")
    # Initialize the distance to all nodes as infinity and the distance to the source node as 0
    distance = {node: float('inf') for node in graph}
    distance[source] = 0
    # Relax the edges repeatedly
    for _ in range(len(graph) - 1):
        for node in graph:
            for neighbor, weight in graph[node]:
                # If the distance to the neighbor through the current node is less than the known distance, update the distance
                if distance[node] + weight < distance[neighbor]:
                    distance[neighbor] = distance[node] + weight
    # Check for negative-weight cycles
    for node in graph:
        for neighbor, weight in graph[node]:
            # If the distance to the neighbor through the current node is less than the known distance, a negative cycle is detected
            if distance[node] + weight < distance[neighbor]:
                return None
    return distance
# Example usage
if __name__ == "__main__":
    graph = {
        'A': [('B', -1), ('C',  4)],
        'B': [('C',  3), ('D',  2), ('E',  2)],
        'C': [],
        'D': [('B',  1), ('C',  5)],
        'E': [('D', -3)]
    }