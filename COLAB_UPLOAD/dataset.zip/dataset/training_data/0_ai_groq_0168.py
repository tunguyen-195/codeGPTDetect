from typing import List
def bucket_sort(arr: List[float]):
    """
    Sorts an array of uniformly distributed floating point numbers using Bucket Sort.
    Time Complexity:
        Best Case: O(n + k) when the input is uniformly distributed and the number of buckets is optimal.
        Average Case: O(n + k) when the input is uniformly distributed and the number of buckets is optimal.
        Worst Case: O(n^2) when the input is not uniformly distributed or the number of buckets is too small.
    Space Complexity:
        O(n + k) where n is the number of elements and k is the number of buckets.
    """
    if not arr:
        raise ValueError("Input array is empty")
    # Determine the minimum and maximum values in the array
    min_value = min(arr)
    max_value = max(arr)
    # If all elements are equal, return the original array
    if min_value == max_value:
        return arr
    # Calculate the range of the input
    range_value = (max_value - min_value) / len(arr)
    # Create empty buckets
    buckets = [[] for _ in range(len(arr))]
    # Insert elements into their respective buckets
    for num in arr:
        # Calculate the index of the bucket where the current element should be inserted
        index = int((num - min_value) / range_value) if range_value != 0 else 0
        # If the calculated index is equal to the number of buckets, decrease it by 1
        if index == len(buckets):
            index -= 1
        buckets[index].append(num)
