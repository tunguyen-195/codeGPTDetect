class Node:
    """Represents a node in the Binary Search Tree."""
    def __init__(self, value: int):
        """
        Initializes a Node with a value and two children.
        """
        self.value = value
        self.left = None
        self.right = None
class BinarySearchTree:
    """Represents a Binary Search Tree."""
    def __init__(self):
        """
        Initializes an empty Binary Search Tree.
        """
        self.root = None
    def insert(self, value: int):
        """
        Inserts a value into the Binary Search Tree.
        """
        if not self.root:
            self.root = Node(value)
        else:
            self._insert_recursive(self.root, value)
    def _insert_recursive(self, node: Node, value: int):
        """
        Recursively inserts a value into the Binary Search Tree.
        """
        if value < node.value:
            if node.left:
                self._insert_recursive(node.left, value)
            else:
                node.left = Node(value)
        elif value > node.value: