class BinaryHeap:
    """
    A Binary Heap data structure that supports both min and max operations.
    The heap is implemented as a list where the parent node is smaller than its children
    in the min heap, and the parent node is larger than its children in the max heap.
    """
    def __init__(self, is_min_heap: bool = True):
        """
        Initializes the binary heap.
        """
        self.heap = []
        self.is_min_heap = is_min_heap
    def insert(self, value: int):
        """
        Inserts a value into the heap.
        """
        if not self.heap:
            raise ValueError("Heap is empty. Please provide a value to insert.")
        self.heap.append(value)
        self._heapify_up(len(self.heap) - 1)
    def delete(self, value: int):
        """
        Deletes a value from the heap.
        """
        if value not in self.heap:
            raise ValueError("Value not found in the heap.")
        index = self.heap.index(value)
        self.heap[index] = self.heap[-1]
        self.heap.pop()
        self._heapify_down(index)