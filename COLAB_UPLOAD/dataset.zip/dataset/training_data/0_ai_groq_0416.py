from typing import List
def four_sum(nums: List[int], target: int):
    """
    Finds all unique quadruplets in the given list of integers that sum up to the target value.
    - nums (List[int]): A list of integers.
    - target (int): The target sum.
    - List[List[int]]: A list of unique quadruplets that sum up to the target value.
    """
    nums.sort()  # Sort the list to apply two-pointer technique
    result = []
    def k_sum(nums: List[int], target: int, k: int):
        """
        Recursive function to find all unique k-tuples in the given list of integers that sum up to the target value.
        - nums (List[int]): A list of integers.
        - target (int): The target sum.
        - k (int): The number of elements in the tuple.
        """
        if k == 2:
            # Use two-pointer technique to find pairs that sum up to the target value
            left, right = 0, len(nums) - 1
            while left < right:
                current_sum = nums[left] + nums[right]
                if current_sum == target:
                    result.append([nums[left], nums[right]])
                    left += 1
                    right -= 1
                elif current_sum < target:
                    left += 1
                else:
                    right -= 1
        else:
            for i in range(len(nums) - k + 1):
                # Recursively call k_sum function with the remaining elements and k-1
                k_sum(nums[i + 1:], target - nums[i], k - 1)
