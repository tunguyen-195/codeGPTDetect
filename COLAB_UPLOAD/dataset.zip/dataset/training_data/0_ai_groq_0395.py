def longest_palindrome_substring(s: str):
    """
    Find the longest palindrome substring in a given string.
    str: The longest palindrome substring.
    TypeError: If the input is not a string.
    ValueError: If the input string is empty.
    """
    # Check if the input is a string
    if not isinstance(s, str):
        raise TypeError("Input must be a string.")
    # Check if the input string is empty
    if not s:
        raise ValueError("Input string cannot be empty.")
    # Initialize the longest palindrome substring and its length
    longest_palindrome = ""
    max_length = 0
    # Iterate over the string
    for i in range(len(s)):
        # Consider odd-length palindrome
        for j in range(i + 1, len(s) + 1):
            substring = s[i:j]
            # Check if the substring is a palindrome and update the longest palindrome if necessary
            if substring == substring[::-1] and len(substring) > max_length:
                longest_palindrome = substring
                max_length = len(substring)
        # Consider even-length palindrome
        for j in range(i + 2, len(s) + 1, 2):
            substring = s[i:j]
            # Check if the substring is a palindrome and update the longest palindrome if necessary
            if substring == substring[::-1] and len(substring) > max_length:
                longest_palindrome = substring