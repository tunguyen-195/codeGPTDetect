class MinHeap:
    """
    A binary min heap implementation.
    """
    def __init__(self):
        """
        Initializes an empty min heap.
        """
        self.heap = []
        self.size = 0
    def insert(self, value: int):
        """
        Inserts a new value into the min heap.
        """
        if not isinstance(value, int):
            raise ValueError("Value must be an integer.")
        self.heap.append(value)
        self.size += 1
        self._heapify_up(self.size - 1)
    def extract_min(self):
        """
        Removes and returns the minimum value from the min heap.
        """
        if self.size == 0:
            raise IndexError("Heap is empty.")
        if self.size == 1:
            self.size -= 1
            return self.heap.pop()
        root = self.heap[0]
        self.heap[0] = self.heap.pop()
        self.size -= 1