def find_missing_number(nums: list[int]):
    """
    Find the missing number in an array from 1 to n.
    nums: A list of integers from 1 to n with one number missing.
    The missing number in the array.
    ValueError: If the input list is empty or contains duplicate numbers.
    """
    if not nums:
        raise ValueError("Input list is empty")
    # Calculate the sum of numbers from 1 to n using Gauss' formula
    n = len(nums) + 1
    expected_sum = n * (n + 1) // 2
    # Calculate the actual sum of the numbers in the list
    actual_sum = sum(nums)
    # The missing number is the difference between the expected sum and the actual sum
    missing_number = expected_sum - actual_sum
    return missing_number