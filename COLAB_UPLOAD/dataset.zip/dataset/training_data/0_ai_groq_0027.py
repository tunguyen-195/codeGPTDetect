def heapify(arr: list[int], n: int, i: int):
    """
    Build a max heap.
    :param arr: The input list to be heapified.
    :param n: The size of the heap.
    :param i: The index to start heapifying from.
    :return: None
    """
    largest = i
    left = 2 * i + 1
    right = 2 * i + 2
    # Check if the left child exists and is greater than the root
    if left < n and arr[left] > arr[largest]:
        largest = left
    # Check if the right child exists and is greater than the root
    if right < n and arr[right] > arr[largest]:
        largest = right
    # If the largest is not the root, swap and heapify the affected sub-tree
    if largest != i:
        arr[i], arr[largest] = arr[largest], arr[i]
        heapify(arr, n, largest)
def heap_sort(arr: list[int]):
    """
    Sorts an array in ascending order using HeapSort algorithm.
    Time complexity:
    - Best case: O(n log n)
    - Average case: O(n log n)
    - Worst case: O(n log n)
    Space complexity: O(1)
    :param arr: The input list to be sorted.
    :return: The sorted list.
    """