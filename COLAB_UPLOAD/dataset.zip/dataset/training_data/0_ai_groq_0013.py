class CircularQueue:
    """
    A class to implement a Circular Queue with a fixed size.
    """
    def __init__(self, k: int):
        """
        Initializes the Circular Queue with a given size.
        """
        if not isinstance(k, int) or k <= 0:
            raise ValueError("The size of the queue must be a positive integer.")
        self.k = k
        self.queue = [None] * k
        self.head = self.tail = -1
    def is_empty(self):
        """
        Checks if the queue is empty.
        """
        return self.head == -1
    def is_full(self):
        """
        Checks if the queue is full.
        """
        return (self.tail + 1) % self.k == self.head
    def enqueue(self, data: int):
        """
        Adds an element to the rear of the queue.
        """
        if self.is_full():
            raise Exception("Queue is full.")
        elif self.is_empty():
            self.head = self.tail = 0