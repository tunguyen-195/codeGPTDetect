def exponential_search(arr: list, target: int):
    """
    Exponential Search for unbounded arrays.
    This function performs an exponential search on an unbounded array.
    It first finds the range where the element is present using exponential search,
    then performs a binary search in that range.
    """
    # If the array is empty, the target is not present
    if not arr:
        return -1
    # If the target is present at the first index, return 0
    if arr[0] == target:
        return 0
    # Initialize the index
    i = 1
    # Exponentially increase the index until we find the range where the target is present
    while i < len(arr) and arr[i] <= target:
        # If the target is found during the exponential search, return the index
        if arr[i] == target:
            return i
        i *= 2
    # If the target is not found during the exponential search, perform a binary search
    # in the range [i//2, min(i, len(arr) - 1)]
    return binary_search(arr, target, i // 2, min(i, len(arr) - 1))
def binary_search(arr: list, target: int, low: int, high: int):
    """
    Binary Search for a sorted list.
    This function performs a binary search on a sorted list.
    """
