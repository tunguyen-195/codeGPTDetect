class Node:
    """Represents a single node in the circular linked list."""
    
    def __init__(self, data: any):
        """
        Initializes a new node with the given data.
        
        """
        self.data = data
        self.next = None
class CircularLinkedList:
    """Represents a circular linked list."""
    
    def __init__(self):
        """
        Initializes an empty circular linked list.
        """
        self.head = None
        self.tail = None
    def append(self, data: any):
        """
        Adds a new node with the given data to the end of the list.
        
        """
        new_node = Node(data)
        
        if not self.head:
            self.head = new_node
            self.tail = new_node
            self.tail.next = self.head  # Point the tail to the head for circularity
        else:
            self.tail.next = new_node
            self.tail = new_node
            self.tail.next = self.head  # Point the tail to the head for circularity
    def prepend(self, data: any):
        """
        Adds a new node with the given data to the beginning of the list.