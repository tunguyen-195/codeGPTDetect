def jump_search(arr: list[int], x: int):
    """
    Jump Search is an searching algorithm for ordered lists. It creates a block and tries to find the element in that block.
    If the item is not in the block, it shifts the entire block. The size of the block is the square root of the size of the list.
    """
    n = len(arr)
    # Find the block size to jump
    step = int(n ** 0.5)
    # Find the block where element is present (if it is present)
    prev = 0
    while arr[min(step, n) - 1] < x:
        prev = step
        step += int(n ** 0.5)
        if prev >= n:
            return False
    # Doing a linear search for x in block beginning with prev
    while arr[prev] < x:
        prev += 1
        if prev == min(step, n):
            return False
    # If we reach here, then the element was present in prev index
    if arr[prev] == x:
        return True
    return False
# Example usage
if __name__ == "__main__":
    arr = [0, 1, 1, 2, 3, 5, 8, 13, 21, 34, 55, 89, 144, 233, 377, 610]
    x = 55
    if jump_search(arr, x):
        print(f"Element {x} is present in array")
    else:
        print(f"Element {x} is not present in array")
    x = 100
    if jump_search(arr, x):