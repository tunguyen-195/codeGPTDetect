def floyd_warshall(graph: list[list[int]]):
    """
    Implement Floyd-Warshall algorithm to find all-pairs shortest paths in a weighted graph.
    graph: A 2D list representing the adjacency matrix of the graph, where graph[i][j] is the weight of the edge from vertex i to vertex j.
    A 2D list representing the shortest distances between all pairs of vertices.
    ValueError: If the input graph is not a square matrix or contains negative weights.
    """
    # Check if the input graph is a square matrix
    num_vertices = len(graph)
    if any(len(row) != num_vertices for row in graph):
        raise ValueError("Input graph must be a square matrix")
    # Check if the input graph contains negative weights
    for i in range(num_vertices):
        for j in range(num_vertices):
            if graph[i][j] < 0:
                raise ValueError("Input graph must not contain negative weights")
    # Initialize the distance matrix with the input graph
    distances = [[float('inf')] * num_vertices for _ in range(num_vertices)]
    for i in range(num_vertices):
        for j in range(num_vertices):
            distances[i][j] = graph[i][j]
    # Relax the edges repeatedly
    for k in range(num_vertices):
        for i in range(num_vertices):
            for j in range(num_vertices):
                # Update the distance if a shorter path is found
                distances[i][j] = min(distances[i][j], distances[i][k] + distances[k][j])
    return distances
def print_shortest_paths(distances: list[list[int]]):
    """
    Print the shortest distances between all pairs of vertices.