from collections import OrderedDict
class LRUCache:
    """
    A class to implement an LRU (Least Recently Used) Cache using OrderedDict.
    """
    def __init__(self, capacity: int):
        """
        Initialize the LRU Cache.
        """
        if not isinstance(capacity, int) or capacity <= 0:
            raise ValueError("Capacity must be a positive integer")
        self.capacity = capacity
        self.cache = OrderedDict()
    def get(self, key: int):
        """
        Get the value associated with the given key from the cache.
        """
        if key in self.cache:
            # Move the key to the end to mark it as recently used
            self.cache.move_to_end(key)
            return self.cache[key]
        return -1
    def put(self, key: int, value: int):
        """
        Add or update the value associated with the given key in the cache.
        """
        if not isinstance(key, int) or not isinstance(value, int):
            raise ValueError("Key and value must be integers")
        if key in self.cache:
            # Update the value and move the key to the end
            self.cache[key] = value
            self.cache.move_to_end(key)