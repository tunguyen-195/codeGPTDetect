def longest_common_prefix(strs: list[str]):
    """
    This function finds the longest common prefix among a list of strings.
    str: The longest common prefix.
    ValueError: If the input list is empty.
    TypeError: If the input list contains non-string elements.
    """
    # Check if the input list is empty
    if not strs:
        raise ValueError("Input list cannot be empty")
    # Check if the input list contains non-string elements
    if not all(isinstance(s, str) for s in strs):
        raise TypeError("Input list must contain only strings")
    # Sort the list of strings alphabetically
    # This is done to simplify the process of finding the common prefix
    # Since the list is sorted, the common prefix will be the common prefix of the first and last strings
    strs.sort()
    # Get the first and last strings in the sorted list
    first_str = strs[0]
    last_str = strs[-1]
    # Initialize the common prefix as an empty string
    common_prefix = ""
    # Iterate over the characters in the first string
    for i in range(len(first_str)):
        # Check if the character at the current position in the first string
        # is the same as the character at the same position in the last string
        if i < len(last_str) and first_str[i] == last_str[i]:
            # If the characters match, add the character to the common prefix
            common_prefix += first_str[i]
        else: