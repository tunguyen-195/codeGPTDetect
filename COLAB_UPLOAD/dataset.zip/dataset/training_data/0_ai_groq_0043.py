from heapq import heappop, heappush
from typing import List, Tuple, Dict
class AStarSearch:
    """
    A* Search algorithm implementation for pathfinding.
    """
    def __init__(self, grid: List[List[int]], start: Tuple[int, int], goal: Tuple[int, int]):
        """
        Initializes the A* Search algorithm.
        """
        self.grid = grid
        self.start = start
        self.goal = goal
        self.open_list: List[Tuple[float, Tuple[int, int]]] = []
        self.closed_list: Dict[Tuple[int, int], bool] = {}
        self.came_from: Dict[Tuple[int, int], Tuple[int, int]] = {}
        self.g_score: Dict[Tuple[int, int], float] = {}
        self.f_score: Dict[Tuple[int, int], float] = {}
    def heuristic(self, node: Tuple[int, int]):
        """
        Calculates the Manhattan distance heuristic.
        """
        return abs(node[0] - self.goal[0]) + abs(node[1] - self.goal[1])
    def is_valid(self, node: Tuple[int, int]):
        """
        Checks if a node is within the grid boundaries and not an obstacle.
        """
        x, y = node
        return (0 <= x < len(self.grid)) and (0 <= y < len(self.grid[0])) and (self.grid[x][y] == 0)
    def is_goal(self, node: Tuple[int, int]):
        """