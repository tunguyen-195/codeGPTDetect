from typing import Any, List
class Deque:
    """
    A Double-ended Queue (Deque) implementation in Python.
    A deque is a data structure that allows elements to be added or removed from both ends.
    It supports the following operations:
    - append(element): Adds an element to the right end of the deque.
    - appendleft(element): Adds an element to the left end of the deque.
    - pop(): Removes and returns the element from the right end of the deque.
    - popleft(): Removes and returns the element from the left end of the deque.
    - remove(element): Removes the first occurrence of the specified element from the deque.
    - index(element): Returns the index of the first occurrence of the specified element in the deque.
    - count(element): Returns the number of occurrences of the specified element in the deque.
    """
    def __init__(self):
        """
        Initializes an empty deque.
        """
        self._elements: List[Any] = []
    def append(self, element: Any):
        """
        Adds an element to the right end of the deque.
        """
        self._elements.append(element)
    def appendleft(self, element: Any):
        """
        Adds an element to the left end of the deque.
        """
        self._elements.insert(0, element)
    def pop(self):
        """
        Removes and returns the element from the right end of the deque.