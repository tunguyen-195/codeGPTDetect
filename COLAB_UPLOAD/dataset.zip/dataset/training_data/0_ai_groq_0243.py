class Node:
    """Represents a node in a circular linked list."""
    def __init__(self, data: any):
        """
        Initializes a new node with the given data.
        """
        self.data = data
        self.next = None
class CircularLinkedList:
    """Represents a circular linked list."""
    def __init__(self):
        """
        Initializes an empty circular linked list.
        """
        self.head = None
    def append(self, data: any):
        """
        Appends a new node with the given data to the end of the list.
        """
        if not self.head:
            self.head = Node(data)
            self.head.next = self.head
        else:
            new_node = Node(data)
            current = self.head
            while current.next != self.head:
                current = current.next
            current.next = new_node
            new_node.next = self.head
    def prepend(self, data: any):
        """
        Prepends a new node with the given data to the beginning of the list.
        """
        if not self.head: