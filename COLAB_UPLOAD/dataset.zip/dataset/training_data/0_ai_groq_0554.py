class Graph:
    """
    A class representing a graph using adjacency matrix.
    Methods:
        __init__: Initializes the graph with the given number of vertices.
        add_edge: Adds an edge between two vertices in the graph.
        remove_edge: Removes an edge between two vertices in the graph.
        has_edge: Checks if there is an edge between two vertices in the graph.
        get_neighbors: Returns a list of neighbors of a given vertex.
        display: Prints the adjacency matrix.
    """
    def __init__(self, num_vertices: int):
        """
        Initializes the graph with the given number of vertices.
        """
        if not isinstance(num_vertices, int) or num_vertices <= 0:
            raise ValueError("Number of vertices must be a positive integer.")
        self.num_vertices = num_vertices
        self.matrix = [[0 for _ in range(num_vertices)] for _ in range(num_vertices)]
    def add_edge(self, v1: int, v2: int):
        """
        Adds an edge between two vertices in the graph.
        """
        if not (0 <= v1 < self.num_vertices and 0 <= v2 < self.num_vertices):
            raise ValueError("Vertex indices must be within the range of vertices.")
        if v1 == v2:
            raise ValueError("Vertices cannot be the same.")
        self.matrix[v1][v2] = 1
        self.matrix[v2][v1] = 1  # Comment: For undirected graph, add edge in both directions
    def remove_edge(self, v1: int, v2: int):
        """