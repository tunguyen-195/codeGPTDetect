def counting_sort(arr: list[int]):
    """
    Sorts an integer array using the Counting Sort algorithm.
    list[int]: The sorted integer array.
    Time Complexity:
    Best-case: O(n + k), where n is the number of elements in the array and k is the range of input.
    Average-case: O(n + k), assuming the input is uniformly distributed.
    Worst-case: O(n + k), when all elements are unique or the range of input is large.
    Space Complexity:
    O(n + k), for the output array and the count array.
    """
    if not arr:
        # If the array is empty, return it as it is already sorted
        return arr
    # Find the minimum and maximum values in the array to determine the range of input
    min_val = min(arr)
    max_val = max(arr)
    # Calculate the range of input (k)
    k = max_val - min_val + 1
    # Create a count array to store the count of individual elements
    count = [0] * k
    # Count the occurrences of each element in the array
    for num in arr:
        count[num - min_val] += 1
    # Calculate cumulative counts to determine the positions of elements in the output array
    for i in range(1, k):
        count[i] += count[i - 1]
    # Create the output array
    output = [0] * len(arr)