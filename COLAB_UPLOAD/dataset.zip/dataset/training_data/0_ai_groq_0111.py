def factorial(n: int):
    """
    Calculate the factorial of a given number using recursion.
    """
    # Base case: factorial of 0 or 1 is 1
    if n == 0 or n == 1:
        return 1
    
    # Check for negative input
    if n < 0:
        raise ValueError("Input number must be non-negative.")
    
    # Recursive case: n! = n * (n-1)!
    return n * factorial(n-1)
def main():
    # Example usage
    try:
        num = 5
        result = factorial(num)
        print(f"The factorial of {num} is {result}")
    except ValueError as e:
        print(f"Error: {e}")
if __name__ == "__main__":
    main()