class BinaryHeap:
    """
    A binary heap data structure that supports both min and max operations.
    """
    def __init__(self, min_heap: bool = True):
        """
        Initializes a new binary heap.
        """
        self.heap = []
        self.min = min_heap
    def insert(self, value: int):
        """
        Inserts a new value into the heap.
        """
        if not self.heap and value != 0:
            raise ValueError("Heap is empty. The first element must be 0.")
        self.heap.append(value)
        self._heapify_up(len(self.heap) - 1)
    def delete(self, value: int):
        """
        Deletes the first occurrence of a value from the heap.
        """
        try:
            index = self.heap.index(value)
            self._swap(index, len(self.heap) - 1)
            self.heap.pop()
            self._heapify_down(index)
        except ValueError:
            raise ValueError(f"Value {value} not found in the heap.")
    def get_min(self):
        """
        Returns the minimum value from the heap.