class Graph:
    """
    A class to represent a Graph using adjacency matrix.
    ----------
    num_vertices : int
        The number of vertices in the graph.
    adjacency_matrix : list
        A 2D list representing the adjacency matrix of the graph.
    """
    def __init__(self, num_vertices: int):
        """
        Initialize a Graph object.
        ----------
        num_vertices : int
            The number of vertices in the graph.
        ------
        ValueError
            If num_vertices is less than 1.
        """
        if num_vertices < 1:
            raise ValueError("Number of vertices must be greater than 0")
        self.num_vertices = num_vertices
        self.adjacency_matrix = [[0 for _ in range(num_vertices)] for _ in range(num_vertices)]
    def add_edge(self, src: int, dest: int):
        """
        Add an edge to the graph.
        ----------
        src : int
            The source vertex.
        dest : int
            The destination vertex.
        ------
        ValueError