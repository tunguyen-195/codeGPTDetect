from typing import Dict, List
class Graph:
    """
    A directed graph class for cycle detection.
    """
    def __init__(self):
        """
        Initialize an empty graph.
        """
        self.adjacency_list: Dict[int, List[int]] = {}
    def add_edge(self, source: int, destination: int):
        """
        Add a directed edge to the graph.
        """
        if source not in self.adjacency_list:
            self.adjacency_list[source] = []
        self.adjacency_list[source].append(destination)
    def has_cycle(self):
        """
        Detect a cycle in the graph using DFS.
        bool: True if a cycle exists, False otherwise.
        """
        visited: set = set()
        rec_stack: set = set()
        for node in self.adjacency_list:
            if node not in visited:
                if self._has_cycle_util(node, visited, rec_stack):
                    return True
        return False
