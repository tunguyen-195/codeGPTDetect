def radixsort(nums: list[int]):
    """
    Sorts a list of integers using the radix sort algorithm.
    The radix sort algorithm is a non-comparative integer sorting algorithm that sorts data with integer keys by grouping keys by the individual digits which share the same significant position and value.
    Time complexity: O(nk) where n is the number of elements and k is the number of digits in the maximum number.
    list[int]: A sorted list of integers.
    TypeError: If the input is not a list of integers.
    """
    # Check if input is a list
    if not isinstance(nums, list):
        raise TypeError("Input must be a list")
    # Check if all elements in the list are integers
    if not all(isinstance(num, int) for num in nums):
        raise TypeError("All elements in the list must be integers")
    # Find the maximum number to determine the number of digits
    max_num = max(nums)
    # If the list is empty or all numbers are zero, return the list as it is already sorted
    if max_num == 0:
        return nums
    # Perform counting sort for every digit
    exp = 1
    while max_num // exp > 0:
        # Initialize the count array
        count = [0] * 10
        # Store the count of occurrences in count array
        for num in nums:
            digit = (num // exp) % 10
            count[digit] += 1