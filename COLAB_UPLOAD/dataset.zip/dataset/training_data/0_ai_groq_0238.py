class BTreeNode:
    """
    A node in the B-Tree.
    """
    def __init__(self, leaf: bool = False):
        """
        Initialize a BTreeNode.
        """
        self.keys = []
        self.children = []
        self.leaf = leaf
class BTree:
    """
    A B-Tree for disk-based storage.
    """
    def __init__(self, degree: int):
        """
        Initialize a BTree.
        """
        self.degree = degree
        self.root = BTreeNode(True)
    def insert(self, key: int):
        """
        Insert a key into the B-Tree.
