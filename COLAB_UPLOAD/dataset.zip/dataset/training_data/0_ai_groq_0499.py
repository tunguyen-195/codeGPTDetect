def z_algorithm(pattern: str):
    """
    Compute the Z-array for the given pattern string.
    The Z-array is an array where Z[i] represents the length of the longest substring
    starting at position i that is a prefix of the pattern.
    """
    if not pattern:
        raise ValueError("Input pattern cannot be an empty string")
    n = len(pattern)
    z_array = [0] * n
    left = 0
    right = 0
    for i in range(1, n):
        # If i is greater than the right boundary, set i to the left boundary
        if i > right:
            left = i
            right = i
            while right < n and pattern[right - left] == pattern[right]:
                right += 1
            z_array[i] = right - left
            right -= 1
        else:
            # If i is within the right boundary, use the previously computed value
            k = i - left
            if z_array[k] < right - i + 1:
                z_array[i] = z_array[k]
            else:
                left = i
                while right < n and pattern[right - left] == pattern[right]:
                    right += 1
                z_array[i] = right - left
                right -= 1
    return z_array
def find_pattern(text: str, pattern: str):